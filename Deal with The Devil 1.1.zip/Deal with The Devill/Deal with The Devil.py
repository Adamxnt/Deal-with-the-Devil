import pygame as p
import os
import logging as l
from pygame import mixer as m
import pygame.freetype
import time as t
import random as r
print("Deal With The Devil")
print('''
Made and Coded by: Adam LeFaive
Sprites made by: Zachary Padmore (because I couldn't for the life of me)
''')
print("This is a top-down 2D game, inspired by Binding of Isaac. You will find weapons and items in rooms to defeat the enemies that appear. You must defeat this enemies before you can leave the room.")
print('''
To walk forwards press (W) or (Up arrow key)
To walk backwards press (S) or (Down arrow key)
To walk to the right press (D) or (Right arrow key)
To walk to the left press (A) or (Left arrow key)
To jump press (Space bar)
''')
print("If there is something you think I should change/update/add, tell me")
p.init()
m.init()
p.font.init()
win=p.display.set_mode((800, 600))
p.display.set_caption("Deal with The Devil")
walkDown = [p.image.load('D1.png'), p.image.load('D2.png'), p.image.load('D1.png'), p.image.load('D3.png'), p.image.load('D1.png'), p.image.load('D2.png'), p.image.load('D1.png'), p.image.load('D3.png'), p.image.load('D1.png'), p.image.load('D2.png'), p.image.load('D1.png'), p.image.load('D3.png'), p.image.load('D1.png'), p.image.load('D2.png'), p.image.load('D1.png'), p.image.load('D3.png'), p.image.load('D1.png'), p.image.load('D2.png'), p.image.load('D1.png'), p.image.load('D3.png')]
walkUp = [p.image.load('U1.png'), p.image.load('U2.png'), p.image.load('U1.png'), p.image.load('U3.png'), p.image.load('U1.png'), p.image.load('U2.png'), p.image.load('U1.png'), p.image.load('U3.png'), p.image.load('U1.png'), p.image.load('U2.png'), p.image.load('U1.png'), p.image.load('U3.png'), p.image.load('U1.png'), p.image.load('U2.png'), p.image.load('U1.png'), p.image.load('U3.png'), p.image.load('U1.png'), p.image.load('U2.png'), p.image.load('U1.png'), p.image.load('U3.png')]
walkRight = [p.image.load('R1.png'), p.image.load('R2.png'), p.image.load('R1.png'), p.image.load('R3.png'), p.image.load('R1.png'), p.image.load('R2.png'), p.image.load('R1.png'), p.image.load('R3.png'), p.image.load('R1.png'), p.image.load('R2.png'), p.image.load('R1.png'), p.image.load('R3.png'), p.image.load('R1.png'), p.image.load('R2.png'), p.image.load('R1.png'), p.image.load('R3.png'), p.image.load('R1.png'), p.image.load('R2.png'), p.image.load('R1.png'), p.image.load('R3.png')]
walkLeft = [p.image.load('L1.png'), p.image.load('L2.png'), p.image.load('L1.png'), p.image.load('L3.png'), p.image.load('L1.png'), p.image.load('L2.png'), p.image.load('L1.png'), p.image.load('L3.png'), p.image.load('L1.png'), p.image.load('L2.png'), p.image.load('L1.png'), p.image.load('L3.png'), p.image.load('L1.png'), p.image.load('L2.png'), p.image.load('L1.png'), p.image.load('L3.png'), p.image.load('L1.png'), p.image.load('L2.png'), p.image.load('L1.png'), p.image.load('L3.png')]
pickupDagger = [p.image.load('P1.png'), p.image.load('P2.png'), p.image.load('P3.png'), p.image.load('P4.png'), p.image.load('P5.png'), p.image.load('P6.png'), p.image.load('P7.png'), p.image.load('P8.png'), p.image.load('P9.png'), p.image.load('P10.png'), p.image.load('P11.png'), p.image.load('P12.png'), p.image.load('P13.png'), p.image.load('P14.png'), p.image.load('P15-dagger.png'), p.image.load('P15-dagger.png'), p.image.load('P15-dagger.png'), p.image.load('P15-dagger.png'), p.image.load('P15-dagger.png'), p.image.load('P15-dagger.png')]
pickupTrident = [p.image.load('P1.png'), p.image.load('P2.png'), p.image.load('P3.png'), p.image.load('P4.png'), p.image.load('P5.png'), p.image.load('P6.png'), p.image.load('P7.png'), p.image.load('P8.png'), p.image.load('P9.png'), p.image.load('P10.png'), p.image.load('P11.png'), p.image.load('P12.png'), p.image.load('P13.png'), p.image.load('P14.png'), p.image.load('P15-trident.png'), p.image.load('P15-trident.png'), p.image.load('P15-trident.png'), p.image.load('P15-trident.png'), p.image.load('P15-trident.png'), p.image.load('P15-trident.png')]
pickupSword = [p.image.load('P1.png'), p.image.load('P2.png'), p.image.load('P3.png'), p.image.load('P4.png'), p.image.load('P5.png'), p.image.load('P6.png'), p.image.load('P7.png'), p.image.load('P8.png'), p.image.load('P9.png'), p.image.load('P10.png'), p.image.load('P11.png'), p.image.load('P12.png'), p.image.load('P13.png'), p.image.load('P14.png'), p.image.load('P15-sword.png'), p.image.load('P15-sword.png'), p.image.load('P15-sword.png'), p.image.load('P15-sword.png'), p.image.load('P15-sword.png'), p.image.load('P15-sword.png')]
pickupAxe = [p.image.load('P1.png'), p.image.load('P2.png'), p.image.load('P3.png'), p.image.load('P4.png'), p.image.load('P5.png'), p.image.load('P6.png'), p.image.load('P7.png'), p.image.load('P8.png'), p.image.load('P9.png'), p.image.load('P10.png'), p.image.load('P11.png'), p.image.load('P12.png'), p.image.load('P13.png'), p.image.load('P14.png'), p.image.load('P15-axe.png'), p.image.load('P15-axe.png'), p.image.load('P15-axe.png'), p.image.load('P15-axe.png'), p.image.load('P15-axe.png'), p.image.load('P15-axe.png')]
pickupGun = [p.image.load('P1.png'), p.image.load('P2.png'), p.image.load('P3.png'), p.image.load('P4.png'), p.image.load('P5.png'), p.image.load('P6.png'), p.image.load('P7.png'), p.image.load('P8.png'), p.image.load('P9.png'), p.image.load('P10.png'), p.image.load('P11.png'), p.image.load('P12.png'), p.image.load('P13.png'), p.image.load('P14.png'), p.image.load('P15-gun.png'), p.image.load('P15-gun.png'), p.image.load('P15-gun.png'), p.image.load('P15-gun.png'), p.image.load('P15-gun.png'), p.image.load('P15-gun.png')]
pickupNuke = [p.image.load('P1.png'), p.image.load('P2.png'), p.image.load('P3.png'), p.image.load('P4.png'), p.image.load('P5.png'), p.image.load('P6.png'), p.image.load('P7.png'), p.image.load('P8.png'), p.image.load('P9.png'), p.image.load('P10.png'), p.image.load('P11.png'), p.image.load('P12.png'), p.image.load('P13.png'), p.image.load('P14.png'), p.image.load('P15-nuke.png'), p.image.load('P15-nuke.png'), p.image.load('P15-nuke.png'), p.image.load('P15-nuke.png'), p.image.load('P15-nuke.png'), p.image.load('P15-nuke.png')]
pickupHealingHerb = [p.image.load('P1.png'), p.image.load('P2.png'), p.image.load('P3.png'), p.image.load('P4.png'), p.image.load('P5.png'), p.image.load('P6.png'), p.image.load('P7.png'), p.image.load('P8.png'), p.image.load('P9.png'), p.image.load('P10.png'), p.image.load('P11.png'), p.image.load('P12.png'), p.image.load('P13.png'), p.image.load('P14.png'), p.image.load('P15-healing_herb.png'), p.image.load('P15-healing_herb.png'), p.image.load('P15-healing_herb.png'), p.image.load('P15-healing_herb.png'), p.image.load('P15-healing_herb.png'), p.image.load('P15-healing_herb.png'), p.image.load('P15-healing_herb.png')]
pickupPotion = [p.image.load('P1.png'), p.image.load('P2.png'), p.image.load('P3.png'), p.image.load('P4.png'), p.image.load('P5.png'), p.image.load('P6.png'), p.image.load('P7.png'), p.image.load('P8.png'), p.image.load('P9.png'), p.image.load('P10.png'), p.image.load('P11.png'), p.image.load('P12.png'), p.image.load('P13.png'), p.image.load('P14.png'), p.image.load('P15-potion.png'), p.image.load('P15-potion.png'), p.image.load('P15-potion.png'), p.image.load('P15-potion.png'), p.image.load('P15-potion.png'), p.image.load('P15-potion.png')]
pickupFreshWater = [p.image.load('P1.png'), p.image.load('P2.png'), p.image.load('P3.png'), p.image.load('P4.png'), p.image.load('P5.png'), p.image.load('P6.png'), p.image.load('P7.png'), p.image.load('P8.png'), p.image.load('P9.png'), p.image.load('P10.png'), p.image.load('P11.png'), p.image.load('P12.png'), p.image.load('P13.png'), p.image.load('P14.png'), p.image.load('P15-fresh_water.png'), p.image.load('P15-fresh_water.png'), p.image.load('P15-fresh_water.png'), p.image.load('P15-fresh_water.png'), p.image.load('P15-fresh_water.png'), p.image.load('P15-fresh_water.png')]
pickupSuperPotion = [p.image.load('P1.png'), p.image.load('P2.png'), p.image.load('P3.png'), p.image.load('P4.png'), p.image.load('P5.png'), p.image.load('P6.png'), p.image.load('P7.png'), p.image.load('P8.png'), p.image.load('P9.png'), p.image.load('P10.png'), p.image.load('P11.png'), p.image.load('P12.png'), p.image.load('P13.png'), p.image.load('P14.png'), p.image.load('P15-super_potion.png'), p.image.load('P15-super_potion.png'), p.image.load('P15-super_potion.png'), p.image.load('P15-super_potion.png'), p.image.load('P15-super_potion.png'), p.image.load('P15-super_potion.png')]
pickupOmegaPotion = [p.image.load('P1.png'), p.image.load('P2.png'), p.image.load('P3.png'), p.image.load('P4.png'), p.image.load('P5.png'), p.image.load('P6.png'), p.image.load('P7.png'), p.image.load('P8.png'), p.image.load('P9.png'), p.image.load('P10.png'), p.image.load('P11.png'), p.image.load('P12.png'), p.image.load('P13.png'), p.image.load('P14.png'), p.image.load('P15-omega_potion.png'), p.image.load('P15-omega_potion.png'), p.image.load('P15-omega_potion.png'), p.image.load('P15-omega_potion.png'), p.image.load('P15-omega_potion.png'), p.image.load('P15-omega_potion.png')]
pickupEpicPotion = [p.image.load('P1.png'), p.image.load('P2.png'), p.image.load('P3.png'), p.image.load('P4.png'), p.image.load('P5.png'), p.image.load('P6.png'), p.image.load('P7.png'), p.image.load('P8.png'), p.image.load('P9.png'), p.image.load('P10.png'), p.image.load('P11.png'), p.image.load('P12.png'), p.image.load('P13.png'), p.image.load('P14.png'), p.image.load('P15-epic_potion.png'), p.image.load('P15-epic_potion.png'), p.image.load('P15-epic_potion.png'), p.image.load('P15-epic_potion.png'), p.image.load('P15-epic_potion.png'), p.image.load('P15-epic_potion.png')]
pickupTwoTimes = [p.image.load('P1.png'), p.image.load('P2.png'), p.image.load('P3.png'), p.image.load('P4.png'), p.image.load('P5.png'), p.image.load('P6.png'), p.image.load('P7.png'), p.image.load('P8.png'), p.image.load('P9.png'), p.image.load('P10.png'), p.image.load('P11.png'), p.image.load('P12.png'), p.image.load('P13.png'), p.image.load('P14.png'), p.image.load('P15-two_times.png'), p.image.load('P15-two_times.png'), p.image.load('P15-two_times.png'), p.image.load('P15-two_times.png'), p.image.load('P15-two_times.png'), p.image.load('P15-two_times.png')]
pickupAmulet = [p.image.load('P1.png'), p.image.load('P2.png'), p.image.load('P3.png'), p.image.load('P4.png'), p.image.load('P5.png'), p.image.load('P6.png'), p.image.load('P7.png'), p.image.load('P8.png'), p.image.load('P9.png'), p.image.load('P10.png'), p.image.load('P11.png'), p.image.load('P12.png'), p.image.load('P13.png'), p.image.load('P14.png'), p.image.load('P15-amulet.png'), p.image.load('P15-amulet.png'), p.image.load('P15-amulet.png'), p.image.load('P15-amulet.png'), p.image.load('P15-amulet.png'), p.image.load('P15-amulet.png')]
pickupWoodShield = [p.image.load('P1.png'), p.image.load('P2.png'), p.image.load('P3.png'), p.image.load('P4.png'), p.image.load('P5.png'), p.image.load('P6.png'), p.image.load('P7.png'), p.image.load('P8.png'), p.image.load('P9.png'), p.image.load('P10.png'), p.image.load('P11.png'), p.image.load('P12.png'), p.image.load('P13.png'), p.image.load('P14.png'), p.image.load('P15-wood_shield.png'), p.image.load('P15-wood_shield.png'), p.image.load('P15-wood_shield.png'), p.image.load('P15-wood_shield.png'), p.image.load('P15-wood_shield.png'), p.image.load('P15-wood_shield.png')]
pickupMetalShield = [p.image.load('P1.png'), p.image.load('P2.png'), p.image.load('P3.png'), p.image.load('P4.png'), p.image.load('P5.png'), p.image.load('P6.png'), p.image.load('P7.png'), p.image.load('P8.png'), p.image.load('P9.png'), p.image.load('P10.png'), p.image.load('P11.png'), p.image.load('P12.png'), p.image.load('P13.png'), p.image.load('P14.png'), p.image.load('P15-metal_shield.png'), p.image.load('P15-metal_shield.png'), p.image.load('P15-metal_shield.png'), p.image.load('P15-metal_shield.png'), p.image.load('P15-metal_shield.png'), p.image.load('P15-metal_shield.png')]
#pickupKevlarVest = [p.image.load('P1.png'), p.image.load('P2.png'), p.image.load('P3.png'), p.image.load('P4.png'), p.image.load('P5.png'), p.image.load('P6.png'), p.image.load('P7.png'), p.image.load('P8.png'), p.image.load('P9.png'), p.image.load('P10.png'), p.image.load('P11.png'), p.image.load('P12.png'), p.image.load('P13.png'), p.image.load('P14.png'), p.image.load('P15-kevlar_vest.png'), p.image.load('P15-kevlar_vest.png'), p.image.load('P15-kevlar_vest.png'), p.image.load('P15-kevlar_vest.png'), p.image.load('P15-kevlar_vest.png'), p.image.load('P15-kevlar_vest.png')]
MiniDevil = [p.image.load('Mini-Devil1.png'), p.image.load('Mini-Devil2.png'), p.image.load('Mini-Devil1.png'), p.image.load('Mini-Devil2.png'), p.image.load('Mini-Devil1.png'), p.image.load('Mini-Devil2.png'), p.image.load('Mini-Devil1.png'), p.image.load('Mini-Devil2.png'), p.image.load('Mini-Devil1.png'), p.image.load('Mini-Devil2.png'), p.image.load('Mini-Devil1.png'), p.image.load('Mini-Devil2.png'), p.image.load('Mini-Devil1.png'), p.image.load('Mini-Devil2.png'), p.image.load('Mini-Devil1.png'), p.image.load('Mini-Devil2.png'), p.image.load('Mini-Devil1.png'), p.image.load('Mini-Devil2.png'), p.image.load('Mini-Devil1.png'), p.image.load('Mini-Devil2.png')]
Devil = [p.image.load('Devil1.png'), p.image.load('Devil2.png'), p.image.load('Devil1.png'), p.image.load('Devil3.png'), p.image.load('Devil1.png'), p.image.load('Devil2.png'), p.image.load('Devil1.png'), p.image.load('Devil3.png'), p.image.load('Devil1.png'), p.image.load('Devil2.png'), p.image.load('Devil1.png'), p.image.load('Devil3.png'), p.image.load('Devil1.png'), p.image.load('Devil2.png'), p.image.load('Devil1.png'), p.image.load('Devil3.png'), p.image.load('Devil1.png'), p.image.load('Devil2.png'), p.image.load('Devil1.png'), p.image.load('Devil3.png')]
Zombie = [p.image.load('Zombie1.png'), p.image.load('Zombie2.png'), p.image.load('Zombie1.png'), p.image.load('Zombie2.png'), p.image.load('Zombie1.png'), p.image.load('Zombie2.png'), p.image.load('Zombie1.png'), p.image.load('Zombie2.png'), p.image.load('Zombie1.png'), p.image.load('Zombie2.png'), p.image.load('Zombie1.png'), p.image.load('Zombie2.png'), p.image.load('Zombie1.png'), p.image.load('Zombie2.png'), p.image.load('Zombie1.png'), p.image.load('Zombie2.png'), p.image.load('Zombie1.png'), p.image.load('Zombie2.png'), p.image.load('Zombie1.png'), p.image.load('Zombie2.png')]
MmeToure = [p.image.load('Mme-Toure1.png'), p.image.load('Mme-Toure2.png'), p.image.load('Mme-Toure1.png'), p.image.load('Mme-Toure2.png'), p.image.load('Mme-Toure1.png'), p.image.load('Mme-Toure2.png'), p.image.load('Mme-Toure1.png'), p.image.load('Mme-Toure2.png'), p.image.load('Mme-Toure1.png'), p.image.load('Mme-Toure2.png'), p.image.load('Mme-Toure1.png'), p.image.load('Mme-Toure2.png'), p.image.load('Mme-Toure1.png'), p.image.load('Mme-Toure2.png'), p.image.load('Mme-Toure1.png'), p.image.load('Mme-Toure2.png'), p.image.load('Mme-Toure1.png'), p.image.load('Mme-Toure2.png'), p.image.load('Mme-Toure1.png'), p.image.load('Mme-Toure2.png')]
Satan = [p.image.load('Satan1.png'), p.image.load('Satan1.png'), p.image.load('Satan1.png'), p.image.load('Satan2.png'), p.image.load('Satan3.png'), p.image.load('Satan4.png'), p.image.load('Satan5.png'), p.image.load('Satan6.png'), p.image.load('Satan1.png'), p.image.load('Satan2.png'), p.image.load('Satan3.png'), p.image.load('Satan4.png'), p.image.load('Satan5.png'), p.image.load('Satan6.png'), p.image.load('Satan1.png'), p.image.load('Satan2.png'), p.image.load('Satan3.png'), p.image.load('Satan4.png'), p.image.load('Satan5.png'), p.image.load('Satan6.png')]
attackUpDagger = [p.image.load('SU1-dagger.png'), p.image.load('SU2-dagger.png'), p.image.load('SU1-dagger.png'), p.image.load('SU2-dagger.png'), p.image.load('SU1-dagger.png'), p.image.load('SU2-dagger.png'), p.image.load('SU1-dagger.png'), p.image.load('SU2-dagger.png'), p.image.load('SU1-dagger.png'), p.image.load('SU2-dagger.png'), p.image.load('SU1-dagger.png'), p.image.load('SU2-dagger.png'), p.image.load('SU1-dagger.png'), p.image.load('SU2-dagger.png'), p.image.load('SU1-dagger.png'), p.image.load('SU2-dagger.png'), p.image.load('SU1-dagger.png'), p.image.load('SU2-dagger.png'), p.image.load('SU1-dagger.png'), p.image.load('SU2-dagger.png')]
attackUpTrident = [p.image.load('SU1-trident.png'), p.image.load('SU2-trident.png'), p.image.load('SU1-trident.png'), p.image.load('SU2-trident.png'), p.image.load('SU1-trident.png'), p.image.load('SU2-trident.png'), p.image.load('SU1-trident.png'), p.image.load('SU2-trident.png'), p.image.load('SU1-trident.png'), p.image.load('SU2-trident.png'), p.image.load('SU1-trident.png'), p.image.load('SU2-trident.png'), p.image.load('SU1-trident.png'), p.image.load('SU2-trident.png'), p.image.load('SU1-trident.png'), p.image.load('SU2-trident.png'), p.image.load('SU1-trident.png'), p.image.load('SU2-trident.png'), p.image.load('SU1-trident.png'), p.image.load('SU2-trident.png')]
attackUpSword = [p.image.load('SU1-sword.png'), p.image.load('SU2-sword.png'), p.image.load('SU1-sword.png'), p.image.load('SU2-sword.png'), p.image.load('SU1-sword.png'), p.image.load('SU2-sword.png'),  p.image.load('SU1-sword.png'), p.image.load('SU2-sword.png'), p.image.load('SU1-sword.png'), p.image.load('SU2-sword.png'),  p.image.load('SU1-sword.png'), p.image.load('SU2-sword.png'),  p.image.load('SU1-sword.png'), p.image.load('SU2-sword.png'),  p.image.load('SU1-sword.png'), p.image.load('SU2-sword.png'),  p.image.load('SU1-sword.png'), p.image.load('SU2-sword.png'), p.image.load('SU1-sword.png'), p.image.load('SU2-sword.png')]
attackUpAxe = [p.image.load('SU1-axe.png'), p.image.load('SU2-axe.png'), p.image.load('SU1-axe.png'), p.image.load('SU2-axe.png'), p.image.load('SU1-axe.png'), p.image.load('SU2-axe.png'), p.image.load('SU1-axe.png'), p.image.load('SU2-axe.png'), p.image.load('SU1-axe.png'), p.image.load('SU2-axe.png'), p.image.load('SU1-axe.png'), p.image.load('SU2-axe.png'), p.image.load('SU1-axe.png'), p.image.load('SU2-axe.png'), p.image.load('SU1-axe.png'), p.image.load('SU2-axe.png'), p.image.load('SU1-axe.png'), p.image.load('SU2-axe.png'), p.image.load('SU1-axe.png'), p.image.load('SU2-axe.png')]
attackUpGun = [p.image.load('SU1-gun.png'), p.image.load('SU2-gun.png'), p.image.load('SU1-gun.png'), p.image.load('SU2-gun.png'), p.image.load('SU1-gun.png'), p.image.load('SU2-gun.png'), p.image.load('SU1-gun.png'), p.image.load('SU2-gun.png'), p.image.load('SU1-gun.png'), p.image.load('SU2-gun.png'), p.image.load('SU1-gun.png'), p.image.load('SU2-gun.png'), p.image.load('SU1-gun.png'), p.image.load('SU2-gun.png'), p.image.load('SU1-gun.png'), p.image.load('SU2-gun.png'), p.image.load('SU1-gun.png'), p.image.load('SU2-gun.png'), p.image.load('SU1-gun.png'), p.image.load('SU2-gun.png')]
attackUpNuke = [p.image.load('SU1-nuke.png'), p.image.load('SU2-nuke.png'), p.image.load('SU1-nuke.png'), p.image.load('SU2-nuke.png'), p.image.load('SU1-nuke.png'), p.image.load('SU2-nuke.png'), p.image.load('SU1-nuke.png'), p.image.load('SU2-nuke.png'), p.image.load('SU1-nuke.png'), p.image.load('SU2-nuke.png'), p.image.load('SU1-nuke.png'), p.image.load('SU2-nuke.png'), p.image.load('SU1-nuke.png'), p.image.load('SU2-nuke.png'), p.image.load('SU1-nuke.png'), p.image.load('SU2-nuke.png'), p.image.load('SU1-nuke.png'), p.image.load('SU2-nuke.png'), p.image.load('SU1-nuke.png'), p.image.load('SU2-nuke.png')]
attackDownDagger = [p.image.load('SD1-dagger.png'), p.image.load('SD2-dagger.png'), p.image.load('SD1-dagger.png'), p.image.load('SD2-dagger.png'), p.image.load('SD1-dagger.png'), p.image.load('SD2-dagger.png'), p.image.load('SD1-dagger.png'), p.image.load('SD2-dagger.png'), p.image.load('SD1-dagger.png'), p.image.load('SD2-dagger.png'), p.image.load('SD1-dagger.png'), p.image.load('SD2-dagger.png'), p.image.load('SD1-dagger.png'), p.image.load('SD2-dagger.png'), p.image.load('SD1-dagger.png'), p.image.load('SD2-dagger.png'), p.image.load('SD1-dagger.png'), p.image.load('SD2-dagger.png'), p.image.load('SD1-dagger.png'), p.image.load('SD2-dagger.png')]
attackDownTrident = [p.image.load('SD1-trident.png'), p.image.load('SD2-trident.png'), p.image.load('SD1-trident.png'), p.image.load('SD2-trident.png'), p.image.load('SD1-trident.png'), p.image.load('SD2-trident.png'), p.image.load('SD1-trident.png'), p.image.load('SD2-trident.png'), p.image.load('SD1-trident.png'), p.image.load('SD2-trident.png'), p.image.load('SD1-trident.png'), p.image.load('SD2-trident.png'), p.image.load('SD1-trident.png'), p.image.load('SD2-trident.png'), p.image.load('SD1-trident.png'), p.image.load('SD2-trident.png'), p.image.load('SD1-trident.png'), p.image.load('SD2-trident.png'), p.image.load('SD1-trident.png'), p.image.load('SD2-trident.png')]
attackDownSword = [p.image.load('SD1-sword.png'), p.image.load('SD2-sword.png'), p.image.load('SD1-sword.png'), p.image.load('SD2-sword.png'), p.image.load('SD1-sword.png'), p.image.load('SD2-sword.png'), p.image.load('SD1-sword.png'), p.image.load('SD2-sword.png'), p.image.load('SD1-sword.png'), p.image.load('SD2-sword.png'), p.image.load('SD1-sword.png'), p.image.load('SD2-sword.png'), p.image.load('SD1-sword.png'), p.image.load('SD2-sword.png'), p.image.load('SD1-sword.png'), p.image.load('SD2-sword.png'), p.image.load('SD1-sword.png'), p.image.load('SD2-sword.png'), p.image.load('SD1-sword.png'), p.image.load('SD2-sword.png')]
attackDownAxe = [p.image.load('SD1-axe.png'), p.image.load('SD2-axe.png'), p.image.load('SD1-axe.png'), p.image.load('SD2-axe.png'), p.image.load('SD1-axe.png'), p.image.load('SD2-axe.png'), p.image.load('SD1-axe.png'), p.image.load('SD2-axe.png'), p.image.load('SD1-axe.png'), p.image.load('SD2-axe.png'), p.image.load('SD1-axe.png'), p.image.load('SD2-axe.png'), p.image.load('SD1-axe.png'), p.image.load('SD2-axe.png'), p.image.load('SD1-axe.png'), p.image.load('SD2-axe.png'), p.image.load('SD1-axe.png'), p.image.load('SD2-axe.png'), p.image.load('SD1-axe.png'), p.image.load('SD2-axe.png')]
attackDownGun = [p.image.load('SD1-gun.png'), p.image.load('SD2-gun.png'), p.image.load('SD1-gun.png'), p.image.load('SD2-gun.png'), p.image.load('SD1-gun.png'), p.image.load('SD2-gun.png'), p.image.load('SD1-gun.png'), p.image.load('SD2-gun.png'), p.image.load('SD1-gun.png'), p.image.load('SD2-gun.png'), p.image.load('SD1-gun.png'), p.image.load('SD2-gun.png'), p.image.load('SD1-gun.png'), p.image.load('SD2-gun.png'), p.image.load('SD1-gun.png'), p.image.load('SD2-gun.png'), p.image.load('SD1-gun.png'), p.image.load('SD2-gun.png'), p.image.load('SD1-gun.png'), p.image.load('SD2-gun.png')]
attackDownNuke = [p.image.load('SD1-nuke.png'), p.image.load('SD2-nuke.png'), p.image.load('SD1-nuke.png'), p.image.load('SD2-nuke.png'), p.image.load('SD1-nuke.png'), p.image.load('SD2-nuke.png'), p.image.load('SD1-nuke.png'), p.image.load('SD2-nuke.png'), p.image.load('SD1-nuke.png'), p.image.load('SD2-nuke.png'), p.image.load('SD1-nuke.png'), p.image.load('SD2-nuke.png'), p.image.load('SD1-nuke.png'), p.image.load('SD2-nuke.png'), p.image.load('SD1-nuke.png'), p.image.load('SD2-nuke.png'), p.image.load('SD1-nuke.png'), p.image.load('SD2-nuke.png'), p.image.load('SD1-nuke.png'), p.image.load('SD2-nuke.png')]
attackRightDagger = [p.image.load('SwingR1-dagger.png'), p.image.load('SwingR2-dagger.png'), p.image.load('SwingR1-dagger.png'), p.image.load('SwingR2-dagger.png'), p.image.load('SwingR1-dagger.png'), p.image.load('SwingR2-dagger.png'), p.image.load('SwingR1-dagger.png'), p.image.load('SwingR2-dagger.png'), p.image.load('SwingR1-dagger.png'), p.image.load('SwingR2-dagger.png'), p.image.load('SwingR1-dagger.png'), p.image.load('SwingR2-dagger.png'), p.image.load('SwingR1-dagger.png'), p.image.load('SwingR2-dagger.png'), p.image.load('SwingR1-dagger.png'), p.image.load('SwingR2-dagger.png'), p.image.load('SwingR1-dagger.png'), p.image.load('SwingR2-dagger.png'), p.image.load('SwingR1-dagger.png'), p.image.load('SwingR2-dagger.png')]
attackRightTrident = [p.image.load('SwingR1-trident.png'), p.image.load('SwingR2-trident.png'), p.image.load('SwingR1-trident.png'), p.image.load('SwingR2-trident.png'), p.image.load('SwingR1-trident.png'), p.image.load('SwingR2-trident.png'), p.image.load('SwingR1-trident.png'), p.image.load('SwingR2-trident.png'), p.image.load('SwingR1-trident.png'), p.image.load('SwingR2-trident.png'), p.image.load('SwingR1-trident.png'), p.image.load('SwingR2-trident.png'), p.image.load('SwingR1-trident.png'), p.image.load('SwingR2-trident.png'), p.image.load('SwingR1-trident.png'), p.image.load('SwingR2-trident.png'), p.image.load('SwingR1-trident.png'), p.image.load('SwingR2-trident.png'), p.image.load('SwingR1-trident.png'), p.image.load('SwingR2-trident.png')]
attackRightSword = [p.image.load('SwingR1-sword.png'), p.image.load('SwingR2-sword.png'), p.image.load('SwingR1-sword.png'), p.image.load('SwingR2-sword.png'), p.image.load('SwingR1-sword.png'), p.image.load('SwingR2-sword.png'), p.image.load('SwingR1-sword.png'), p.image.load('SwingR2-sword.png'), p.image.load('SwingR1-sword.png'), p.image.load('SwingR2-sword.png'), p.image.load('SwingR1-sword.png'), p.image.load('SwingR2-sword.png'), p.image.load('SwingR1-sword.png'), p.image.load('SwingR2-sword.png'), p.image.load('SwingR1-sword.png'), p.image.load('SwingR2-sword.png'), p.image.load('SwingR1-sword.png'), p.image.load('SwingR2-sword.png'), p.image.load('SwingR1-sword.png'), p.image.load('SwingR2-sword.png')]
attackRightAxe = [p.image.load('SwingR1-axe.png'), p.image.load('SwingR2-axe.png'), p.image.load('SwingR1-axe.png'), p.image.load('SwingR2-axe.png'), p.image.load('SwingR1-axe.png'), p.image.load('SwingR2-axe.png'), p.image.load('SwingR1-axe.png'), p.image.load('SwingR2-axe.png'), p.image.load('SwingR1-axe.png'), p.image.load('SwingR2-axe.png'), p.image.load('SwingR1-axe.png'), p.image.load('SwingR2-axe.png'), p.image.load('SwingR1-axe.png'), p.image.load('SwingR2-axe.png'), p.image.load('SwingR1-axe.png'), p.image.load('SwingR2-axe.png'), p.image.load('SwingR1-axe.png'), p.image.load('SwingR2-axe.png'), p.image.load('SwingR1-axe.png'), p.image.load('SwingR2-axe.png')]
attackRightGun = [p.image.load('SwingR1-gun.png'), p.image.load('SwingR2-gun.png'), p.image.load('SwingR1-gun.png'), p.image.load('SwingR2-gun.png'), p.image.load('SwingR1-gun.png'), p.image.load('SwingR2-gun.png'), p.image.load('SwingR1-gun.png'), p.image.load('SwingR2-gun.png'), p.image.load('SwingR1-gun.png'), p.image.load('SwingR2-gun.png'), p.image.load('SwingR1-gun.png'), p.image.load('SwingR2-gun.png'), p.image.load('SwingR1-gun.png'), p.image.load('SwingR2-gun.png'), p.image.load('SwingR1-gun.png'), p.image.load('SwingR2-gun.png'), p.image.load('SwingR1-gun.png'), p.image.load('SwingR2-gun.png'), p.image.load('SwingR1-gun.png'), p.image.load('SwingR2-gun.png')]
attackRightNuke = [p.image.load('SwingR1-nuke.png'), p.image.load('SwingR2-nuke.png'), p.image.load('SwingR1-nuke.png'), p.image.load('SwingR2-nuke.png'), p.image.load('SwingR1-nuke.png'), p.image.load('SwingR2-nuke.png'), p.image.load('SwingR1-nuke.png'), p.image.load('SwingR2-nuke.png'), p.image.load('SwingR1-nuke.png'), p.image.load('SwingR2-nuke.png'), p.image.load('SwingR1-nuke.png'), p.image.load('SwingR2-nuke.png'), p.image.load('SwingR1-nuke.png'), p.image.load('SwingR2-nuke.png'), p.image.load('SwingR1-nuke.png'), p.image.load('SwingR2-nuke.png'), p.image.load('SwingR1-nuke.png'), p.image.load('SwingR2-nuke.png'), p.image.load('SwingR1-nuke.png'), p.image.load('SwingR2-nuke.png')]
attackLeftDagger = [p.image.load('SL1-dagger.png'), p.image.load('SL2-dagger.png'), p.image.load('SL1-dagger.png'), p.image.load('SL2-dagger.png'), p.image.load('SL1-dagger.png'), p.image.load('SL2-dagger.png'), p.image.load('SL1-dagger.png'), p.image.load('SL2-dagger.png'), p.image.load('SL1-dagger.png'), p.image.load('SL2-dagger.png'), p.image.load('SL1-dagger.png'), p.image.load('SL2-dagger.png'), p.image.load('SL1-dagger.png'), p.image.load('SL2-dagger.png'), p.image.load('SL1-dagger.png'), p.image.load('SL2-dagger.png'), p.image.load('SL1-dagger.png'), p.image.load('SL2-dagger.png'), p.image.load('SL1-dagger.png'), p.image.load('SL2-dagger.png')]
attackLeftTrident = [p.image.load('SL1-trident.png'), p.image.load('SL2-trident.png'), p.image.load('SL1-trident.png'), p.image.load('SL2-trident.png'), p.image.load('SL1-trident.png'), p.image.load('SL2-trident.png'), p.image.load('SL1-trident.png'), p.image.load('SL2-trident.png'), p.image.load('SL1-trident.png'), p.image.load('SL2-trident.png'), p.image.load('SL1-trident.png'), p.image.load('SL2-trident.png'), p.image.load('SL1-trident.png'), p.image.load('SL2-trident.png'), p.image.load('SL1-trident.png'), p.image.load('SL2-trident.png'), p.image.load('SL1-trident.png'), p.image.load('SL2-trident.png'), p.image.load('SL1-trident.png'), p.image.load('SL2-trident.png')]
attackLeftSword = [p.image.load('SL1-sword.png'), p.image.load('SL2-sword.png'), p.image.load('SL1-sword.png'), p.image.load('SL2-sword.png'), p.image.load('SL1-sword.png'), p.image.load('SL2-sword.png'), p.image.load('SL1-sword.png'), p.image.load('SL2-sword.png'), p.image.load('SL1-sword.png'), p.image.load('SL2-sword.png'), p.image.load('SL1-sword.png'), p.image.load('SL2-sword.png'), p.image.load('SL1-sword.png'), p.image.load('SL2-sword.png'), p.image.load('SL1-sword.png'), p.image.load('SL2-sword.png'), p.image.load('SL1-sword.png'), p.image.load('SL2-sword.png'), p.image.load('SL1-sword.png'), p.image.load('SL2-sword.png')]
attackLeftAxe = [p.image.load('SL1-axe.png'), p.image.load('SL2-axe.png'), p.image.load('SL1-axe.png'), p.image.load('SL2-axe.png'), p.image.load('SL1-axe.png'), p.image.load('SL2-axe.png'), p.image.load('SL1-axe.png'), p.image.load('SL2-axe.png'), p.image.load('SL1-axe.png'), p.image.load('SL2-axe.png'), p.image.load('SL1-axe.png'), p.image.load('SL2-axe.png'), p.image.load('SL1-axe.png'), p.image.load('SL2-axe.png'), p.image.load('SL1-axe.png'), p.image.load('SL2-axe.png'), p.image.load('SL1-axe.png'), p.image.load('SL2-axe.png'), p.image.load('SL1-axe.png'), p.image.load('SL2-axe.png')]
attackLeftGun = [p.image.load('SL1-gun.png'), p.image.load('SL2-gun.png'), p.image.load('SL1-gun.png'), p.image.load('SL2-gun.png'), p.image.load('SL1-gun.png'), p.image.load('SL2-gun.png'), p.image.load('SL1-gun.png'), p.image.load('SL2-gun.png'), p.image.load('SL1-gun.png'), p.image.load('SL2-gun.png'), p.image.load('SL1-gun.png'), p.image.load('SL2-gun.png'), p.image.load('SL1-gun.png'), p.image.load('SL2-gun.png'), p.image.load('SL1-gun.png'), p.image.load('SL2-gun.png'), p.image.load('SL1-gun.png'), p.image.load('SL2-gun.png'), p.image.load('SL1-gun.png'), p.image.load('SL2-gun.png')]
attackLeftNuke = [p.image.load('SL1-nuke.png'), p.image.load('SL2-nuke.png'), p.image.load('SL1-nuke.png'), p.image.load('SL2-nuke.png'), p.image.load('SL1-nuke.png'), p.image.load('SL2-nuke.png'), p.image.load('SL1-nuke.png'), p.image.load('SL2-nuke.png'), p.image.load('SL1-nuke.png'), p.image.load('SL2-nuke.png'), p.image.load('SL1-nuke.png'), p.image.load('SL2-nuke.png'), p.image.load('SL1-nuke.png'), p.image.load('SL2-nuke.png'), p.image.load('SL1-nuke.png'), p.image.load('SL2-nuke.png'), p.image.load('SL1-nuke.png'), p.image.load('SL2-nuke.png'), p.image.load('SL1-nuke.png'), p.image.load('SL2-nuke.png')]
Floor1Room1 = p.image.load('F1R1.png')
Floor1Room2 = p.image.load('F1R2.png')
Floor1Room3 = p.image.load('F1R2.png')
Floor1Room4 = p.image.load('F1R2.png')
Floor1Room5 = p.image.load('F1R5.png')
Floor2Room1 = p.image.load('F1R1.png')
Floor2Room2 = p.image.load('F1R2.png')
Floor2Room3 = p.image.load('F2R3.png')
SecretRoom = p.image.load('SR1.png')
Floor2Room4 = p.image.load('F1R2.png')
Floor2Room5 = p.image.load('F1R5.png')
Floor3Room1 = p.image.load('F1R1.png')
Floor3Room2 = p.image.load('F1R2.png')
Floor3Room3 = p.image.load('F1R2.png')
Floor3Room4 = p.image.load('F1R2.png')
Floor3Room5 = p.image.load('F1R5.png')
Surface = p.image.load('Surface.png')
chara = p.image.load('D1.png')
spr_dagger = p.image.load('Dagger1.png')
spr_trident = p.image.load('Trident1.png')
spr_sword = p.image.load('Sword1.png')
spr_axe = p.image.load('Axe1.png')
spr_gun = p.image.load('AK47-1.png')
spr_nuke = p.image.load('Nuke1.png')
spr_herb = p.image.load('Healing Herb 1.png')
spr_potion = p.image.load('Potion1.png')
spr_water = p.image.load('Fresh Water 1.png')
spr_super_potion = p.image.load('Super Potion 1.png')
spr_omega_potion = p.image.load('Omega Potion 1.png')
spr_epic_potion = p.image.load('Epic Potion 1.png')
spr_two_times = p.image.load('Two Times 1.png')
spr_amulet = p.image.load('Amulet1.png')
spr_wood_shield = p.image.load('Wood Shield 1.png')
spr_metal_shield = p.image.load('Metal Shield 1.png')
#spr_kevlar_vest = p.image.load('Kevlar Vest 1.png')
inventory = []
#Spawning random items for each room and luck level
itemsF1R1 = ['trident','trident', 'trident', 'trident','trident', 'trident', 'trident', 'trident', 'trident', 'trident', 'trident', 'trident', 'trident', 'trident', 'trident', 'trident', 'trident', 'trident', 'trident', 'trident', 'trident', 'trident', 'trident', 'trident', 'trident', 'trident', 'trident', 'trident', 'trident', 'dagger', 'dagger', 'dagger', 'dagger', 'dagger', 'dagger', 'dagger', 'sword', 'sword', 'sword', 'sword', 'sword', 'axe', 'axe', 'axe', 'axe', 'axe', 'gun', 'dagger', 'dagger', 'dagger', 'dagger', 'dagger', 'dagger', 'dagger', 'sword', 'sword', 'sword', 'sword', 'sword', 'axe', 'axe', 'axe', 'axe', 'axe', 'gun', 'dagger', 'dagger', 'dagger', 'dagger', 'dagger', 'dagger', 'dagger', 'sword', 'sword', 'sword', 'sword', 'sword', 'axe', 'axe', 'axe', 'axe', 'axe', 'gun', 'nuke']
itemSpawned1 = r.choice(itemsF1R1)
itemsF1R3 = ['healing_herb', 'healing_herb', 'healing_herb', 'healing_herb', 'healing_herb', 'healing_herb', 'potion', 'potion', 'potion', 'potion', 'fresh_water', 'amulet', 'amulet', 'amulet', 'wood_shield', 'wood_shield', 'wood_shield', 'wood_shield']
itemSpawned2 = r.choice(itemsF1R3)
itemsF1R5 = ['healing_herb', 'healing_herb', 'healing_herb', 'potion', 'potion', 'fresh_water', 'amulet', 'wood_shield']
itemSpawned3 = r.choice(itemsF1R5)
itemsLuck1F1R5 = ['healing_herb', 'healing_herb', 'potion', 'potion', 'fresh_water', 'amulet', 'wood_shield']
itemLuck1Spawned3 = r.choice(itemsLuck1F1R5)
itemsLuck2F1R5 = ['healing_herb', 'healing_herb', 'potion', 'potion', 'potion', 'fresh_water', 'amulet', 'wood_shield']
itemLuck2Spawned3 = r.choice(itemsLuck2F1R5)
itemsLuck3F1R5 = ['healing_herb', 'potion', 'potion', 'fresh_water', 'fresh_water', 'amulet', 'wood_shield']
itemLuck3Spawned3 = r.choice(itemsLuck3F1R5)
itemsF2R1 = ['healing_herb', 'healing_herb', 'healing_herb', 'healing_herb', 'healing_herb', 'potion', 'potion', 'potion', 'potion', 'super_potion', 'metal_shield']
itemSpawned4 = r.choice(itemsF2R1)
itemsLuck1F2R1 = ['healing_herb', 'healing_herb', 'healing_herb', 'healing_herb', 'potion', 'potion', 'potion', 'potion', 'super_potion']
itemLuck1Spawned4 = r.choice(itemsLuck1F2R1)
itemsLuck2F2R1 = ['healing_herb', 'healing_herb', 'healing_herb', 'healing_herb', 'potion', 'potion', 'potion', 'potion', 'super_potion', 'super_potion']
itemLuck2Spawned4 = r.choice(itemsLuck2F2R1)
itemsLuck3F2R1 = ['healing_herb', 'healing_herb', 'potion', 'potion', 'potion', 'potion', 'super_potion', 'super_potion', 'super_potion']
itemLuck3Spawned4 = r.choice(itemsLuck3F2R1)
itemsF2R3 = ['healing_herb', 'healing_herb', 'healing_herb', 'potion', 'potion', 'super_potion', 'metal_shield']
itemSpawned5 = r.choice(itemsF2R3)
itemsLuck1F2R3 = ['healing_herb', 'healing_herb', 'potion', 'potion', 'super_potion', 'metal_shield']
itemLuck1Spawned5 = r.choice(itemsLuck1F2R3)
itemsLuck2F2R3 = ['healing_herb', 'potion', 'potion', 'super_potion']
itemLuck2Spawned5 = r.choice(itemsLuck2F2R3)
itemsLuck3F2R3 = ['healing_herb', 'healing_herb', 'potion', 'potion', 'potion', 'super_potion', 'super_potion']
itemLuck3Spawned5 = r.choice(itemsLuck3F2R3)
itemsSR1 = ['two_times', 'two_times', 'omega_potion', 'omega_potion', 'omega_potion', 'epic_potion', 'metal_shield', 'metal_shield']
itemSpawned6 = r.choice(itemsSR1)
itemsLuck1SR1 = ['two_times', 'two_times', 'omega_potion', 'omega_potion', 'epic_potion']
itemLuck1Spawned6 = r.choice(itemsLuck1SR1)
itemsLuck2SR1 = ['two_times', 'two_times', 'omega_potion', 'omega_potion', 'epic_potion', 'epic_potion']
itemLuck2Spawned6 = r.choice(itemsLuck2SR1)
itemsLuck3SR1 = ['two_times', 'two_times', 'two_times', 'omega_potion', 'omega_potion', 'omega_potion', 'epic_potion', 'epic_potion']
itemLuck3Spawned6 = r.choice(itemsLuck3SR1)
itemsF2R5 = ['healing_herb', 'healing_herb', 'healing_herb', 'potion', 'potion', 'potion', 'potion', 'potion', 'super_potion', 'super_potion', 'omega_potion', 'metal_shield']
itemSpawned7 = r.choice(itemsF2R5)
itemsLuck1F2R5 = ['healing_herb', 'healing_herb', 'potion', 'potion', 'potion', 'potion', 'potion', 'super_potion', 'super_potion', 'super_potion', 'omega_potion']
itemLuck1Spawned7 = r.choice(itemsLuck1F2R5)
itemsLuck2F2R5 = ['healing_herb', 'healing_herb', 'healing_herb', 'potion', 'potion', 'potion', 'potion', 'potion', 'potion', 'potion', 'super_potion', 'super_potion', 'super_potion', 'omega_potion']
itemLuck2Spawned7 = r.choice(itemsLuck2F2R5)
itemsLuck3F2R5 = ['healing_herb', 'healing_herb', 'healing_herb', 'potion', 'potion', 'potion', 'potion', 'potion', 'super_potion', 'super_potion', 'omega_potion', 'omega_potion', 'omega_potion']
itemLuck3Spawned7 = r.choice(itemsLuck3F2R5)
itemsF3R1 = ['healing_herb', 'healing_herb', 'potion', 'potion', 'potion', 'potion', 'potion', 'potion', 'potion', 'super_potion', 'super_potion', 'super_potion', 'omega_potion']
itemSpawned8 = r.choice(itemsF3R1)
itemsLuck1F3R1 = ['healing_herb', 'potion', 'potion', 'potion', 'potion', 'potion', 'potion', 'super_potion', 'super_potion', 'super_potion', 'omega_potion']
itemLuck1Spawned8 = r.choice(itemsLuck1F3R1)
itemsLuck2F3R1 = ['healing_herb', 'healing_herb', 'potion', 'potion', 'potion', 'potion', 'potion', 'potion', 'potion', 'super_potion', 'super_potion', 'super_potion', 'super_potion', 'omega_potion', 'omega_potion']
itemLuck2Spawned8 = r.choice(itemsLuck2F3R1)
itemsLuck3F3R1 = ['healing_herb', 'potion', 'potion', 'potion', 'potion', 'potion', 'potion', 'super_potion', 'super_potion', 'super_potion', 'omega_potion', 'omega_potion']
itemLuck3Spawned8 = r.choice(itemsLuck3F3R1)
itemsF3R3 = ['potion', 'potion', 'potion', 'super_potion', 'super_potion', 'super_potion', 'omega_potion', 'omega_potion']
itemSpawned9 = r.choice(itemsF3R3)
itemsLuck1F3R3 = ['potion', 'potion', 'super_potion', 'super_potion', 'super_potion', 'omega_potion', 'omega_potion']
itemLuck1Spawned9 = r.choice(itemsLuck1F3R3)
itemsLuck2F3R3 = ['potion', 'super_potion', 'super_potion', 'omega_potion', 'omega_potion']
itemLuck2Spawned9 = r.choice(itemsLuck2F3R3)
itemsLuck3F3R3 = ['potion', 'potion', 'super_potion', 'super_potion', 'omega_potion', 'omega_potion', 'omega_potion']
itemLuck3Spawned9 = r.choice(itemsLuck3F3R3)
itemsF3R4 = ['super_potion', 'super_potion', 'super_potion', 'super_potion', 'super_potion', 'super_potion', 'omega_potion', 'omega_potion', 'epic_potion']
itemSpawned10 = r.choice(itemsF3R4)
itemsLuck1F3R4 = ['super_potion', 'super_potion', 'super_potion', 'super_potion', 'super_potion', 'omega_potion', 'omega_potion', 'epic_potion']
itemLuck1Spawned10 = r.choice(itemsLuck1F3R4)
itemsLuck2F3R4 = ['super_potion', 'super_potion', 'super_potion', 'omega_potion', 'omega_potion', 'epic_potion']
itemLuck2Spawned10 = r.choice(itemsLuck2F3R4)
itemsLuck3F3R4 = ['super_potion', 'super_potion', 'omega_potion', 'omega_potion', 'epic_potion', 'epic_potion']
itemLuck3Spawned10 = r.choice(itemsLuck3F3R4)
#Setting the enemy HP and dmg (also the dmg for every weapon in the game)
healing_herb_healed=25
potion_healed=50
fresh_water_healed=75
super_potion_healed=100
omega_potion_healed=150
epic_potion_healed=250
mini_devil_health=30
devil1_health=50
devil2_health=50
zombie1_health=75
zombie2_health=75
toure_health=200
satan_health=325
mini_devil_dmg=25
devil1_dmg=40
devil2_dmg=40
zombie1_dmg=90
zombie2_dmg=90
toure_dmg=100
satan_dmg=150
no_weapon=0
dmg_dagger=30
dmg_trident=40
dmg_sword=50
dmg_axe=75
dmg_AK47=150
dmg_Nuke=500000000
def_wood_shield=15
def_metal_shield=25
def_kevlar_vest=60
#Making a clock to set the frame rate
clock = p.time.Clock()
n=0
w=1
t=1
t1=1
t2=1
t3=1
t4=1
t5=1
t6=1
t7=1
t8=1
a=1
a1=1
a2=1
a3=1
a4=1
a5=1
a6=1
x=350
y=275
itm_spwn_x=350
itm_spwn_y=325
pickupCount0=0
pickupCount=0
pickupCount1=0
pickupCount2=0
pickupCount3=0
pickupCount4=0
pickupCount5=0
pickupCount6=0
pickupCount7=0
pickupCount8=0
attackCount=0
attackCount1=0
attackCount2=0
attackCount3=0
attackCount4=0
attackCount5=0
attackCount6=0
minidevilCount=0
devilCount=0
devilCount1=0
zombieCount=0
zombieCount1=0
toureCount=0
satanCount=0
enemy_x=425
enemy_y=250
chara_width=64
chara_height=64
vel=5
luck=0
player_health=100
player_defense=0
white = (255, 255, 255)
black = (0, 0, 0)
red = (255, 0, 0)
#My functions used thru the whole program
def init_display():
    """
    set up the pygame display, full screen
    """

    # Check which frame buffer drivers are available
    # Start with fbcon since directfb hangs with composite output
    drivers = ['fbcon', 'directfb', 'svgalib', 'directx', 'windib']
    found = False
    for driver in drivers:
        # Make sure that SDL_VIDEODRIVER is set
        if not os.getenv('SDL_VIDEODRIVER'):
            os.putenv('SDL_VIDEODRIVER', driver)
        try:
            p.display.init()
        except p.error:
            #  logging.warn('Driver: %s failed.' % driver)
            continue
        found = True
        l.debug('using %s driver', driver)
        break

    if not found:
        raise Exception('No suitable video driver found!')

    size = (p.display.Info().current_w, p.display.Info().current_h)
    p.mouse.set_visible(0)
    if driver != 'directx':  # debugging hack runs in a window on Windows
        screen = p.display.set_mode(size, p.FULLSCREEN)
    else:
        l.info('running in windowed mode')
        # set window origin for windowed usage
        os.putenv('SDL_VIDEO_WINDOW_POS', '0,0')
        # size = (size[0]-10, size[1] - 30)
        screen = p.display.set_mode(size, p.NOFRAME)

    l.debug('display size: %d x %d', size[0], size[1])
    return screen, size
def gameOver():
    game_over = p.freetype.Font("Raleway-BlackItalic.ttf", 36)
    game_over.render_to(win, (275, 250), "Game OVER...", (red))
def level_1():
    global walkCount
    global w
    global pickupCount0
    win.blit(Floor1Room1, (0,0))
    room_title1 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
    room_title1.render_to(win, (325, 10), "Floor 1 Room 1", (black))
    health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
    defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
    luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
    dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    if 'dagger' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
    elif 'trident' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
    elif 'sword' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
    elif 'axe' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
    elif 'gun' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
    elif 'nuke' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
    else:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))

    if walkCount + 1 >= 60:
        walkCount = 0

    if left:
        win.blit(walkLeft[walkCount//3], (x,y))
        walkCount += 1
    elif right:
        win.blit(walkRight[walkCount//3], (x,y))
        walkCount += 1
    elif up:
        win.blit(walkUp[walkCount//3], (x,y))
        walkCount += 1
    elif down:
        win.blit(walkDown[walkCount//3], (x,y))
        walkCount += 1
    else:
        win.blit(chara, (x, y))
    if w == 1:
        if itemSpawned1 == 'dagger':
            win.blit(spr_dagger, (itm_spwn_x, itm_spwn_y))
            if (x >= 286 and x <= 414) and (y >= 261 and y <= 389):
                inventory.append('dagger')
                m.music.load('item-get.mp3')
                m.music.play()
                w=w-1
        elif itemSpawned1 == 'trident':
            win.blit(spr_trident, (itm_spwn_x, itm_spwn_y))
            if (x >= 286 and x <= 414) and (y >= 261 and y <= 389):
                inventory.append('trident')
                m.music.load('item-get.mp3')
                m.music.play()
                w=w-1
        elif itemSpawned1 == 'sword':
            win.blit(spr_sword, (itm_spwn_x, itm_spwn_y))
            if (x >= 286 and x <= 414) and (y >= 261 and y <= 389):
                inventory.append('sword')
                m.music.load('item-get.mp3')
                m.music.play()
                w=w-1
        elif itemSpawned1 == 'axe':
            win.blit(spr_axe, (itm_spwn_x, itm_spwn_y))
            if (x >= 286 and x <= 414) and (y >= 261 and y <= 389):
                inventory.append('axe')
                m.music.load('item-get.mp3')
                m.music.play()
                w=w-1
        elif itemSpawned1 == 'gun':
            win.blit(spr_gun, (itm_spwn_x, itm_spwn_y))
            if (x >= 286 and x <= 414) and (y >= 261 and y <= 389):
                inventory.append('gun')
                m.music.load('item-get.mp3')
                m.music.play()
                w=w-1
        elif itemSpawned1 == 'nuke':
            win.blit(spr_nuke, (itm_spwn_x, itm_spwn_y))
            if (x >= 286 and x <= 414) and (y >= 261 and y <= 389):
                inventory.append('nuke')
                m.music.load('item-get.mp3')
                m.music.play()
                w=w-1
    elif w == 0:
            win.fill(white)
            win.blit(Floor1Room1, (0,0))
            room_title3 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
            room_title3.render_to(win, (325, 10), "Floor 1 Room 1", (black))
            health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
            health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
            defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
            defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
            luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
            luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
            dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
            if 'dagger' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
            elif 'trident' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
            elif 'sword' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
            elif 'axe' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
            elif 'gun' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
            elif 'nuke' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
            else:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
            if pickupCount0 < 60:
                if itemSpawned1 == 'dagger':
                    win.blit(pickupDagger[pickupCount0//3], (x,y))
                    pickupCount0 += 1
                elif itemSpawned1 == 'trident':
                    win.blit(pickupTrident[pickupCount0//3], (x,y))
                    pickupCount0 += 1
                elif itemSpawned1 == 'sword':
                    win.blit(pickupSword[pickupCount0//3], (x,y))
                    pickupCount0 += 1
                elif itemSpawned1 == 'axe':
                    win.blit(pickupAxe[pickupCount0//3], (x,y))
                    pickupCount0 += 1
                elif itemSpawned1 == 'gun':
                    win.blit(pickupGun[pickupCount0//3], (x,y))
                    pickupCount0 += 1
                elif itemSpawned1 == 'nuke':
                    win.blit(pickupNuke[pickupCount0//3], (x,y))
                    pickupCount0 += 1
            elif pickupCount0 > 60:
                win.blit(chara, (x,y))
            if walkCount + 1 >= 60:
                walkCount = 0
            if left:
                win.blit(walkLeft[walkCount//3], (x,y))
                walkCount += 1
            elif right:
                win.blit(walkRight[walkCount//3], (x,y))
                walkCount += 1
            elif up:
                win.blit(walkUp[walkCount//3], (x,y))
                walkCount += 1
            elif down:
                win.blit(walkDown[walkCount//3], (x,y))
                walkCount += 1
            else:
                win.blit(chara, (x, y))
    p.display.update()
def level_2():
    global walkCount
    global minidevilCount
    global attackCount
    global mini_devil_health
    global player_health
    global a
    win.blit(Floor1Room2, (0,0))
    room_title2 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
    room_title2.render_to(win, (325, 10), "Floor 1 Room 2", (black))
    health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
    defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
    luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
    dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    if 'dagger' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
    elif 'trident' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
    elif 'sword' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
    elif 'axe' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
    elif 'gun' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
    elif 'nuke' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
    else:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))

    if walkCount + 1 >= 60:
        walkCount = 0

    if left:
        win.blit(walkLeft[walkCount//3], (x,y))
        walkCount += 1
    elif right:
        win.blit(walkRight[walkCount//3], (x,y))
        walkCount += 1
    elif up:
        win.blit(walkUp[walkCount//3], (x,y))
        walkCount += 1
    elif down:
        win.blit(walkDown[walkCount//3], (x,y))
        walkCount += 1
    else:
        win.blit(chara, (x, y))
    #Spawning set enemies
    if a == 1:
        if (x >= 400 and x <= 480) and (y >= 215 and y <= 265):
            if 'dagger' in inventory:
                if left == True:
                    win.blit(attackLeftDagger[attackCount//3], (x,y))
                    attackCount += 1
                    mini_devil_health=mini_devil_health-dmg_dagger
                    if mini_devil_health > 0:
                        if player_defense == 0:
                            player_health=player_health-mini_devil_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*mini_devil_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount >= 60:
                        attackCount=0
                elif right == True:
                    win.blit(attackRightDagger[attackCount//3], (x,y))
                    attackCount += 1
                    mini_devil_health=mini_devil_health-dmg_dagger
                    if mini_devil_health > 0:
                        if player_defense == 0:
                            player_health=player_health-mini_devil_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*mini_devil_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount >= 60:
                        attackCount=0
                elif up == True:
                    win.blit(attackUpDagger[attackCount//3], (x,y))
                    attackCount += 1
                    mini_devil_health=mini_devil_health-dmg_dagger
                    if mini_devil_health > 0:
                        if player_defense == 0:
                            player_health=player_health-mini_devil_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*mini_devil_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount >= 60:
                        attackCount=0
                elif down == True:
                    win.blit(attackDownDagger[attackCount//3], (x,y))
                    attackCount += 1
                    mini_devil_health=mini_devil_health-dmg_dagger
                    if mini_devil_health > 0:
                        if player_defense == 0:
                            player_health=player_health-mini_devil_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*mini_devil_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount >= 60:
                        attackCount=0
                else:
                    win.blit(attackDownDagger[attackCount//3], (x,y))
                    attackCount += 1
                    mini_devil_health=mini_devil_health-dmg_dagger
                    if mini_devil_health > 0:
                        if player_defense == 0:
                            player_health=player_health-mini_devil_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*mini_devil_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount >= 60:
                        attackCount=0
            elif 'trident' in inventory:
                if left == True:
                    win.blit(attackLeftTrident[attackCount//3], (x,y))
                    attackCount += 1
                    mini_devil_health=mini_devil_health-dmg_trident
                    if mini_devil_health > 0:
                        if player_defense == 0:
                            player_health=player_health-mini_devil_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*mini_devil_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount >= 60:
                        attackCount=0
                elif right == True:
                    win.blit(attackRightTrident[attackCount//3], (x,y))
                    attackCount += 1
                    mini_devil_health=mini_devil_health-dmg_trident
                    if mini_devil_health > 0:
                        if player_defense == 0:
                            player_health=player_health-mini_devil_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*mini_devil_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount >= 60:
                        attackCount=0
                elif up == True:
                    win.blit(attackUpTrident[attackCount//3], (x,y))
                    attackCount += 1
                    mini_devil_health=mini_devil_health-dmg_trident
                    if mini_devil_health > 0:
                        if player_defense == 0:
                            player_health=player_health-mini_devil_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*mini_devil_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount >= 60:
                        attackCount=0
                elif down == True:
                    win.blit(attackDownTrident[attackCount//3], (x,y))
                    attackCount += 1
                    mini_devil_health=mini_devil_health-dmg_trident
                    if mini_devil_health > 0:
                        if player_defense == 0:
                            player_health=player_health-mini_devil_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*mini_devil_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount >= 60:
                        attackCount=0
                else:
                    win.blit(attackDownTrident[attackCount//3], (x,y))
                    attackCount += 1
                    mini_devil_health=mini_devil_health-dmg_trident
                    if mini_devil_health > 0:
                        if player_defense == 0:
                            player_health=player_health-mini_devil_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*mini_devil_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount >= 60:
                        attackCount=0
            elif 'sword' in inventory:
                if left == True:
                    win.blit(attackLeftSword[attackCount//3], (x,y))
                    attackCount += 1
                    mini_devil_health=mini_devil_health-dmg_sword
                    if mini_devil_health > 0:
                        if player_defense == 0:
                            player_health=player_health-mini_devil_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*mini_devil_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount >= 60:
                        attackCount=0
                elif right == True:
                    win.blit(attackRightSword[attackCount//3], (x,y))
                    attackCount += 1
                    mini_devil_health=mini_devil_health-dmg_sword
                    if mini_devil_health > 0:
                        if player_defense == 0:
                            player_health=player_health-mini_devil_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*mini_devil_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount >= 60:
                        attackCount=0
                elif up == True:
                    win.blit(attackUpSword[attackCount//3], (x,y))
                    attackCount += 1
                    mini_devil_health=mini_devil_health-dmg_sword
                    if mini_devil_health > 0:
                        if player_defense == 0:
                            player_health=player_health-mini_devil_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*mini_devil_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount >= 60:
                        attackCount=0
                elif down == True:
                    win.blit(attackDownSword[attackCount//3], (x,y))
                    attackCount += 1
                    mini_devil_health=mini_devil_health-dmg_sword
                    if mini_devil_health > 0:
                        if player_defense == 0:
                            player_health=player_health-mini_devil_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*mini_devil_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount >= 60:
                        attackCount=0
                else:
                    win.blit(attackDownSword[attackCount//3], (x,y))
                    attackCount += 1
                    mini_devil_health=mini_devil_health-dmg_sword
                    if mini_devil_health > 0:
                        if player_defense == 0:
                            player_health=player_health-mini_devil_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*mini_devil_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount >= 60:
                        attackCount=0
            elif 'axe' in inventory:
                if left == True:
                    win.blit(attackLeftAxe[attackCount//3], (x,y))
                    attackCount += 1
                    mini_devil_health=mini_devil_health-dmg_axe
                    if mini_devil_health > 0:
                        if player_defense == 0:
                            player_health=player_health-mini_devil_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*mini_devil_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount >= 60:
                        attackCount=0
                elif right == True:
                    win.blit(attackRightAxe[attackCount//3], (x,y))
                    attackCount += 1
                    mini_devil_health=mini_devil_health-dmg_axe
                    if mini_devil_health > 0:
                        if player_defense == 0:
                            player_health=player_health-mini_devil_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*mini_devil_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount >= 60:
                        attackCount=0
                elif up == True:
                    win.blit(attackUpAxe[attackCount//3], (x,y))
                    attackCount += 1
                    mini_devil_health=mini_devil_health-dmg_axe
                    if mini_devil_health > 0:
                        if player_defense == 0:
                            player_health=player_health-mini_devil_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*mini_devil_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount >= 60:
                        attackCount=0
                elif down == True:
                    win.blit(attackDownAxe[attackCount//3], (x,y))
                    attackCount += 1
                    mini_devil_health=mini_devil_health-dmg_axe
                    if mini_devil_health > 0:
                        if player_defense == 0:
                            player_health=player_health-mini_devil_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*mini_devil_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount >= 60:
                        attackCount=0
                else:
                    win.blit(attackDownAxe[attackCount//3], (x,y))
                    attackCount += 1
                    mini_devil_health=mini_devil_health-dmg_axe
                    if mini_devil_health > 0:
                        if player_defense == 0:
                            player_health=player_health-mini_devil_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*mini_devil_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount >= 60:
                        attackCount=0
            elif 'gun' in inventory:
                if left == True:
                    win.blit(attackLeftGun[attackCount//3], (x,y))
                    attackCount += 1
                    mini_devil_health=mini_devil_health-dmg_AK47
                    if mini_devil_health > 0:
                        if player_defense == 0:
                            player_health=player_health-mini_devil_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*mini_devil_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount >= 60:
                        attackCount=0
                elif right == True:
                    win.blit(attackRightGun[attackCount//3], (x,y))
                    attackCount += 1
                    mini_devil_health=mini_devil_health-dmg_AK47
                    if mini_devil_health > 0:
                        if player_defense == 0:
                            player_health=player_health-mini_devil_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*mini_devil_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount >= 60:
                        attackCount=0
                elif up == True:
                    win.blit(attackUpGun[attackCount//3], (x,y))
                    attackCount += 1
                    mini_devil_health=mini_devil_health-dmg_AK47
                    if mini_devil_health > 0:
                        if player_defense == 0:
                            player_health=player_health-mini_devil_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*mini_devil_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount >= 60:
                        attackCount=0
                elif down == True:
                    win.blit(attackDownGun[attackCount//3], (x,y))
                    attackCount += 1
                    mini_devil_health=mini_devil_health-dmg_AK47
                    if mini_devil_health > 0:
                        if player_defense == 0:
                            player_health=player_health-mini_devil_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*mini_devil_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount >= 60:
                        attackCount=0
                else:
                    win.blit(attackDownGun[attackCount//3], (x,y))
                    attackCount += 1
                    mini_devil_health=mini_devil_health-dmg_AK47
                    if mini_devil_health > 0:
                        if player_defense == 0:
                            player_health=player_health-mini_devil_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*mini_devil_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount >= 60:
                        attackCount=0
            elif 'nuke' in inventory:
                if left == True:
                    win.blit(attackLeftNuke[attackCount//3], (x,y))
                    attackCount += 1
                    mini_devil_health=mini_devil_health-dmg_Nuke
                    if mini_devil_health > 0:
                        if player_defense == 0:
                            player_health=player_health-mini_devil_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*mini_devil_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount >= 60:
                        attackCount=0
                elif right == True:
                    win.blit(attackRightNuke[attackCount//3], (x,y))
                    attackCount += 1
                    mini_devil_health=mini_devil_health-dmg_Nuke
                    if mini_devil_health > 0:
                        if player_defense == 0:
                            player_health=player_health-mini_devil_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*mini_devil_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount >= 60:
                        attackCount=0
                elif up == True:
                    win.blit(attackUpNuke[attackCount//3], (x,y))
                    attackCount += 1
                    mini_devil_health=mini_devil_health-dmg_Nuke
                    if mini_devil_health > 0:
                        if player_defense == 0:
                            player_health=player_health-mini_devil_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*mini_devil_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount >= 60:
                        attackCount=0
                elif down == True:
                    win.blit(attackDownNuke[attackCount//3], (x,y))
                    attackCount += 1
                    mini_devil_health=mini_devil_health-dmg_Nuke
                    if mini_devil_health > 0:
                        if player_defense == 0:
                            player_health=player_health-mini_devil_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*mini_devil_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount >= 60:
                        attackCount=0
                else:
                    win.blit(attackDownNuke[attackCount//3], (x,y))
                    attackCount += 1
                    mini_devil_health=mini_devil_health-dmg_Nuke
                    if mini_devil_health > 0:
                        if player_defense == 0:
                            player_health=player_health-mini_devil_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*mini_devil_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount >= 60:
                        attackCount=0
    if mini_devil_health > 0:
        win.blit(MiniDevil[minidevilCount//3], (enemy_x, enemy_y))
        minidevil_health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 12)
        minidevil_health_bar.render_to(win, (450, 245), ("HP " + str(mini_devil_health)), (black))
        minidevilCount += 1           
        if minidevilCount == 60:
            minidevilCount=0
    elif mini_devil_health <= 0:
        a=a-1
        pass
    if player_health <= 0:
        gameOver()
    p.display.update()
def level_3():
    global walkCount
    global player_health
    global player_defense
    global healing_herb_healed
    global potion_healed
    global fresh_water_healed
    global luck
    global t
    global pickupCount
    global luck
    win.blit(Floor1Room3, (0,0))
    room_title3 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
    room_title3.render_to(win, (325, 10), "Floor 1 Room 3", (black))
    health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
    defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
    luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
    dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    if 'dagger' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
    elif 'trident' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
    elif 'sword' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
    elif 'axe' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
    elif 'gun' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
    elif 'nuke' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
    else:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))

    if walkCount + 1 >= 60:
        walkCount = 0

    if left:
        win.blit(walkLeft[walkCount//3], (x,y))
        walkCount += 1
    elif right:
        win.blit(walkRight[walkCount//3], (x,y))
        walkCount += 1
    elif up:
        win.blit(walkUp[walkCount//3], (x,y))
        walkCount += 1
    elif down:
        win.blit(walkDown[walkCount//3], (x,y))
        walkCount += 1
    else:
        win.blit(chara, (x, y))
    #Spawning items
    if itemSpawned2 == 'healing_herb':
        win.blit(spr_herb, (itm_spwn_x, itm_spwn_y))
        if t == 1:
            if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                player_health=player_health+healing_herb_healed
                m.music.load('item-get.mp3')
                m.music.play()
                t=t-1
        elif t == 0:
            win.fill(white)
            win.blit(Floor1Room3, (0,0))
            room_title3 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
            room_title3.render_to(win, (325, 10), "Floor 1 Room 3", (black))
            health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
            health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
            defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
            defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
            luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
            luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
            dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
            if 'dagger' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
            elif 'trident' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
            elif 'sword' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
            elif 'axe' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
            elif 'gun' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
            elif 'nuke' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
            else:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
            if pickupCount < 60:
                win.blit(pickupHealingHerb[pickupCount//3], (x,y))
                pickupCount += 1
            elif pickupCount > 60:
                win.blit(chara, (x,y))
            if walkCount + 1 >= 60:
                walkCount = 0
            if left:
                win.blit(walkLeft[walkCount//3], (x,y))
                walkCount += 1
            elif right:
                win.blit(walkRight[walkCount//3], (x,y))
                walkCount += 1
            elif up:
                win.blit(walkUp[walkCount//3], (x,y))
                walkCount += 1
            elif down:
                win.blit(walkDown[walkCount//3], (x,y))
                walkCount += 1
            else:
                win.blit(chara, (x, y))
    elif itemSpawned2 == 'potion':
        win.blit(spr_potion, (itm_spwn_x, itm_spwn_y))
        if t == 1:
            if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                player_health=player_health+potion_healed
                m.music.load('item-get.mp3')
                m.music.play()
                t=t-1
        elif t == 0:
            win.fill(white)
            win.blit(Floor1Room3, (0,0))
            room_title3 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
            room_title3.render_to(win, (325, 10), "Floor 1 Room 3", (black))
            health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
            health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
            defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
            defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
            luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
            luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
            dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
            if 'dagger' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
            elif 'trident' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
            elif 'sword' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
            elif 'axe' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
            elif 'gun' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
            elif 'nuke' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
            else:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
            if pickupCount < 60:
                win.blit(pickupPotion[pickupCount//3], (x,y))
                pickupCount += 1
            elif pickupCount > 60:
                win.blit(chara, (x,y))
            if walkCount + 1 >= 60:
                walkCount = 0
            if left:
                win.blit(walkLeft[walkCount//3], (x,y))
                walkCount += 1
            elif right:
                win.blit(walkRight[walkCount//3], (x,y))
                walkCount += 1
            elif up:
                win.blit(walkUp[walkCount//3], (x,y))
                walkCount += 1
            elif down:
                win.blit(walkDown[walkCount//3], (x,y))
                walkCount += 1
            else:
                win.blit(chara, (x, y))
    elif itemSpawned2 == 'fresh_water':
        win.blit(spr_water, (itm_spwn_x, itm_spwn_y))
        if t == 1:
            if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                player_health=player_health+fresh_water_healed
                m.music.load('item-get.mp3')
                m.music.play()
                t=t-1
        elif t == 0:
            win.fill(white)
            win.blit(Floor1Room3, (0,0))
            room_title3 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
            room_title3.render_to(win, (325, 10), "Floor 1 Room 3", (black))
            health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
            health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
            defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
            defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
            luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
            luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
            dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
            if 'dagger' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
            elif 'trident' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
            elif 'sword' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
            elif 'axe' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
            elif 'gun' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
            elif 'nuke' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
            else:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
            if pickupCount < 60:
                win.blit(pickupFreshWater[pickupCount//3], (x,y))
                pickupCount += 1
            elif pickupCount > 60:
                win.blit(chara, (x,y))
            if walkCount + 1 >= 60:
                walkCount = 0
            if left:
                win.blit(walkLeft[walkCount//3], (x,y))
                walkCount += 1
            elif right:
                win.blit(walkRight[walkCount//3], (x,y))
                walkCount += 1
            elif up:
                win.blit(walkUp[walkCount//3], (x,y))
                walkCount += 1
            elif down:
                win.blit(walkDown[walkCount//3], (x,y))
                walkCount += 1
            else:
                win.blit(chara, (x, y))
    if itemSpawned2 == 'amulet':
        win.blit(spr_amulet, (itm_spwn_x, itm_spwn_y))
        if t == 1:
            if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                luck=luck+1
                m.music.load('item-get.mp3')
                m.music.play()
                t=t-1
        elif t == 0:
            win.fill(white)
            win.blit(Floor1Room3, (0,0))
            room_title3 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
            room_title3.render_to(win, (325, 10), "Floor 1 Room 3", (black))
            health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
            health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
            defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
            defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
            luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
            luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
            dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
            if 'dagger' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
            elif 'trident' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
            elif 'sword' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
            elif 'axe' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
            elif 'gun' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
            elif 'nuke' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
            else:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
            if pickupCount < 60:
                win.blit(pickupAmulet[pickupCount//3], (x,y))
                pickupCount += 1
            elif pickupCount > 60:
                win.blit(chara, (x,y))
            if walkCount + 1 >= 60:
                walkCount = 0
            if left:
                win.blit(walkLeft[walkCount//3], (x,y))
                walkCount += 1
            elif right:
                win.blit(walkRight[walkCount//3], (x,y))
                walkCount += 1
            elif up:
                win.blit(walkUp[walkCount//3], (x,y))
                walkCount += 1
            elif down:
                win.blit(walkDown[walkCount//3], (x,y))
                walkCount += 1
            else:
                win.blit(chara, (x, y))
    if itemSpawned2 == 'wood_shield':
        win.blit(spr_wood_shield, (itm_spwn_x, itm_spwn_y))
        if t == 1:
            if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                player_defense=player_defense+def_wood_shield
                m.music.load('item-get.mp3')
                m.music.play()
                t=t-1
        elif t == 0:
            win.fill(white)
            win.blit(Floor1Room3, (0,0))
            room_title3 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
            room_title3.render_to(win, (325, 10), "Floor 1 Room 3", (black))
            health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
            health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
            defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
            defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
            luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
            luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
            dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
            if 'dagger' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
            elif 'trident' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
            elif 'sword' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
            elif 'axe' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
            elif 'gun' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
            elif 'nuke' in inventory:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
            else:
                dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
            if pickupCount < 60:
                win.blit(pickupWoodShield[pickupCount//3], (x,y))
                pickupCount += 1
            elif pickupCount > 60:
                win.blit(chara, (x,y))
            if walkCount + 1 >= 60:
                walkCount = 0
            if left:
                win.blit(walkLeft[walkCount//3], (x,y))
                walkCount += 1
            elif right:
                win.blit(walkRight[walkCount//3], (x,y))
                walkCount += 1
            elif up:
                win.blit(walkUp[walkCount//3], (x,y))
                walkCount += 1
            elif down:
                win.blit(walkDown[walkCount//3], (x,y))
                walkCount += 1
            else:
                win.blit(chara, (x, y))
    p.display.update()
def level_4():
    global walkCount
    global devilCount
    global attackCount1
    global player_health
    global devil1_health
    global a1
    win.blit(Floor1Room4, (0,0))
    room_title4 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
    room_title4.render_to(win, (325, 10), "Floor 1 Room 4", (black))
    health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
    defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
    luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
    dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    if 'dagger' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
    elif 'trident' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
    elif 'sword' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
    elif 'axe' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
    elif 'gun' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
    elif 'nuke' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
    else:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))

    if walkCount + 1 >= 60:
        walkCount = 0

    if left:
        win.blit(walkLeft[walkCount//3], (x,y))
        walkCount += 1
    elif right:
        win.blit(walkRight[walkCount//3], (x,y))
        walkCount += 1
    elif up:
        win.blit(walkUp[walkCount//3], (x,y))
        walkCount += 1
    elif down:
        win.blit(walkDown[walkCount//3], (x,y))
        walkCount += 1
    else:
        win.blit(chara, (x, y))
    #Spawning set enemies
    if a1 == 1:
        if (x >= 400 and x <= 480) and (y >= 215 and y <= 265):
            if 'dagger' in inventory:
                if left == True:
                    win.blit(attackLeftDagger[attackCount1//3], (x,y))
                    attackCount1 += 1
                    devil1_health=devil1_health-dmg_dagger
                    if devil1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount1 >= 60:
                        attackCount1=0
                elif right == True:
                    win.blit(attackRightDagger[attackCount1//3], (x,y))
                    attackCount1 += 1
                    devil1_health=devil1_health-dmg_dagger
                    if devil1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount1 >= 60:
                        attackCount1=0
                elif up == True:
                    win.blit(attackUpDagger[attackCount1//3], (x,y))
                    attackCount1 += 1
                    devil1_health=devil1_health-dmg_dagger
                    if devil1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount1 >= 60:
                        attackCount1=0
                elif down == True:
                    win.blit(attackDownDagger[attackCount1//3], (x,y))
                    attackCount1 += 1
                    devil1_health=devil1_health-dmg_dagger
                    if devil1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount1 >= 60:
                        attackCount1=0
                else:
                    win.blit(attackDownDagger[attackCount1//3], (x,y))
                    attackCount1 += 1
                    devil1_health=devil1_health-dmg_dagger
                    if devil1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount1 >= 60:
                        attackCount1=0
            elif 'trident' in inventory:
                if left == True:
                    win.blit(attackLeftTrident[attackCount1//3], (x,y))
                    attackCount1 += 1
                    devil1_health=devil1_health-dmg_trident
                    if devil1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount1 >= 60:
                        attackCount1=0
                elif right == True:
                    win.blit(attackRightTrident[attackCount1//3], (x,y))
                    attackCount1 += 1
                    devil1_health=devil1_health-dmg_trident
                    if devil1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount1 >= 60:
                        attackCount1=0
                elif up == True:
                    win.blit(attackUpTrident[attackCount1//3], (x,y))
                    attackCount1 += 1
                    devil1_health=devil1_health-dmg_trident
                    if devil1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount1 >= 60:
                        attackCount1=0
                elif down == True:
                    win.blit(attackDownTrident[attackCount1//3], (x,y))
                    attackCount1 += 1
                    devil1_health=devil1_health-dmg_trident
                    if devil1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount1 >= 60:
                        attackCount1=0
                else:
                    win.blit(attackDownTrident[attackCount1//3], (x,y))
                    attackCount1 += 1
                    devil1_health=devil1_health-dmg_trident
                    if devil1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount1 >= 60:
                        attackCount1=0
            elif 'sword' in inventory:
                if left == True:
                    win.blit(attackLeftSword[attackCount1//3], (x,y))
                    attackCount1 += 1
                    devil1_health=devil1_health-dmg_sword
                    if devil1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount1 >= 60:
                        attackCount1=0
                elif right == True:
                    win.blit(attackRightSword[attackCount1//3], (x,y))
                    attackCount1 += 1
                    devil1_health=devil1_health-dmg_sword
                    if devil1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount1 >= 60:
                        attackCount1=0
                elif up == True:
                    win.blit(attackUpSword[attackCount1//3], (x,y))
                    attackCount1 += 1
                    devil1_health=devil1_health-dmg_sword
                    if devil1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount1 >= 60:
                        attackCount1=0
                elif down == True:
                    win.blit(attackDownSword[attackCount1//3], (x,y))
                    attackCount1 += 1
                    devil1_health=devil1_health-dmg_sword
                    if devil1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount1 >= 60:
                        attackCount1=0
                else:
                    win.blit(attackDownSword[attackCount1//3], (x,y))
                    attackCount1 += 1
                    devil1_health=devil1_health-dmg_sword
                    if devil1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount1 >= 60:
                        attackCount1=0
            elif 'axe' in inventory:
                if left == True:
                    win.blit(attackLeftAxe[attackCount1//3], (x,y))
                    attackCount1 += 1
                    devil1_health=devil1_health-dmg_axe
                    if devil1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount1 >= 60:
                        attackCount1=0
                elif right == True:
                    win.blit(attackRightAxe[attackCount1//3], (x,y))
                    attackCount1 += 1
                    devil1_health=devil1_health-dmg_axe
                    if devil1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount1 >= 60:
                        attackCount1=0
                elif up == True:
                    win.blit(attackUpAxe[attackCount1//3], (x,y))
                    attackCount1 += 1
                    devil1_health=devil1_health-dmg_axe
                    if devil1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount1 >= 60:
                        attackCount1=0
                elif down == True:
                    win.blit(attackDownAxe[attackCount1//3], (x,y))
                    attackCount1 += 1
                    devil1_health=devil1_health-dmg_axe
                    if devil1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount1 >= 60:
                        attackCount1=0
                else:
                    win.blit(attackDownAxe[attackCount1//3], (x,y))
                    attackCount1 += 1
                    devil1_health=devil1_health-dmg_axe
                    if devil1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount1 >= 60:
                        attackCount1=0
            elif 'gun' in inventory:
                if left == True:
                    win.blit(attackLeftGun[attackCount1//3], (x,y))
                    attackCount1 += 1
                    devil1_health=devil1_health-dmg_AK47
                    if devil1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount1 >= 60:
                        attackCount1=0
                elif right == True:
                    win.blit(attackRightGun[attackCount1//3], (x,y))
                    attackCount1 += 1
                    devil1_health=devil1_health-dmg_AK47
                    if devil1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount1 >= 60:
                        attackCount1=0
                elif up == True:
                    win.blit(attackUpGun[attackCount1//3], (x,y))
                    attackCount1 += 1
                    devil1_health=devil1_health-dmg_AK47
                    if devil1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount1 >= 60:
                        attackCount1=0
                elif down == True:
                    win.blit(attackDownGun[attackCount1//3], (x,y))
                    attackCount1 += 1
                    devil1_health=devil1_health-dmg_AK47
                    if devil1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount1 >= 60:
                        attackCount1=0
                else:
                    win.blit(attackDownGun[attackCount1//3], (x,y))
                    attackCount1 += 1
                    devil1_health=devil1_health-dmg_AK47
                    if devil1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount1 >= 60:
                        attackCount1=0
            elif 'nuke' in inventory:
                if left == True:
                    win.blit(attackLeftNuke[attackCount1//3], (x,y))
                    attackCount1 += 1
                    devil1_health=devil1_health-dmg_Nuke
                    if devil1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount1 >= 60:
                        attackCount1=0
                elif right == True:
                    win.blit(attackRightNuke[attackCount1//3], (x,y))
                    attackCount1 += 1
                    devil1_health=devil1_health-dmg_Nuke
                    if devil1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount1 >= 60:
                        attackCount1=0
                elif up == True:
                    win.blit(attackUpNuke[attackCount1//3], (x,y))
                    attackCount1 += 1
                    devil1_health=devil1_health-dmg_Nuke
                    if devil1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount1 >= 60:
                        attackCount1=0
                elif down == True:
                    win.blit(attackDownNuke[attackCount1//3], (x,y))
                    attackCount1 += 1
                    devil1_health=devil1_health-dmg_Nuke
                    if devil1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount1 >= 60:
                        attackCount1=0
                else:
                    win.blit(attackDownNuke[attackCount1//3], (x,y))
                    attackCount1 += 1
                    devil1_health=devil1_health-dmg_Nuke
                    if devil1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount1 >= 60:
                        attackCount1=0
    if devil1_health > 0:
        win.blit(Devil[devilCount//3], (enemy_x, enemy_y))
        devil1_health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 14)
        devil1_health_bar.render_to(win, (455, 235), ("HP " + str(devil1_health)), (black))
        devilCount += 1
        if devilCount == 60:
            devilCount=0
    elif devil1_health <= 0:
        a1=a1-1
        pass
    if player_health <= 0:
        gameOver()
    p.display.update()
def level_5():
    global walkCount
    global player_health
    global player_defense
    global healing_herb_healed
    global potion_healed
    global fresh_water_healed
    global luck
    global t1
    global pickupCount1
    global luck
    win.blit(Floor1Room5, (0,0))
    room_title5 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
    room_title5.render_to(win, (325, 10), "Floor 1 Room 5", (black))
    health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
    defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
    luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
    dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    if 'dagger' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
    elif 'trident' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
    elif 'sword' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
    elif 'axe' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
    elif 'gun' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
    elif 'nuke' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
    else:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))

    if walkCount + 1 >= 60:
        walkCount = 0

    if left:
        win.blit(walkLeft[walkCount//3], (x,y))
        walkCount += 1
    elif right:
        win.blit(walkRight[walkCount//3], (x,y))
        walkCount += 1
    elif up:
        win.blit(walkUp[walkCount//3], (x,y))
        walkCount += 1
    elif down:
        win.blit(walkDown[walkCount//3], (x,y))
        walkCount += 1
    else:
        win.blit(chara, (x, y))
    #Spawning items
    if luck == 0:
        if itemSpawned3 == 'healing_herb':
            win.blit(spr_herb, (itm_spwn_x, itm_spwn_y))
            if t1 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+healing_herb_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t1=t1-1
            elif t1 == 0:
                win.fill(white)
                win.blit(Floor1Room5, (0,0))
                room_title5 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title5.render_to(win, (325, 10), "Floor 1 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount1 < 60:
                    win.blit(pickupHealingHerb[pickupCount1//3], (x,y))
                    pickupCount1 += 1
                elif pickupCount1 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemSpawned3 == 'potion':
            win.blit(spr_potion, (itm_spwn_x, itm_spwn_y))
            if t1 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t1=t1-1
            elif t1 == 0:
                win.fill(white)
                win.blit(Floor1Room5, (0,0))
                room_title5 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title5.render_to(win, (325, 10), "Floor 1 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount1 < 60:
                    win.blit(pickupPotion[pickupCount1//3], (x,y))
                    pickupCount1 += 1
                elif pickupCount1 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemSpawned3 == 'fresh_water':
            win.blit(spr_water, (itm_spwn_x, itm_spwn_y))
            if t1 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+fresh_water_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t1=t1-1
            elif t1 == 0:
                win.fill(white)
                win.blit(Floor1Room5, (0,0))
                room_title5 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title5.render_to(win, (325, 10), "Floor 1 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount1 < 60:
                    win.blit(pickupFreshWater[pickupCount1//3], (x,y))
                    pickupCount1 += 1
                elif pickupCount1 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        if itemSpawned3 == 'amulet':
            win.blit(spr_amulet, (itm_spwn_x, itm_spwn_y))
            if t1 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    luck=luck+1
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t=t-1
            elif t1 == 0:
                win.fill(white)
                win.blit(Floor1Room3, (0,0))
                room_title3 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title3.render_to(win, (325, 10), "Floor 1 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount < 60:
                    win.blit(pickupAmulet[pickupCount//3], (x,y))
                    pickupCount += 1
                elif pickupCount > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        if itemSpawned3 == 'wood_shield':
            win.blit(spr_wood_shield, (itm_spwn_x, itm_spwn_y))
            if t1 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_defense+def_wood_shield
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t1=t1-1
            elif t1 == 0:
                win.fill(white)
                win.blit(Floor1Room5, (0,0))
                room_title5 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title5.render_to(win, (325, 10), "Floor 1 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount1 < 60:
                    win.blit(pickupWoodShield[pickupCount1//3], (x,y))
                    pickupCount1 += 1
                elif pickupCount1 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
    elif luck == 1:
        if itemLuck1Spawned3 == 'healing_herb':
            win.blit(spr_herb, (itm_spwn_x, itm_spwn_y))
            if t1 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+healing_herb_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t1=t1-1
            elif t1 == 0:
                win.fill(white)
                win.blit(Floor1Room5, (0,0))
                room_title5 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title5.render_to(win, (325, 10), "Floor 1 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount1 < 60:
                    win.blit(pickupHealingHerb[pickupCount1//3], (x,y))
                    pickupCount1 += 1
                elif pickupCount1 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck1Spawned3 == 'potion':
            win.blit(spr_potion, (itm_spwn_x, itm_spwn_y))
            if t1 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t1=t1-1
            elif t1 == 0:
                win.fill(white)
                win.blit(Floor1Room5, (0,0))
                room_title5 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title5.render_to(win, (325, 10), "Floor 1 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount1 < 60:
                    win.blit(pickupPotion[pickupCount1//3], (x,y))
                    pickupCount1 += 1
                elif pickupCount1 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck1Spawned3 == 'fresh_water':
            win.blit(spr_water, (itm_spwn_x, itm_spwn_y))
            if t1 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+fresh_water_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t1=t1-1
            elif t1 == 0:
                win.fill(white)
                win.blit(Floor1Room5, (0,0))
                room_title5 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title5.render_to(win, (325, 10), "Floor 1 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount1 < 60:
                    win.blit(pickupFreshWater[pickupCount1//3], (x,y))
                    pickupCount1 += 1
                elif pickupCount1 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        if itemLuck1Spawned3 == 'amulet':
            win.blit(spr_amulet, (itm_spwn_x, itm_spwn_y))
            if t1 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    luck=luck+1
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t=t-1
            elif t1 == 0:
                win.fill(white)
                win.blit(Floor1Room3, (0,0))
                room_title3 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title3.render_to(win, (325, 10), "Floor 1 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount < 60:
                    win.blit(pickupAmulet[pickupCount//3], (x,y))
                    pickupCount += 1
                elif pickupCount > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        if itemLuck1Spawned3 == 'wood_shield':
            win.blit(spr_wood_shield, (itm_spwn_x, itm_spwn_y))
            if t1 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+healing_herb_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t1=t1-1
            elif t1 == 0:
                win.fill(white)
                win.blit(Floor1Room5, (0,0))
                room_title5 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title5.render_to(win, (325, 10), "Floor 1 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount1 < 60:
                    win.blit(pickupWoodShield[pickupCount1//3], (x,y))
                    pickupCount1 += 1
                elif pickupCount1 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
    elif luck == 2:
        if itemLuck2Spawned3 == 'healing_herb':
            win.blit(spr_herb, (itm_spwn_x, itm_spwn_y))
            if t1 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+healing_herb_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t1=t1-1
            elif t1 == 0:
                win.fill(white)
                win.blit(Floor1Room5, (0,0))
                room_title5 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title5.render_to(win, (325, 10), "Floor 1 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount1 < 60:
                    win.blit(pickupHealingHerb[pickupCount1//3], (x,y))
                    pickupCount1 += 1
                elif pickupCount1 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck2Spawned3 == 'potion':
            win.blit(spr_potion, (itm_spwn_x, itm_spwn_y))
            if t1 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t1=t1-1
            elif t1 == 0:
                win.fill(white)
                win.blit(Floor1Room5, (0,0))
                room_title5 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title5.render_to(win, (325, 10), "Floor 1 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount1 < 60:
                    win.blit(pickupPotion[pickupCount1//3], (x,y))
                    pickupCount1 += 1
                elif pickupCount1 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck2Spawned3 == 'fresh_water':
            win.blit(spr_water, (itm_spwn_x, itm_spwn_y))
            if t1 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+fresh_water_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t1=t1-1
            elif t1 == 0:
                win.fill(white)
                win.blit(Floor1Room5, (0,0))
                room_title5 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title5.render_to(win, (325, 10), "Floor 1 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount1 < 60:
                    win.blit(pickupFreshWater[pickupCount1//3], (x,y))
                    pickupCount1 += 1
                elif pickupCount1 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        if itemLuck2Spawned2 == 'amulet':
            win.blit(spr_amulet, (itm_spwn_x, itm_spwn_y))
            if t1 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    luck=luck+1
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t=t-1
            elif t1 == 0:
                win.fill(white)
                win.blit(Floor1Room3, (0,0))
                room_title3 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title3.render_to(win, (325, 10), "Floor 1 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount < 60:
                    win.blit(pickupAmulet[pickupCount//3], (x,y))
                    pickupCount += 1
                elif pickupCount > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        if itemLuck2Spawned3 == 'wood_shield':
            win.blit(spr_wood_shield, (itm_spwn_x, itm_spwn_y))
            if t1 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+healing_herb_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t1=t1-1
            elif t1 == 0:
                win.fill(white)
                win.blit(Floor1Room5, (0,0))
                room_title5 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title5.render_to(win, (325, 10), "Floor 1 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount1 < 60:
                    win.blit(pickupWoodShield[pickupCount1//3], (x,y))
                    pickupCount1 += 1
                elif pickupCount1 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
    elif luck == 3:
        if itemLuck3Spawned3 == 'healing_herb':
            win.blit(spr_herb, (itm_spwn_x, itm_spwn_y))
            if t1 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+healing_herb_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t1=t1-1
            elif t1 == 0:
                win.fill(white)
                win.blit(Floor1Room5, (0,0))
                room_title5 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title5.render_to(win, (325, 10), "Floor 1 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount1 < 60:
                    win.blit(pickupHealingHerb[pickupCount1//3], (x,y))
                    pickupCount1 += 1
                elif pickupCount1 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck3Spawned3 == 'potion':
            win.blit(spr_potion, (itm_spwn_x, itm_spwn_y))
            if t1 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t1=t1-1
            elif t1 == 0:
                win.fill(white)
                win.blit(Floor1Room5, (0,0))
                room_title5 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title5.render_to(win, (325, 10), "Floor 1 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount1 < 60:
                    win.blit(pickupPotion[pickupCount1//3], (x,y))
                    pickupCount1 += 1
                elif pickupCount1 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck3Spawned3 == 'fresh_water':
            win.blit(spr_water, (itm_spwn_x, itm_spwn_y))
            if t1 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+fresh_water_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t1=t1-1
            elif t1 == 0:
                win.fill(white)
                win.blit(Floor1Room5, (0,0))
                room_title5 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title5.render_to(win, (325, 10), "Floor 1 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount1 < 60:
                    win.blit(pickupFreshWater[pickupCount1//3], (x,y))
                    pickupCount1 += 1
                elif pickupCount1 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        if itemLuck3Spawned2 == 'amulet':
            win.blit(spr_amulet, (itm_spwn_x, itm_spwn_y))
            if t1 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    luck=luck+1
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t=t-1
            elif t1 == 0:
                win.fill(white)
                win.blit(Floor1Room3, (0,0))
                room_title3 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title3.render_to(win, (325, 10), "Floor 1 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount < 60:
                    win.blit(pickupAmulet[pickupCount//3], (x,y))
                    pickupCount += 1
                elif pickupCount > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        if itemLuck3Spawned3 == 'wood_shield':
            win.blit(spr_wood_shield, (itm_spwn_x, itm_spwn_y))
            if t1 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+healing_herb_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t1=t1-1
            elif t1 == 0:
                win.fill(white)
                win.blit(Floor1Room5, (0,0))
                room_title5 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title5.render_to(win, (325, 10), "Floor 1 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount1 < 60:
                    win.blit(pickupWoodShield[pickupCount1//3], (x,y))
                    pickupCount1 += 1
                elif pickupCount1 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
    p.display.update()
def level_6():
    global walkCount
    global player_health
    global healing_herb_healed
    global potion_healed
    global super_poiton_healed
    global t2
    global pickupCount2
    global luck
    win.blit(Floor2Room1, (0,0))
    room_title6 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
    room_title6.render_to(win, (325, 10), "Floor 2 Room 1", (black))
    health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
    defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
    luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
    dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    if 'dagger' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
    elif 'trident' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
    elif 'sword' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
    elif 'axe' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
    elif 'gun' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
    elif 'nuke' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
    else:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))

    if walkCount + 1 >= 60:
        walkCount = 0

    if left:
        win.blit(walkLeft[walkCount//3], (x,y))
        walkCount += 1
    elif right:
        win.blit(walkRight[walkCount//3], (x,y))
        walkCount += 1
    elif up:
        win.blit(walkUp[walkCount//3], (x,y))
        walkCount += 1
    elif down:
        win.blit(walkDown[walkCount//3], (x,y))
        walkCount += 1
    else:
        win.blit(chara, (x, y))
    #Spawning items
    if luck == 0:
        if itemSpawned4 == 'healing_herb':
            win.blit(spr_herb, (itm_spwn_x, itm_spwn_y))
            if t2 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+healing_herb_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t2=t2-1
            elif t2 == 0:
                win.fill(white)
                win.blit(Floor2Room1, (0,0))
                room_title6 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title6.render_to(win, (325, 10), "Floor 2 Room 1", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount2 < 60:
                    win.blit(pickupHealingHerb[pickupCount2//3], (x,y))
                    pickupCount2 += 1
                elif pickupCount2 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemSpawned4 == 'potion':
            win.blit(spr_potion, (itm_spwn_x, itm_spwn_y))
            if t2 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t2=t2-1
            elif t2 == 0:
                win.fill(white)
                win.blit(Floor2Room1, (0,0))
                room_title6 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title6.render_to(win, (325, 10), "Floor 2 Room 1", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount2 < 60:
                    win.blit(pickupPotion[pickupCount2//3], (x,y))
                    pickupCount2 += 1
                elif pickupCount2 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemSpawned4 == 'super_potion':
            win.blit(spr_super_potion, (itm_spwn_x, itm_spwn_y))
            if t2 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+super_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t2=t2-1
            elif t2 == 0:
                win.fill(white)
                win.blit(Floor2Room1, (0,0))
                room_title6 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title6.render_to(win, (325, 10), "Floor 2 Room 1", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount2 < 60:
                    win.blit(pickupSuperPotion[pickupCount2//3], (x,y))
                    pickupCount2 += 1
                elif pickupCount2 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
    elif luck == 1:
        if itemLuck1Spawned4 == 'healing_herb':
            win.blit(spr_herb, (itm_spwn_x, itm_spwn_y))
            if t2 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+healing_herb_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t2=t2-1
            elif t2 == 0:
                win.fill(white)
                win.blit(Floor2Room1, (0,0))
                room_title6 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title6.render_to(win, (325, 10), "Floor 2 Room 1", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount2 < 60:
                    win.blit(pickupHealingHerb[pickupCount2//3], (x,y))
                    pickupCount2 += 1
                elif pickupCount2 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck1Spawned4 == 'potion':
            win.blit(spr_potion, (itm_spwn_x, itm_spwn_y))
            if t2 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t2=t2-1
            elif t2 == 0:
                win.fill(white)
                win.blit(Floor2Room1, (0,0))
                room_title6 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title6.render_to(win, (325, 10), "Floor 2 Room 1", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount2 < 60:
                    win.blit(pickupPotion[pickupCount2//3], (x,y))
                    pickupCount2 += 1
                elif pickupCount2 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck1Spawned4 == 'super_potion':
            win.blit(spr_super_potion, (itm_spwn_x, itm_spwn_y))
            if t2 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+super_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t2=t2-1
            elif t2 == 0:
                win.fill(white)
                win.blit(Floor2Room1, (0,0))
                room_title6 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title6.render_to(win, (325, 10), "Floor 2 Room 1", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount2 < 60:
                    win.blit(pickupSuperPotion[pickupCount2//3], (x,y))
                    pickupCount2 += 1
                elif pickupCount2 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
    elif luck == 2:
        if itemLuck2Spawned4 == 'healing_herb':
            win.blit(spr_herb, (itm_spwn_x, itm_spwn_y))
            if t2 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+healing_herb_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t2=t2-1
            elif t2 == 0:
                win.fill(white)
                win.blit(Floor2Room1, (0,0))
                room_title6 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title6.render_to(win, (325, 10), "Floor 2 Room 1", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount2 < 60:
                    win.blit(pickupHealingHerb[pickupCount2//3], (x,y))
                    pickupCount2 += 1
                elif pickupCount2 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck2Spawned4 == 'potion':
            win.blit(spr_potion, (itm_spwn_x, itm_spwn_y))
            if t2 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t2=t2-1
            elif t2 == 0:
                win.fill(white)
                win.blit(Floor2Room1, (0,0))
                room_title6 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title6.render_to(win, (325, 10), "Floor 2 Room 1", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount2 < 60:
                    win.blit(pickupPotion[pickupCount2//3], (x,y))
                    pickupCount2 += 1
                elif pickupCount2 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck2Spawned4 == 'super_potion':
            win.blit(spr_super_potion, (itm_spwn_x, itm_spwn_y))
            if t2 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+super_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t2=t2-1
            elif t2 == 0:
                win.fill(white)
                win.blit(Floor2Room1, (0,0))
                room_title6 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title6.render_to(win, (325, 10), "Floor 2 Room 1", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount2 < 60:
                    win.blit(pickupSuperPotion[pickupCount2//3], (x,y))
                    pickupCount2 += 1
                elif pickupCount2 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
    if luck == 3:
        if itemLuck3Spawned4 == 'healing_herb':
            win.blit(spr_herb, (itm_spwn_x, itm_spwn_y))
            if t2 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+healing_herb_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t2=t2-1
            elif t2 == 0:
                win.fill(white)
                win.blit(Floor2Room1, (0,0))
                room_title6 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title6.render_to(win, (325, 10), "Floor 2 Room 1", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount2 < 60:
                    win.blit(pickupHealingHerb[pickupCount2//3], (x,y))
                    pickupCount2 += 1
                elif pickupCount2 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck3Spawned4 == 'potion':
            win.blit(spr_potion, (itm_spwn_x, itm_spwn_y))
            if t2 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t2=t2-1
            elif t2 == 0:
                win.fill(white)
                win.blit(Floor2Room1, (0,0))
                room_title6 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title6.render_to(win, (325, 10), "Floor 2 Room 1", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount2 < 60:
                    win.blit(pickupPotion[pickupCount2//3], (x,y))
                    pickupCount2 += 1
                elif pickupCount2 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck3Spawned4 == 'super_potion':
            win.blit(spr_super_potion, (itm_spwn_x, itm_spwn_y))
            if t2 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+super_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t2=t2-1
            elif t2 == 0:
                win.fill(white)
                win.blit(Floor2Room1, (0,0))
                room_title6 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title6.render_to(win, (325, 10), "Floor 2 Room 1", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount2 < 60:
                    win.blit(pickupSuperPotion[pickupCount2//3], (x,y))
                    pickupCount2 += 1
                elif pickupCount2 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
    p.display.update()
def level_7():
    global walkCount
    global devilCount1
    global attackCount2
    global player_health
    global devil2_health
    global a2
    win.blit(Floor2Room2, (0,0))
    room_title7 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
    room_title7.render_to(win, (325, 10), "Floor 2 Room 2", (black))
    health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
    defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
    luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
    dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    if 'dagger' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
    elif 'trident' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
    elif 'sword' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
    elif 'axe' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
    elif 'gun' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
    elif 'nuke' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
    else:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))

    if walkCount + 1 >= 60:
        walkCount = 0

    if left:
        win.blit(walkLeft[walkCount//3], (x,y))
        walkCount += 1
    elif right:
        win.blit(walkRight[walkCount//3], (x,y))
        walkCount += 1
    elif up:
        win.blit(walkUp[walkCount//3], (x,y))
        walkCount += 1
    elif down:
        win.blit(walkDown[walkCount//3], (x,y))
        walkCount += 1
    else:
        win.blit(chara, (x, y))
    #Spawning set enemies
    if a2 == 1:
        if (x >= 400 and x <= 480) and (y >= 215 and y <= 265):
            if 'dagger' in inventory:
                if left == True:
                    win.blit(attackLeftDagger[attackCount2//3], (x,y))
                    attackCount2 += 1
                    devil2_health=devil2_health-dmg_dagger
                    if devil2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount2 >= 60:
                        attackCount2=0
                elif right == True:
                    win.blit(attackRightDagger[attackCount2//3], (x,y))
                    attackCount2 += 1
                    devil2_health=devil2_health-dmg_dagger
                    if devil2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount2 >= 60:
                        attackCount2=0
                elif up == True:
                    win.blit(attackUpDagger[attackCount2//3], (x,y))
                    attackCount2 += 1
                    devil2_health=devil2_health-dmg_dagger
                    if devil2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount2 >= 60:
                        attackCount2=0
                elif down == True:
                    win.blit(attackDownDagger[attackCount2//3], (x,y))
                    attackCount2 += 1
                    devil2_health=devil2_health-dmg_dagger
                    if devil2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount2 >= 60:
                        attackCount2=0
                else:
                    win.blit(attackDownDagger[attackCount2//3], (x,y))
                    attackCount2 += 1
                    devil2_health=devil2_health-dmg_dagger
                    if devil2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount2 >= 60:
                        attackCount2=0
            elif 'trident' in inventory:
                if left == True:
                    win.blit(attackLeftTrident[attackCount2//3], (x,y))
                    attackCount2 += 1
                    devil2_health=devil2_health-dmg_trident
                    if devil2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount2 >= 60:
                        attackCount2=0
                elif right == True:
                    win.blit(attackRightTrident[attackCount2//3], (x,y))
                    attackCount2 += 1
                    devil2_health=devil2_health-dmg_trident
                    if devil2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount2 >= 60:
                        attackCount2=0
                elif up == True:
                    win.blit(attackUpTrident[attackCount2//3], (x,y))
                    attackCount2 += 1
                    devil2_health=devil2_health-dmg_trident
                    if devil2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount2 >= 60:
                        attackCount2=0
                elif down == True:
                    win.blit(attackDownTrident[attackCount2//3], (x,y))
                    attackCount2 += 1
                    devil2_health=devil2_health-dmg_trident
                    if devil2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount2 >= 60:
                        attackCount2=0
                else:
                    win.blit(attackDownTrident[attackCount2//3], (x,y))
                    attackCount2 += 1
                    devil2_health=devil2_health-dmg_trident
                    if devil2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount2 >= 60:
                        attackCount2=0
            elif 'sword' in inventory:
                if left == True:
                    win.blit(attackLeftSword[attackCount2//3], (x,y))
                    attackCount2 += 1
                    devil2_health=devil2_health-dmg_sword
                    if devil2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount2 >= 60:
                        attackCount2=0
                elif right == True:
                    win.blit(attackRightSword[attackCount2//3], (x,y))
                    attackCount2 += 1
                    devil2_health=devil2_health-dmg_sword
                    if devil2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount2 >= 60:
                        attackCount2=0
                elif up == True:
                    win.blit(attackUpSword[attackCount2//3], (x,y))
                    attackCount2 += 1
                    devil2_health=devil2_health-dmg_sword
                    if devil2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount2 >= 60:
                        attackCount2=0
                elif down == True:
                    win.blit(attackDownSword[attackCount2//3], (x,y))
                    attackCount2 += 1
                    devil2_health=devil2_health-dmg_sword
                    if devil2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount2 >= 60:
                        attackCount2=0
                else:
                    win.blit(attackDownSword[attackCount2//3], (x,y))
                    attackCount2 += 1
                    devil2_health=devil2_health-dmg_sword
                    if devil2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount2 >= 60:
                        attackCount2=0
            elif 'axe' in inventory:
                if left == True:
                    win.blit(attackLeftAxe[attackCount2//3], (x,y))
                    attackCount2 += 1
                    devil2_health=devil2_health-dmg_axe
                    if devil2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount2 >= 60:
                        attackCount2=0
                elif right == True:
                    win.blit(attackRightAxe[attackCount2//3], (x,y))
                    attackCount2 += 1
                    devil2_health=devil2_health-dmg_axe
                    if devil2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount2 >= 60:
                        attackCount2=0
                elif up == True:
                    win.blit(attackUpAxe[attackCount2//3], (x,y))
                    attackCount2 += 1
                    devil2_health=devil2_health-dmg_axe
                    if devil2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount2 >= 60:
                        attackCount2=0
                elif down == True:
                    win.blit(attackDownAxe[attackCount2//3], (x,y))
                    attackCount2 += 1
                    devil2_health=devil2_health-dmg_axe
                    if devil2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount2 >= 60:
                        attackCount2=0
                else:
                    win.blit(attackDownAxe[attackCount2//3], (x,y))
                    attackCount2 += 1
                    devil2_health=devil2_health-dmg_axe
                    if devil2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount2 >= 60:
                        attackCount2=0
            elif 'gun' in inventory:
                if left == True:
                    win.blit(attackLeftGun[attackCount2//3], (x,y))
                    attackCount2 += 1
                    devil2_health=devil2_health-dmg_AK47
                    if devil2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount2 >= 60:
                        attackCount2=0
                elif right == True:
                    win.blit(attackRightGun[attackCount2//3], (x,y))
                    attackCount2 += 1
                    devil2_health=devil2_health-dmg_AK47
                    if devil2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount2 >= 60:
                        attackCount2=0
                elif up == True:
                    win.blit(attackUpGun[attackCount2//3], (x,y))
                    attackCount2 += 1
                    devil2_health=devil2_health-dmg_Ak47
                    if devil2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount2 >= 60:
                        attackCount2=0
                elif down == True:
                    win.blit(attackDownGun[attackCount2//3], (x,y))
                    attackCount2 += 1
                    devil2_health=devil2_health-dmg_AK47
                    if devil2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount2 >= 60:
                        attackCount2=0
                else:
                    win.blit(attackDownGun[attackCount2//3], (x,y))
                    attackCount2 += 1
                    devil2_health=devil2_health-dmg_gun
                    if devil2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount2 >= 60:
                        attackCount2=0
            elif 'nuke' in inventory:
                if left == True:
                    win.blit(attackLeftNuke[attackCount2//3], (x,y))
                    attackCount2 += 1
                    devil2_health=devil2_health-dmg_Nuke
                    if devil2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount2 >= 60:
                        attackCount2=0
                elif right == True:
                    win.blit(attackRightNuke[attackCount2//3], (x,y))
                    attackCount2 += 1
                    devil2_health=devil2_health-dmg_Nuke
                    if devil2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount2 >= 60:
                        attackCount2=0
                elif up == True:
                    win.blit(attackUpNuke[attackCount2//3], (x,y))
                    attackCount2 += 1
                    devil2_health=devil2_health-dmg_Nuke
                    if devil2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount2 >= 60:
                        attackCount2=0
                elif down == True:
                    win.blit(attackDownNuke[attackCount2//3], (x,y))
                    attackCount2 += 1
                    devil2_health=devil2_health-dmg_Nuke
                    if devil2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount2 >= 60:
                        attackCount2=0
                else:
                    win.blit(attackDownNuke[attackCount2//3], (x,y))
                    attackCount2 += 1
                    devil2_health=devil2_health-dmg_Nuke
                    if devil2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*devil2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount2 >= 60:
                        attackCount2=0
    if devil2_health > 0:
        win.blit(Devil[devilCount1//3], (enemy_x, enemy_y))
        devil2_health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 14)
        devil2_health_bar.render_to(win, (455, 235), ("HP " + str(devil2_health)), (black))
        devilCount1 += 1
        if devilCount1 == 60:
            devilCount1=0
    elif devil2_health <= 0:
        a2=a2-1
        pass
    if player_health <= 0:
        gameOver()
    p.display.update()
def level_8():
    global walkCount
    global player_health
    global healing_herb_healed
    global potion_healed
    global super_potion_healed
    global t3
    global pickupCount3
    global luck
    win.blit(Floor2Room3, (0,0))
    room_title8 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
    room_title8.render_to(win, (325, 10), "Floor 2 Room 3", (black))
    health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
    defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
    luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
    dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    if 'dagger' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
    elif 'trident' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
    elif 'sword' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
    elif 'axe' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
    elif 'gun' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
    elif 'nuke' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
    else:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))

    if walkCount + 1 >= 60:
        walkCount = 0

    if left:
        win.blit(walkLeft[walkCount//3], (x,y))
        walkCount += 1
    elif right:
        win.blit(walkRight[walkCount//3], (x,y))
        walkCount += 1
    elif up:
        win.blit(walkUp[walkCount//3], (x,y))
        walkCount += 1
    elif down:
        win.blit(walkDown[walkCount//3], (x,y))
        walkCount += 1
    else:
        win.blit(chara, (x, y))
    #Spawning items
    if luck == 0:
        if itemSpawned5 == 'healing_herb':
            win.blit(spr_herb, (itm_spwn_x, itm_spwn_y))
            if t3 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+healing_herb_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t3=t3-1
            elif t3 == 0:
                win.fill(white)
                win.blit(Floor2Room3, (0,0))
                room_title8 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title8.render_to(win, (325, 10), "Floor 2 Room 3", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount3 < 60:
                    win.blit(pickupHealingHerb[pickupCount3//3], (x,y))
                    pickupCount3 += 1
                elif pickupCount3 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemSpawned5 == 'potion':
            win.blit(spr_potion, (itm_spwn_x, itm_spwn_y))
            if t3 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t3=t3-1
            elif t3 == 0:
                win.fill(white)
                win.blit(Floor2Room3, (0,0))
                room_title8 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title8.render_to(win, (325, 10), "Floor 2 Room 3", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount3 < 60:
                    win.blit(pickupPotion[pickupCount3//3], (x,y))
                    pickupCount3 += 1
                elif pickupCount3 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemSpawned5 == 'super_potion':
            win.blit(spr_super_potion, (itm_spwn_x, itm_spwn_y))
            if t3 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+super_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t3=t3-1
            elif t3 == 0:
                win.fill(white)
                win.blit(Floor2Room3, (0,0))
                room_title8 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title8.render_to(win, (325, 10), "Floor 2 Room 3", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount3 < 60:
                    win.blit(pickupSuperPotion[pickupCount3//3], (x,y))
                    pickupCount3 += 1
                elif pickupCount3 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
    elif luck == 1:
        if itemLuck1Spawned5 == 'healing_herb':
            win.blit(spr_herb, (itm_spwn_x, itm_spwn_y))
            if t3 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+healing_herb_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t3=t3-1
            elif t3 == 0:
                win.fill(white)
                win.blit(Floor2Room3, (0,0))
                room_title8 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title8.render_to(win, (325, 10), "Floor 2 Room 3", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount3 < 60:
                    win.blit(pickupHealingHerb[pickupCount3//3], (x,y))
                    pickupCount3 += 1
                elif pickupCount3 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck1Spawned5 == 'potion':
            win.blit(spr_potion, (itm_spwn_x, itm_spwn_y))
            if t3 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t3=t3-1
            elif t3 == 0:
                win.fill(white)
                win.blit(Floor2Room3, (0,0))
                room_title8 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title8.render_to(win, (325, 10), "Floor 2 Room 3", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount3 < 60:
                    win.blit(pickupPotion[pickupCount3//3], (x,y))
                    pickupCount3 += 1
                elif pickupCount3 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck1Spawned5 == 'super_potion':
            win.blit(spr_super_potion, (itm_spwn_x, itm_spwn_y))
            if t3 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+super_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t3=t3-1
            elif t3 == 0:
                win.fill(white)
                win.blit(Floor2Room3, (0,0))
                room_title8 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title8.render_to(win, (325, 10), "Floor 2 Room 3", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount3 < 60:
                    win.blit(pickupSuperPotion[pickupCount3//3], (x,y))
                    pickupCount3 += 1
                elif pickupCount3 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
    elif luck == 2:
        if itemLuck2Spawned5 == 'healing_herb':
            win.blit(spr_herb, (itm_spwn_x, itm_spwn_y))
            if t3 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+healing_herb_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t3=t3-1
            elif t3 == 0:
                win.fill(white)
                win.blit(Floor2Room3, (0,0))
                room_title8 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title8.render_to(win, (325, 10), "Floor 2 Room 3", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount3 < 60:
                    win.blit(pickupHealingHerb[pickupCount3//3], (x,y))
                    pickupCount3 += 1
                elif pickupCount3 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck2Spawned5 == 'potion':
            win.blit(spr_potion, (itm_spwn_x, itm_spwn_y))
            if t3 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t3=t3-1
            elif t3 == 0:
                win.fill(white)
                win.blit(Floor2Room3, (0,0))
                room_title8 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title8.render_to(win, (325, 10), "Floor 2 Room 3", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount3 < 60:
                    win.blit(pickupPotion[pickupCount3//3], (x,y))
                    pickupCount3 += 1
                elif pickupCount3 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck2Spawned5 == 'super_potion':
            win.blit(spr_super_potion, (itm_spwn_x, itm_spwn_y))
            if t3 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+super_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t3=t3-1
            elif t3 == 0:
                win.fill(white)
                win.blit(Floor2Room3, (0,0))
                room_title8 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title8.render_to(win, (325, 10), "Floor 2 Room 3", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount3 < 60:
                    win.blit(pickupSuperPotion[pickupCount3//3], (x,y))
                    pickupCount3 += 1
                elif pickupCount3 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
    elif luck == 3:
        if itemLuck3Spawned5 == 'healing_herb':
            win.blit(spr_herb, (itm_spwn_x, itm_spwn_y))
            if t3 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+healing_herb_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t3=t3-1
            elif t3 == 0:
                win.fill(white)
                win.blit(Floor2Room3, (0,0))
                room_title8 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title8.render_to(win, (325, 10), "Floor 2 Room 3", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount3 < 60:
                    win.blit(pickupHealingHerb[pickupCount3//3], (x,y))
                    pickupCount3 += 1
                elif pickupCount3 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck3Spawned5 == 'potion':
            win.blit(spr_potion, (itm_spwn_x, itm_spwn_y))
            if t3 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t3=t3-1
            elif t3 == 0:
                win.fill(white)
                win.blit(Floor2Room3, (0,0))
                room_title8 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title8.render_to(win, (325, 10), "Floor 2 Room 3", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount3 < 60:
                    win.blit(pickupPotion[pickupCount3//3], (x,y))
                    pickupCount3 += 1
                elif pickupCount3 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck3Spawned5 == 'super_potion':
            win.blit(spr_super_potion, (itm_spwn_x, itm_spwn_y))
            if t3 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+super_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t3=t3-1
            elif t3 == 0:
                win.fill(white)
                win.blit(Floor2Room3, (0,0))
                room_title8 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title8.render_to(win, (325, 10), "Floor 2 Room 3", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount3 < 60:
                    win.blit(pickupSuperPotion[pickupCount3//3], (x,y))
                    pickupCount3 += 1
                elif pickupCount3 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
    p.display.update()
def level_9():
    global walkCount
    global player_health
    global dmg_dagger
    global dmg_trident
    global dmg_sword
    global dmg_axe
    global dmg_AK47
    global dmg_Nuke
    global omega_potion_healed
    global epic_potion_healed
    global t4
    global pickupCount4
    global luck
    win.blit(SecretRoom, (0,0))
    room_title9 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
    room_title9.render_to(win, (375, 10), "???", (black))
    health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
    defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
    luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
    dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    if 'dagger' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
    elif 'trident' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
    elif 'sword' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
    elif 'axe' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
    elif 'gun' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
    elif 'nuke' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
    else:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))

    if walkCount + 1 >= 60:
        walkCount = 0

    if left:
        win.blit(walkLeft[walkCount//3], (x,y))
        walkCount += 1
    elif right:
        win.blit(walkRight[walkCount//3], (x,y))
        walkCount += 1
    elif up:
        win.blit(walkUp[walkCount//3], (x,y))
        walkCount += 1
    elif down:
        win.blit(walkDown[walkCount//3], (x,y))
        walkCount += 1
    else:
        win.blit(chara, (x, y))
    #Spawning items
    if luck == 0:
        if itemSpawned6 == 'two_times':
            win.blit(spr_two_times, (itm_spwn_x, itm_spwn_y))
            if t4 == 1:
                if 'dagger' in inventory:
                    dmg_dagger=dmg_dagger*2
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t4=t4-1
                elif 'trident' in inventory:
                    dmg_trident=dmg_trident*2
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t4=t4-1
                elif 'sword' in inventory:
                    dmg_sword=dmg_sword*2
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t4=t4-1
                elif 'axe' in inventory:
                    dmg_axe=dmg_axe*2
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t4=t4-1
                elif 'gun' in inventory:
                    dmg_AK47=dmg_AK47*2
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t4=t4-1
                elif 'nuke' in inventory:
                    dmg_Nuke=dmg_Nuke*2
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t4=t4-1
            elif t4 == 0:
                win.fill(white)
                win.blit(SecretRoom, (0,0))
                room_title9 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title9.render_to(win, (375, 10), "???", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount4 < 60:
                    win.blit(pickupTwoTimes[pickupCount4//3], (x,y))
                    pickupCount4 += 1
                elif pickupCount4 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemSpawned6 == 'omega_potion':
            win.blit(spr_omega_potion, (itm_spwn_x, itm_spwn_y))
            if t4 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+omega_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t4=t4-1
            elif t4 == 0:
                win.fill(white)
                win.blit(SecretRoom, (0,0))
                room_title9 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title9.render_to(win, (375, 10), "???", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount4 < 60:
                    win.blit(pickupOmegaPotion[pickupCount4//3], (x,y))
                    pickupCount4 += 1
                elif pickupCount4 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemSpawned6 == 'epic_potion':
            win.blit(spr_epic_potion, (itm_spwn_x, itm_spwn_y))
            if t4 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+omega_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t4=t4-1
            elif t4 == 0:
                win.fill(white)
                win.blit(SecretRoom, (0,0))
                room_title9 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title9.render_to(win, (375, 10), "???", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount4 < 60:
                    win.blit(pickupEpicPotion[pickupCount4//3], (x,y))
                    pickupCount4 += 1
                elif pickupCount4 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
    elif luck == 1:
        if itemLuck1Spawned6 == 'two_times':
            win.blit(spr_two_times, (itm_spwn_x, itm_spwn_y))
            if t4 == 1:
                if 'dagger' in inventory:
                    dmg_dagger=dmg_dagger*2
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t4=t4-1
                elif 'trident' in inventory:
                    dmg_trident=dmg_trident*2
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t4=t4-1
                elif 'sword' in inventory:
                    dmg_sword=dmg_sword*2
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t4=t4-1
                elif 'axe' in inventory:
                    dmg_axe=dmg_axe*2
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t4=t4-1
                elif 'gun' in inventory:
                    dmg_AK47=dmg_AK47*2
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t4=t4-1
                elif 'nuke' in inventory:
                    dmg_Nuke=dmg_Nuke*2
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t4=t4-1
            elif t4 == 0:
                win.fill(white)
                win.blit(SecretRoom, (0,0))
                room_title9 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title9.render_to(win, (375, 10), "???", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount4 < 60:
                    win.blit(pickupTwoTimes[pickupCount4//3], (x,y))
                    pickupCount4 += 1
                elif pickupCount4 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck1Spawned6 == 'omega_potion':
            win.blit(spr_omega_potion, (itm_spwn_x, itm_spwn_y))
            if t4 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+omega_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t4=t4-1
            elif t4 == 0:
                win.fill(white)
                win.blit(SecretRoom, (0,0))
                room_title9 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title9.render_to(win, (375, 10), "???", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount4 < 60:
                    win.blit(pickupOmegaPotion[pickupCount4//3], (x,y))
                    pickupCount4 += 1
                elif pickupCount4 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck1Spawned6 == 'epic_potion':
            win.blit(spr_epic_potion, (itm_spwn_x, itm_spwn_y))
            if t4 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+omega_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t4=t4-1
            elif t4 == 0:
                win.fill(white)
                win.blit(SecretRoom, (0,0))
                room_title9 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title9.render_to(win, (375, 10), "???", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount4 < 60:
                    win.blit(pickupEpicPotion[pickupCount4//3], (x,y))
                    pickupCount4 += 1
                elif pickupCount4 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
    elif luck == 2:
        if itemLuck2Spawned6 == 'two_times':
            win.blit(spr_two_times, (itm_spwn_x, itm_spwn_y))
            if t4 == 1:
                if 'dagger' in inventory:
                    dmg_dagger=dmg_dagger*2
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t4=t4-1
                elif 'trident' in inventory:
                    dmg_trident=dmg_trident*2
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t4=t4-1
                elif 'sword' in inventory:
                    dmg_sword=dmg_sword*2
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t4=t4-1
                elif 'axe' in inventory:
                    dmg_axe=dmg_axe*2
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t4=t4-1
                elif 'gun' in inventory:
                    dmg_AK47=dmg_AK47*2
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t4=t4-1
                elif 'nuke' in inventory:
                    dmg_Nuke=dmg_Nuke*2
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t4=t4-1
            elif t4 == 0:
                win.fill(white)
                win.blit(SecretRoom, (0,0))
                room_title9 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title9.render_to(win, (375, 10), "???", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount4 < 60:
                    win.blit(pickupTwoTimes[pickupCount4//3], (x,y))
                    pickupCount4 += 1
                elif pickupCount4 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck2Spawned6 == 'omega_potion':
            win.blit(spr_omega_potion, (itm_spwn_x, itm_spwn_y))
            if t4 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+omega_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t4=t4-1
            elif t4 == 0:
                win.fill(white)
                win.blit(SecretRoom, (0,0))
                room_title9 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title9.render_to(win, (375, 10), "???", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount4 < 60:
                    win.blit(pickupOmegaPotion[pickupCount4//3], (x,y))
                    pickupCount4 += 1
                elif pickupCount4 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck2Spawned6 == 'epic_potion':
            win.blit(spr_epic_potion, (itm_spwn_x, itm_spwn_y))
            if t4 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+omega_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t4=t4-1
            elif t4 == 0:
                win.fill(white)
                win.blit(SecretRoom, (0,0))
                room_title9 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title9.render_to(win, (375, 10), "???", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount4 < 60:
                    win.blit(pickupEpicPotion[pickupCount4//3], (x,y))
                    pickupCount4 += 1
                elif pickupCount4 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
    elif luck == 3:
        if itemLuck3Spawned6 == 'two_times':
            win.blit(spr_two_times, (itm_spwn_x, itm_spwn_y))
            if t4 == 1:
                if 'dagger' in inventory:
                    dmg_dagger=dmg_dagger*2
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t4=t4-1
                elif 'trident' in inventory:
                    dmg_trident=dmg_trident*2
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t4=t4-1
                elif 'sword' in inventory:
                    dmg_sword=dmg_sword*2
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t4=t4-1
                elif 'axe' in inventory:
                    dmg_axe=dmg_axe*2
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t4=t4-1
                elif 'gun' in inventory:
                    dmg_AK47=dmg_AK47*2
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t4=t4-1
                elif 'nuke' in inventory:
                    dmg_Nuke=dmg_Nuke*2
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t4=t4-1
            elif t4 == 0:
                win.fill(white)
                win.blit(SecretRoom, (0,0))
                room_title9 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title9.render_to(win, (375, 10), "???", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount4 < 60:
                    win.blit(pickupTwoTimes[pickupCount4//3], (x,y))
                    pickupCount4 += 1
                elif pickupCount4 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck3Spawned6 == 'omega_potion':
            win.blit(spr_omega_potion, (itm_spwn_x, itm_spwn_y))
            if t4 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+omega_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t4=t4-1
            elif t4 == 0:
                win.fill(white)
                win.blit(SecretRoom, (0,0))
                room_title9 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title9.render_to(win, (375, 10), "???", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount4 < 60:
                    win.blit(pickupOmegaPotion[pickupCount4//3], (x,y))
                    pickupCount4 += 1
                elif pickupCount4 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck3Spawned6 == 'epic_potion':
            win.blit(spr_epic_potion, (itm_spwn_x, itm_spwn_y))
            if t4 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+omega_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t4=t4-1
            elif t4 == 0:
                win.fill(white)
                win.blit(SecretRoom, (0,0))
                room_title9 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title9.render_to(win, (375, 10), "???", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount4 < 60:
                    win.blit(pickupEpicPotion[pickupCount4//3], (x,y))
                    pickupCount4 += 1
                elif pickupCount4 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
    p.display.update()
def level_10():
    global walkCount
    global zombieCount
    global attackCount3
    global player_health
    global zombie1_health
    global a3
    win.blit(Floor2Room4, (0,0))
    room_title10 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
    room_title10.render_to(win, (325, 10), "Floor 2 Room 4", (black))
    health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
    defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
    luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
    dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    if 'dagger' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
    elif 'trident' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
    elif 'sword' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
    elif 'axe' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
    elif 'gun' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
    elif 'nuke' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
    else:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))

    if walkCount + 1 >= 60:
        walkCount = 0

    if left:
        win.blit(walkLeft[walkCount//3], (x,y))
        walkCount += 1
    elif right:
        win.blit(walkRight[walkCount//3], (x,y))
        walkCount += 1
    elif up:
        win.blit(walkUp[walkCount//3], (x,y))
        walkCount += 1
    elif down:
        win.blit(walkDown[walkCount//3], (x,y))
        walkCount += 1
    else:
        win.blit(chara, (x, y))
    #Spawning set enemies
    if a3 == 1:
        if (x >= 400 and x <= 480) and (y >= 215 and y <= 265):
            if 'dagger' in inventory:
                if left == True:
                    win.blit(attackLeftDagger[attackCount3//3], (x,y))
                    attackCount3 += 1
                    zombie1_health=zombie1_health-dmg_dagger
                    if zombie1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount3 >= 60:
                        attackCount3=0
                elif right == True:
                    win.blit(attackRightDagger[attackCount3//3], (x,y))
                    attackCount3 += 1
                    zombie1_health=zombie1_health-dmg_dagger
                    if zombie1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount3 >= 60:
                        attackCount3=0
                elif up == True:
                    win.blit(attackUpDagger[attackCount3//3], (x,y))
                    attackCount3 += 1
                    zombie1_health=zombie1_health-dmg_dagger
                    if zombie1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount3 >= 60:
                        attackCount3=0
                elif down == True:
                    win.blit(attackDownDagger[attackCount3//3], (x,y))
                    attackCount3 += 1
                    zombie1_health=zombie1_health-dmg_dagger
                    if zombie1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount3 >= 60:
                        attackCount3=0
                else:
                    win.blit(attackDownDagger[attackCount3//3], (x,y))
                    attackCount3 += 1
                    zombie1_health=zombie1_health-dmg_dagger
                    if zombie1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount3 >= 60:
                        attackCount3=0
            elif 'trident' in inventory:
                if left == True:
                    win.blit(attackLeftTrident[attackCount3//3], (x,y))
                    attackCount3 += 1
                    zombie1_health=zombie1_health-dmg_trident
                    if zombie1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount3 >= 60:
                        attackCount3=0
                elif right == True:
                    win.blit(attackRightTrident[attackCount3//3], (x,y))
                    attackCount3 += 1
                    zombie1_health=zombie1_health-dmg_trident
                    if zombie1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount3 >= 60:
                        attackCount3=0
                elif up == True:
                    win.blit(attackUpTrident[attackCount3//3], (x,y))
                    attackCount3 += 1
                    zombie1_health=zombie1_health-dmg_trident
                    if zombie1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount3 >= 60:
                        attackCount3=0
                elif down == True:
                    win.blit(attackDownTrident[attackCount3//3], (x,y))
                    attackCount3 += 1
                    zombie1_health=zombie1_health-dmg_trident
                    if zombie1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount3 >= 60:
                        attackCount3=0
                else:
                    win.blit(attackDownTrident[attackCount3//3], (x,y))
                    attackCount3 += 1
                    zombie1_health=zombie1_health-dmg_trident
                    if zombie1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount3 >= 60:
                        attackCount3=0
            elif 'sword' in inventory:
                if left == True:
                    win.blit(attackLeftSword[attackCount3//3], (x,y))
                    attackCount3 += 1
                    zombie1_health=zombie1_health-dmg_sword
                    if zombie1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount3 >= 60:
                        attackCount3=0
                elif right == True:
                    win.blit(attackRightSword[attackCount3//3], (x,y))
                    attackCount3 += 1
                    zombie1_health=zombie1_health-dmg_sword
                    if zombie1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount3 >= 60:
                        attackCount3=0
                elif up == True:
                    win.blit(attackUpSword[attackCount3//3], (x,y))
                    attackCount3 += 1
                    zombie1_health=zombie1_health-dmg_sword
                    if zombie1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount3 >= 60:
                        attackCount3=0
                elif down == True:
                    win.blit(attackDownSword[attackCount3//3], (x,y))
                    attackCount3 += 1
                    zombie1_health=zombie1_health-dmg_sword
                    if zombie1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount3 >= 60:
                        attackCount3=0
                else:
                    win.blit(attackDownSword[attackCount3//3], (x,y))
                    attackCount3 += 1
                    zombie1_health=zombie1_health-dmg_sword
                    if zombie1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount3 >= 60:
                        attackCount3=0
            elif 'axe' in inventory:
                if left == True:
                    win.blit(attackLeftAxe[attackCount3//3], (x,y))
                    attackCount3 += 1
                    zombie1_health=zombie1_health-dmg_axe
                    if zombie1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount3 >= 60:
                        attackCount3=0
                elif right == True:
                    win.blit(attackRightAxe[attackCount3//3], (x,y))
                    attackCount3 += 1
                    zombie1_health=zombie1_health-dmg_axe
                    if zombie1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount3 >= 60:
                        attackCount3=0
                elif up == True:
                    win.blit(attackUpAxe[attackCount3//3], (x,y))
                    attackCount3 += 1
                    zombie1_health=zombie1_health-dmg_axe
                    if zombie1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount3 >= 60:
                        attackCount3=0
                elif down == True:
                    win.blit(attackDownAxe[attackCount3//3], (x,y))
                    attackCount3 += 1
                    zombie1_health=zombie1_health-dmg_axe
                    if zombie1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount3 >= 60:
                        attackCount3=0
                else:
                    win.blit(attackDownAxe[attackCount3//3], (x,y))
                    attackCount3 += 1
                    zombie1_health=zombie1_health-dmg_axe
                    if zombie1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount3 >= 60:
                        attackCount3=0
            elif 'gun' in inventory:
                if left == True:
                    win.blit(attackLeftGun[attackCount3//3], (x,y))
                    attackCount3 += 1
                    zombie1_health=zombie1_health-dmg_AK47
                    if zombie1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount3 >= 60:
                        attackCount3=0
                elif right == True:
                    win.blit(attackRightGun[attackCount3//3], (x,y))
                    attackCount3 += 1
                    zombie1_health=zombie1_health-dmg_AK47
                    if zombie1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount3 >= 60:
                        attackCount3=0
                elif up == True:
                    win.blit(attackUpGun[attackCount3//3], (x,y))
                    attackCount3 += 1
                    zombie1_health=zombie1_health-dmg_AK47
                    if zombie1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount3 >= 60:
                        attackCount3=0
                elif down == True:
                    win.blit(attackDownGun[attackCount3//3], (x,y))
                    attackCount3 += 1
                    zombie1_health=zombie1_health-dmg_AK47
                    if zombie1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount3 >= 60:
                        attackCount3=0
                else:
                    win.blit(attackDownGun[attackCount3//3], (x,y))
                    attackCount3 += 1
                    zombie1_health=zombie1_health-dmg_AK47
                    if zombie1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount3 >= 60:
                        attackCount3=0
            elif 'nuke' in inventory:
                if left == True:
                    win.blit(attackLeftNuke[attackCount3//3], (x,y))
                    attackCount3 += 1
                    zombie1_health=zombie1_health-dmg_Nuke
                    if zombie1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount3 >= 60:
                        attackCount3=0
                elif right == True:
                    win.blit(attackRightNuke[attackCount3//3], (x,y))
                    attackCount3 += 1
                    zombie1_health=zombie1_health-dmg_Nuke
                    if zombie1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount3 >= 60:
                        attackCount3=0
                elif up == True:
                    win.blit(attackUpNuke[attackCount3//3], (x,y))
                    attackCount3 += 1
                    zombie1_health=zombie1_health-dmg_Nuke
                    if zombie1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount3 >= 60:
                        attackCount3=0
                elif down == True:
                    win.blit(attackDownNuke[attackCount3//3], (x,y))
                    attackCount3 += 1
                    zombie1_health=zombie1_health-dmg_Nuke
                    if zombie1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount3 >= 60:
                        attackCount3=0
                else:
                    win.blit(attackDownNuke[attackCount3//3], (x,y))
                    attackCount3 += 1
                    zombie1_health=zombie1_health-dmg_Nuke
                    if zombie1_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie1_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount3 >= 60:
                        attackCount3=0
    if zombie1_health > 0:
        win.blit(Zombie[zombieCount//3], (enemy_x, enemy_y))
        zombie1_health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 14)
        zombie1_health_bar.render_to(win, (455, 245), ("HP " + str(zombie1_health)), (black))
        zombieCount += 1
        if zombieCount == 60:
            zombieCount=0
    elif zombie1_health <= 0:
        a3=a3-1
        pass
    if player_health <= 0:
        gameOver()
    p.display.update()
def level_11():
    global walkCount
    global player_health
    global healing_herb_healed
    global potion_healed
    global super_potion_healed
    global omega_potion_healed
    global t5
    global pickupCount5
    global luck
    win.blit(Floor2Room5, (0,0))
    room_title11 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
    room_title11.render_to(win, (325, 10), "Floor 2 Room 5", (black))
    health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
    defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
    luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
    dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    if 'dagger' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
    elif 'trident' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
    elif 'sword' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
    elif 'axe' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
    elif 'gun' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
    elif 'nuke' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
    else:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))

    if walkCount + 1 >= 60:
        walkCount = 0

    if left:
        win.blit(walkLeft[walkCount//3], (x,y))
        walkCount += 1
    elif right:
        win.blit(walkRight[walkCount//3], (x,y))
        walkCount += 1
    elif up:
        win.blit(walkUp[walkCount//3], (x,y))
        walkCount += 1
    elif down:
        win.blit(walkDown[walkCount//3], (x,y))
        walkCount += 1
    else:
        win.blit(chara, (x, y))
    #Spawning items
    if luck == 0:
        if itemSpawned7 == 'healing_herb':
            win.blit(spr_herb, (itm_spwn_x, itm_spwn_y))
            if t5 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+healing_herb_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t5=t5-1
            elif t5 == 0:
                win.fill(white)
                win.blit(Floor2Room5, (0,0))
                room_title11 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title11.render_to(win, (325, 10), "Floor 2 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount5 < 60:
                    win.blit(pickupHealingHerb[pickupCount5//3], (x,y))
                    pickupCount5 += 1
                elif pickupCount5 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemSpawned7 == 'potion':
            win.blit(spr_potion, (itm_spwn_x, itm_spwn_y))
            if t5 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t5=t5-1
            elif t5 == 0:
                win.fill(white)
                win.blit(Floor2Room5, (0,0))
                room_title11 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title11.render_to(win, (325, 10), "Floor 2 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount5 < 60:
                    win.blit(pickupPotion[pickupCount5//3], (x,y))
                    pickupCount5 += 1
                elif pickupCount5 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemSpawned7 == 'super_potion':
            win.blit(spr_super_potion, (itm_spwn_x, itm_spwn_y))
            if t5 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+super_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t5=t5-1
            elif t5 == 0:
                win.fill(white)
                win.blit(Floor2Room5, (0,0))
                room_title11 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title11.render_to(win, (325, 10), "Floor 2 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount5 < 60:
                    win.blit(pickupSuperPotion[pickupCount5//3], (x,y))
                    pickupCount5 += 1
                elif pickupCount5 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemSpawned7 == 'omega_potion':
            win.blit(spr_omega_potion, (itm_spwn_x, itm_spwn_y))
            if t5 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+omega_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t5=t5-1
            elif t5 == 0:
                win.fill(white)
                win.blit(Floor2Room5, (0,0))
                room_title11 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title11.render_to(win, (325, 10), "Floor 2 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount5 < 60:
                    win.blit(pickupOmegaPotion[pickupCount5//3], (x,y))
                    pickupCount5 += 1
                elif pickupCount5 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
    elif luck == 1:
        if itemLuck1Spawned7 == 'healing_herb':
            win.blit(spr_herb, (itm_spwn_x, itm_spwn_y))
            if t5 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+healing_herb_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t5=t5-1
            elif t5 == 0:
                win.fill(white)
                win.blit(Floor2Room5, (0,0))
                room_title11 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title11.render_to(win, (325, 10), "Floor 2 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount5 < 60:
                    win.blit(pickupHealingHerb[pickupCount5//3], (x,y))
                    pickupCount5 += 1
                elif pickupCount5 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck1Spawned7 == 'potion':
            win.blit(spr_potion, (itm_spwn_x, itm_spwn_y))
            if t5 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t5=t5-1
            elif t5 == 0:
                win.fill(white)
                win.blit(Floor2Room5, (0,0))
                room_title11 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title11.render_to(win, (325, 10), "Floor 2 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount5 < 60:
                    win.blit(pickupPotion[pickupCount5//3], (x,y))
                    pickupCount5 += 1
                elif pickupCount5 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck1Spawned7 == 'super_potion':
            win.blit(spr_super_potion, (itm_spwn_x, itm_spwn_y))
            if t5 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+super_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t5=t5-1
            elif t5 == 0:
                win.fill(white)
                win.blit(Floor2Room5, (0,0))
                room_title11 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title11.render_to(win, (325, 10), "Floor 2 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount5 < 60:
                    win.blit(pickupSuperPotion[pickupCount5//3], (x,y))
                    pickupCount5 += 1
                elif pickupCount5 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck1Spawned7 == 'omega_potion':
            win.blit(spr_omega_potion, (itm_spwn_x, itm_spwn_y))
            if t5 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+omega_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t5=t5-1
            elif t5 == 0:
                win.fill(white)
                win.blit(Floor2Room5, (0,0))
                room_title11 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title11.render_to(win, (325, 10), "Floor 2 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount5 < 60:
                    win.blit(pickupOmegaPotion[pickupCount5//3], (x,y))
                    pickupCount5 += 1
                elif pickupCount5 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
    elif luck == 2:
        if itemLuck2Spawned7 == 'healing_herb':
            win.blit(spr_herb, (itm_spwn_x, itm_spwn_y))
            if t5 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+healing_herb_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t5=t5-1
            elif t5 == 0:
                win.fill(white)
                win.blit(Floor2Room5, (0,0))
                room_title11 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title11.render_to(win, (325, 10), "Floor 2 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount5 < 60:
                    win.blit(pickupHealingHerb[pickupCount5//3], (x,y))
                    pickupCount5 += 1
                elif pickupCount5 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck2Spawned7 == 'potion':
            win.blit(spr_potion, (itm_spwn_x, itm_spwn_y))
            if t5 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t5=t5-1
            elif t5 == 0:
                win.fill(white)
                win.blit(Floor2Room5, (0,0))
                room_title11 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title11.render_to(win, (325, 10), "Floor 2 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount5 < 60:
                    win.blit(pickupPotion[pickupCount5//3], (x,y))
                    pickupCount5 += 1
                elif pickupCount5 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck2Spawned7 == 'super_potion':
            win.blit(spr_super_potion, (itm_spwn_x, itm_spwn_y))
            if t5 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+super_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t5=t5-1
            elif t5 == 0:
                win.fill(white)
                win.blit(Floor2Room5, (0,0))
                room_title11 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title11.render_to(win, (325, 10), "Floor 2 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount5 < 60:
                    win.blit(pickupSuperPotion[pickupCount5//3], (x,y))
                    pickupCount5 += 1
                elif pickupCount5 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck2Spawned7 == 'omega_potion':
            win.blit(spr_omega_potion, (itm_spwn_x, itm_spwn_y))
            if t5 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+omega_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t5=t5-1
            elif t5 == 0:
                win.fill(white)
                win.blit(Floor2Room5, (0,0))
                room_title11 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title11.render_to(win, (325, 10), "Floor 2 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount5 < 60:
                    win.blit(pickupOmegaPotion[pickupCount5//3], (x,y))
                    pickupCount5 += 1
                elif pickupCount5 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
    elif luck == 3:
        if itemLuck3Spawned7 == 'healing_herb':
            win.blit(spr_herb, (itm_spwn_x, itm_spwn_y))
            if t5 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+healing_herb_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t5=t5-1
            elif t5 == 0:
                win.fill(white)
                win.blit(Floor2Room5, (0,0))
                room_title11 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title11.render_to(win, (325, 10), "Floor 2 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount5 < 60:
                    win.blit(pickupHealingHerb[pickupCount5//3], (x,y))
                    pickupCount5 += 1
                elif pickupCount5 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck3Spawned7 == 'potion':
            win.blit(spr_potion, (itm_spwn_x, itm_spwn_y))
            if t5 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t5=t5-1
            elif t5 == 0:
                win.fill(white)
                win.blit(Floor2Room5, (0,0))
                room_title11 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title11.render_to(win, (325, 10), "Floor 2 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount5 < 60:
                    win.blit(pickupPotion[pickupCount5//3], (x,y))
                    pickupCount5 += 1
                elif pickupCount5 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck3Spawned7 == 'super_potion':
            win.blit(spr_super_potion, (itm_spwn_x, itm_spwn_y))
            if t5 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+super_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t5=t5-1
            elif t5 == 0:
                win.fill(white)
                win.blit(Floor2Room5, (0,0))
                room_title11 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title11.render_to(win, (325, 10), "Floor 2 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount5 < 60:
                    win.blit(pickupSuperPotion[pickupCount5//3], (x,y))
                    pickupCount5 += 1
                elif pickupCount5 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck3Spawned7 == 'omega_potion':
            win.blit(spr_omega_potion, (itm_spwn_x, itm_spwn_y))
            if t5 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+omega_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t5=t5-1
            elif t5 == 0:
                win.fill(white)
                win.blit(Floor2Room5, (0,0))
                room_title11 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title11.render_to(win, (325, 10), "Floor 2 Room 5", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount5 < 60:
                    win.blit(pickupOmegaPotion[pickupCount5//3], (x,y))
                    pickupCount5 += 1
                elif pickupCount5 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
    p.display.update()
def level_12():
    global walkCount
    global player_health
    global healing_herb_healed
    global potion_healed
    global super_potion_healed
    global omega_potion_healed
    global t6
    global pickupCount6
    global luck
    win.blit(Floor3Room1, (0,0))
    room_title12 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
    room_title12.render_to(win, (325, 10), "Floor 3 Room 1", (black))
    health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
    defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
    luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
    dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    if 'dagger' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
    elif 'trident' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
    elif 'sword' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
    elif 'axe' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
    elif 'gun' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
    elif 'nuke' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
    else:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))

    if walkCount + 1 >= 60:
        walkCount = 0

    if left:
        win.blit(walkLeft[walkCount//3], (x,y))
        walkCount += 1
    elif right:
        win.blit(walkRight[walkCount//3], (x,y))
        walkCount += 1
    elif up:
        win.blit(walkUp[walkCount//3], (x,y))
        walkCount += 1
    elif down:
        win.blit(walkDown[walkCount//3], (x,y))
        walkCount += 1
    else:
        win.blit(chara, (x, y))
    #Spawning items
    if luck == 0:
        if itemSpawned8 == 'healing_herb':
            win.blit(spr_herb, (itm_spwn_x, itm_spwn_y))
            if t6 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+healing_herb_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t6=t6-1
            elif t6 == 0:
                win.fill(white)
                win.blit(Floor3Room1, (0,0))
                room_title12 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title12.render_to(win, (325, 10), "Floor 3 Room 1", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount6 < 60:
                    win.blit(pickupHealingHerb[pickupCount6//3], (x,y))
                    pickupCount6 += 1
                elif pickupCount6 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemSpawned8 == 'potion':
            win.blit(spr_potion, (itm_spwn_x, itm_spwn_y))
            if t6 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t6=t6-1
            elif t6 == 0:
                win.fill(white)
                win.blit(Floor3Room1, (0,0))
                room_title12 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title12.render_to(win, (325, 10), "Floor 3 Room 1", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount6 < 60:
                    win.blit(pickupPotion[pickupCount6//3], (x,y))
                    pickupCount6 += 1
                elif pickupCount6 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemSpawned8 == 'super_potion':
            win.blit(spr_super_potion, (itm_spwn_x, itm_spwn_y))
            if t6 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+super_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t6=t6-1
            elif t6 == 0:
                win.fill(white)
                win.blit(Floor3Room1, (0,0))
                room_title12 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title12.render_to(win, (325, 10), "Floor 3 Room 1", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount6 < 60:
                    win.blit(pickupSuperPotion[pickupCount6//3], (x,y))
                    pickupCount6 += 1
                elif pickupCount6 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemSpawned8 == 'omega_potion':
            win.blit(spr_omega_potion, (itm_spwn_x, itm_spwn_y))
            if t6 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+omega_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t6=t6-1
            elif t6 == 0:
                win.fill(white)
                win.blit(Floor3Room1, (0,0))
                room_title12 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title12.render_to(win, (325, 10), "Floor 3 Room 1", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount6 < 60:
                    win.blit(pickupOmegaPotion[pickupCount6//3], (x,y))
                    pickupCount6 += 1
                elif pickupCount6 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
    elif luck == 1:
        if itemLuck1Spawned8 == 'healing_herb':
            win.blit(spr_herb, (itm_spwn_x, itm_spwn_y))
            if t6 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+healing_herb_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t6=t6-1
            elif t6 == 0:
                win.fill(white)
                win.blit(Floor3Room1, (0,0))
                room_title12 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title12.render_to(win, (325, 10), "Floor 3 Room 1", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount6 < 60:
                    win.blit(pickupHealingHerb[pickupCount6//3], (x,y))
                    pickupCount6 += 1
                elif pickupCount6 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck1Spawned8 == 'potion':
            win.blit(spr_potion, (itm_spwn_x, itm_spwn_y))
            if t6 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t6=t6-1
            elif t6 == 0:
                win.fill(white)
                win.blit(Floor3Room1, (0,0))
                room_title12 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title12.render_to(win, (325, 10), "Floor 3 Room 1", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount6 < 60:
                    win.blit(pickupPotion[pickupCount6//3], (x,y))
                    pickupCount6 += 1
                elif pickupCount6 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck1Spawned8 == 'super_potion':
            win.blit(spr_super_potion, (itm_spwn_x, itm_spwn_y))
            if t6 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+super_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t6=t6-1
            elif t6 == 0:
                win.fill(white)
                win.blit(Floor3Room1, (0,0))
                room_title12 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title12.render_to(win, (325, 10), "Floor 3 Room 1", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount6 < 60:
                    win.blit(pickupSuperPotion[pickupCount6//3], (x,y))
                    pickupCount6 += 1
                elif pickupCount6 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck1Spawned8 == 'omega_potion':
            win.blit(spr_omega_potion, (itm_spwn_x, itm_spwn_y))
            if t6 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+omega_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t6=t6-1
            elif t6 == 0:
                win.fill(white)
                win.blit(Floor3Room1, (0,0))
                room_title12 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title12.render_to(win, (325, 10), "Floor 3 Room 1", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount6 < 60:
                    win.blit(pickupOmegaPotion[pickupCount6//3], (x,y))
                    pickupCount6 += 1
                elif pickupCount6 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
    elif luck == 2:
        if itemLuck2Spawned8 == 'healing_herb':
            win.blit(spr_herb, (itm_spwn_x, itm_spwn_y))
            if t6 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+healing_herb_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t6=t6-1
            elif t6 == 0:
                win.fill(white)
                win.blit(Floor3Room1, (0,0))
                room_title12 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title12.render_to(win, (325, 10), "Floor 3 Room 1", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount6 < 60:
                    win.blit(pickupHealingHerb[pickupCount6//3], (x,y))
                    pickupCount6 += 1
                elif pickupCount6 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck2Spawned8 == 'potion':
            win.blit(spr_potion, (itm_spwn_x, itm_spwn_y))
            if t6 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t6=t6-1
            elif t6 == 0:
                win.fill(white)
                win.blit(Floor3Room1, (0,0))
                room_title12 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title12.render_to(win, (325, 10), "Floor 3 Room 1", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount6 < 60:
                    win.blit(pickupPotion[pickupCount6//3], (x,y))
                    pickupCount6 += 1
                elif pickupCount6 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck2Spawned8 == 'super_potion':
            win.blit(spr_super_potion, (itm_spwn_x, itm_spwn_y))
            if t6 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+super_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t6=t6-1
            elif t6 == 0:
                win.fill(white)
                win.blit(Floor3Room1, (0,0))
                room_title12 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title12.render_to(win, (325, 10), "Floor 3 Room 1", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount6 < 60:
                    win.blit(pickupSuperPotion[pickupCount6//3], (x,y))
                    pickupCount6 += 1
                elif pickupCount6 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck2Spawned8 == 'omega_potion':
            win.blit(spr_omega_potion, (itm_spwn_x, itm_spwn_y))
            if t6 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+omega_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t6=t6-1
            elif t6 == 0:
                win.fill(white)
                win.blit(Floor3Room1, (0,0))
                room_title12 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title12.render_to(win, (325, 10), "Floor 3 Room 1", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount6 < 60:
                    win.blit(pickupOmegaPotion[pickupCount6//3], (x,y))
                    pickupCount6 += 1
                elif pickupCount6 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
    elif luck == 3:
        if itemLuck3Spawned8 == 'healing_herb':
            win.blit(spr_herb, (itm_spwn_x, itm_spwn_y))
            if t6 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+healing_herb_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t6=t6-1
            elif t6 == 0:
                win.fill(white)
                win.blit(Floor3Room1, (0,0))
                room_title12 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title12.render_to(win, (325, 10), "Floor 3 Room 1", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount6 < 60:
                    win.blit(pickupHealingHerb[pickupCount6//3], (x,y))
                    pickupCount6 += 1
                elif pickupCount6 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck3Spawned8 == 'potion':
            win.blit(spr_potion, (itm_spwn_x, itm_spwn_y))
            if t6 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t6=t6-1
            elif t6 == 0:
                win.fill(white)
                win.blit(Floor3Room1, (0,0))
                room_title12 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title12.render_to(win, (325, 10), "Floor 3 Room 1", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount6 < 60:
                    win.blit(pickupPotion[pickupCount6//3], (x,y))
                    pickupCount6 += 1
                elif pickupCount6 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck3Spawned8 == 'super_potion':
            win.blit(spr_super_potion, (itm_spwn_x, itm_spwn_y))
            if t6 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+super_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t6=t6-1
            elif t6 == 0:
                win.fill(white)
                win.blit(Floor3Room1, (0,0))
                room_title12 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title12.render_to(win, (325, 10), "Floor 3 Room 1", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount6 < 60:
                    win.blit(pickupSuperPotion[pickupCount6//3], (x,y))
                    pickupCount6 += 1
                elif pickupCount6 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck3Spawned8 == 'omega_potion':
            win.blit(spr_omega_potion, (itm_spwn_x, itm_spwn_y))
            if t6 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+omega_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t6=t6-1
            elif t6 == 0:
                win.fill(white)
                win.blit(Floor3Room1, (0,0))
                room_title12 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title12.render_to(win, (325, 10), "Floor 3 Room 1", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount6 < 60:
                    win.blit(pickupOmegaPotion[pickupCount6//3], (x,y))
                    pickupCount6 += 1
                elif pickupCount6 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
    p.display.update()
def level_13():
    global walkCount
    global zombieCount1
    global attackCount4
    global player_health
    global zombie2_health
    global a4
    win.blit(Floor3Room2, (0,0))
    room_title13 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
    room_title13.render_to(win, (325, 10), "Floor 3 Room 2", (black))
    health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
    defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
    luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
    dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    if 'dagger' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
    elif 'trident' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
    elif 'sword' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
    elif 'axe' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
    elif 'gun' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
    elif 'nuke' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
    else:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))

    if walkCount + 1 >= 60:
        walkCount = 0

    if left:
        win.blit(walkLeft[walkCount//3], (x,y))
        walkCount += 1
    elif right:
        win.blit(walkRight[walkCount//3], (x,y))
        walkCount += 1
    elif up:
        win.blit(walkUp[walkCount//3], (x,y))
        walkCount += 1
    elif down:
        win.blit(walkDown[walkCount//3], (x,y))
        walkCount += 1
    else:
        win.blit(chara, (x, y))
    #Spawning set enemies
    if a4 == 1:
        if (x >= 400 and x <= 480) and (y >= 215 and y <= 265):
            if 'dagger' in inventory:
                if left == True:
                    win.blit(attackLeftDagger[attackCount4//3], (x,y))
                    attackCount4 += 1
                    zombie2_health=zombie2_health-dmg_dagger
                    if zombie2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount4 >= 60:
                        attackCount4=0
                elif right == True:
                    win.blit(attackRightDagger[attackCount4//3], (x,y))
                    attackCount4 += 1
                    zombie2_health=zombie2_health-dmg_dagger
                    if zombie2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount4 >= 60:
                        attackCount4=0
                elif up == True:
                    win.blit(attackUpDagger[attackCount4//3], (x,y))
                    attackCount4 += 1
                    zombie2_health=zombie2_health-dmg_dagger
                    if zombie2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount4 >= 60:
                        attackCount4=0
                elif down == True:
                    win.blit(attackDownDagger[attackCount4//3], (x,y))
                    attackCount4 += 1
                    zombie2_health=zombie2_health-dmg_dagger
                    if zombie2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount4 >= 60:
                        attackCount4=0
                else:
                    win.blit(attackDownDagger[attackCount4//3], (x,y))
                    attackCount4 += 1
                    zombie2_health=zombie2_health-dmg_dagger
                    if zombie2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount4 >= 60:
                        attackCount4=0
            elif 'trident' in inventory:
                if left == True:
                    win.blit(attackLeftTrident[attackCount4//3], (x,y))
                    attackCount4 += 1
                    zombie2_health=zombie2_health-dmg_trident
                    if zombie2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount4 >= 60:
                        attackCount4=0
                elif right == True:
                    win.blit(attackRightTrident[attackCount4//3], (x,y))
                    attackCount4 += 1
                    zombie2_health=zombie2_health-dmg_trident
                    if zombie2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount4 >= 60:
                        attackCount4=0
                elif up == True:
                    win.blit(attackUpTrident[attackCount4//3], (x,y))
                    attackCount4 += 1
                    zombie2_health=zombie2_health-dmg_trident
                    if zombie2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount4 >= 60:
                        attackCount4=0
                elif down == True:
                    win.blit(attackDownTrident[attackCount4//3], (x,y))
                    attackCount4 += 1
                    zombie2_health=zombie2_health-dmg_trident
                    if zombie2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount4 >= 60:
                        attackCount4=0
                else:
                    win.blit(attackDownTrident[attackCount4//3], (x,y))
                    attackCount4 += 1
                    zombie2_health=zombie2_health-dmg_trident
                    if zombie2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount4 >= 60:
                        attackCount4=0
            elif 'sword' in inventory:
                if left == True:
                    win.blit(attackLeftSword[attackCount4//3], (x,y))
                    attackCount4 += 1
                    zombie2_health=zombie2_health-dmg_sword
                    if zombie2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount4 >= 60:
                        attackCount4=0
                elif right == True:
                    win.blit(attackRightSword[attackCount4//3], (x,y))
                    attackCount4 += 1
                    zombie2_health=zombie2_health-dmg_sword
                    if zombie2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount4 >= 60:
                        attackCount4=0
                elif up == True:
                    win.blit(attackUpSword[attackCount4//3], (x,y))
                    attackCount4 += 1
                    zombie2_health=zombie2_health-dmg_sword
                    if zombie2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount4 >= 60:
                        attackCount4=0
                elif down == True:
                    win.blit(attackDownSword[attackCount4//3], (x,y))
                    attackCount4 += 1
                    zombie2_health=zombie2_health-dmg_sword
                    if zombie2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount4 >= 60:
                        attackCount4=0
                else:
                    win.blit(attackDownSword[attackCount4//3], (x,y))
                    attackCount4 += 1
                    zombie2_health=zombie2_health-dmg_sword
                    if zombie2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount4 >= 60:
                        attackCount4=0
            elif 'axe' in inventory:
                if left == True:
                    win.blit(attackLeftAxe[attackCount4//3], (x,y))
                    attackCount4 += 1
                    zombie2_health=zombie2_health-dmg_axe
                    if zombie2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount4 >= 60:
                        attackCount4=0
                elif right == True:
                    win.blit(attackRightAxe[attackCount4//3], (x,y))
                    attackCount4 += 1
                    zombie2_health=zombie2_health-dmg_axe
                    if zombie2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount4 >= 60:
                        attackCount4=0
                elif up == True:
                    win.blit(attackUpAxe[attackCount4//3], (x,y))
                    attackCount4 += 1
                    zombie2_health=zombie2_health-dmg_axe
                    if zombie2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount4 >= 60:
                        attackCount4=0
                elif down == True:
                    win.blit(attackDownAxe[attackCount4//3], (x,y))
                    attackCount4 += 1
                    zombie2_health=zombie2_health-dmg_axe
                    if zombie2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount4 >= 60:
                        attackCount4=0
                else:
                    win.blit(attackDownAxe[attackCount4//3], (x,y))
                    attackCount4 += 1
                    zombie2_health=zombie2_health-dmg_axe
                    if zombie2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount4 >= 60:
                        attackCount4=0
            elif 'gun' in inventory:
                if left == True:
                    win.blit(attackLeftGun[attackCount4//3], (x,y))
                    attackCount4 += 1
                    zombie2_health=zombie2_health-dmg_AK47
                    if zombie2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount4 >= 60:
                        attackCount4=0
                elif right == True:
                    win.blit(attackRightGun[attackCount4//3], (x,y))
                    attackCount4 += 1
                    zombie2_health=zombie2_health-dmg_AK47
                    if zombie2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount4 >= 60:
                        attackCount4=0
                elif up == True:
                    win.blit(attackUpGun[attackCount4//3], (x,y))
                    attackCount4 += 1
                    zombie2_health=zombie2_health-dmg_AK47
                    if zombie2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount4 >= 60:
                        attackCount4=0
                elif down == True:
                    win.blit(attackDownGun[attackCount4//3], (x,y))
                    attackCount4 += 1
                    zombie2_health=zombie2_health-dmg_AK47
                    if zombie2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount4 >= 60:
                        attackCount4=0
                else:
                    win.blit(attackDownGun[attackCount4//3], (x,y))
                    attackCount4 += 1
                    zombie2_health=zombie2_health-dmg_AK47
                    if zombie2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount4 >= 60:
                        attackCount4=0
            elif 'nuke' in inventory:
                if left == True:
                    win.blit(attackLeftNuke[attackCount4//3], (x,y))
                    attackCount4 += 1
                    zombie2_health=zombie2_health-dmg_Nuke
                    if zombie2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount4 >= 60:
                        attackCount4=0
                elif right == True:
                    win.blit(attackRightNuke[attackCount4//3], (x,y))
                    attackCount4 += 1
                    zombie2_health=zombie2_health-dmg_Nuke
                    if zombie2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount4 >= 60:
                        attackCount4=0
                elif up == True:
                    win.blit(attackUpNuke[attackCount4//3], (x,y))
                    attackCount4 += 1
                    zombie2_health=zombie2_health-dmg_Nuke
                    if zombie2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount4 >= 60:
                        attackCount4=0
                elif down == True:
                    win.blit(attackDownNuke[attackCount4//3], (x,y))
                    attackCount4 += 1
                    zombie2_health=zombie2_health-dmg_Nuke
                    if zombie2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount4 >= 60:
                        attackCount4=0
                else:
                    win.blit(attackDownNuke[attackCount4//3], (x,y))
                    attackCount4 += 1
                    zombie2_health=zombie2_health-dmg_Nuke
                    if zombie2_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*zombie2_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount4 >= 60:
                        attackCount4=0
    if zombie2_health > 0:
        win.blit(Zombie[zombieCount1//3], (enemy_x, enemy_y))
        zombie2_health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 14)
        zombie2_health_bar.render_to(win, (455, 245), ("HP " + str(zombie2_health)), (black))
        zombieCount1 += 1
        if zombieCount1 == 60:
            zombieCount1=0
    elif zombie2_health <= 0:
        a4=a4-1
        pass
    if player_health <= 0:
        gameOver()
    p.display.update()
def level_14():
    global walkCount
    global player_health
    global potion_healed
    global super_potion_healed
    global omega_potion_healed
    global t7
    global pickupCount7
    global luck
    win.blit(Floor3Room3, (0,0))
    room_title14 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
    room_title14.render_to(win, (325, 10), "Floor 3 Room 3", (black))
    health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
    defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
    luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
    dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    if 'dagger' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
    elif 'trident' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
    elif 'sword' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
    elif 'axe' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
    elif 'gun' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
    elif 'nuke' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
    else:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))

    if walkCount + 1 >= 60:
        walkCount = 0

    if left:
        win.blit(walkLeft[walkCount//3], (x,y))
        walkCount += 1
    elif right:
        win.blit(walkRight[walkCount//3], (x,y))
        walkCount += 1
    elif up:
        win.blit(walkUp[walkCount//3], (x,y))
        walkCount += 1
    elif down:
        win.blit(walkDown[walkCount//3], (x,y))
        walkCount += 1
    else:
        win.blit(chara, (x, y))
    #Spawning items
    if luck == 0:
        if itemSpawned9 == 'potion':
            win.blit(spr_potion, (itm_spwn_x, itm_spwn_y))
            if t7 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t7=t7-1
            elif t7 == 0:
                win.fill(white)
                win.blit(Floor3Room3, (0,0))
                room_title14 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title14.render_to(win, (325, 10), "Floor 3 Room 3", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount7 < 60:
                    win.blit(pickupPotion[pickupCount7//3], (x,y))
                    pickupCount7 += 1
                elif pickupCount7 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemSpawned9 == 'super_potion':
            win.blit(spr_super_potion, (itm_spwn_x, itm_spwn_y))
            if t7 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+super_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t7=t7-1
            elif t7 == 0:
                win.fill(white)
                win.blit(Floor3Room3, (0,0))
                room_title14 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title14.render_to(win, (325, 10), "Floor 3 Room 3", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount7 < 60:
                    win.blit(pickupSuperPotion[pickupCount7//3], (x,y))
                    pickupCount7 += 1
                elif pickupCount7 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemSpawned9 == 'omega_potion':
            win.blit(spr_omega_potion, (itm_spwn_x, itm_spwn_y))
            if t7 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+omega_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t7=t7-1
            elif t7 == 0:
                win.fill(white)
                win.blit(Floor3Room3, (0,0))
                room_title14 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title14.render_to(win, (325, 10), "Floor 3 Room 3", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount7 < 60:
                    win.blit(pickupPotion[pickupCount7//3], (x,y))
                    pickupCount7 += 1
                elif pickupCount7 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
    elif luck == 1:
        if itemLuck1Spawned9 == 'potion':
            win.blit(spr_potion, (itm_spwn_x, itm_spwn_y))
            if t7 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t7=t7-1
            elif t7 == 0:
                win.fill(white)
                win.blit(Floor3Room3, (0,0))
                room_title14 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title14.render_to(win, (325, 10), "Floor 3 Room 3", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount7 < 60:
                    win.blit(pickupPotion[pickupCount7//3], (x,y))
                    pickupCount7 += 1
                elif pickupCount7 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck1Spawned9 == 'super_potion':
            win.blit(spr_super_potion, (itm_spwn_x, itm_spwn_y))
            if t7 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+super_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t7=t7-1
            elif t7 == 0:
                win.fill(white)
                win.blit(Floor3Room3, (0,0))
                room_title14 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title14.render_to(win, (325, 10), "Floor 3 Room 3", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount7 < 60:
                    win.blit(pickupSuperPotion[pickupCount7//3], (x,y))
                    pickupCount7 += 1
                elif pickupCount7 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck1Spawned9 == 'omega_potion':
            win.blit(spr_omega_potion, (itm_spwn_x, itm_spwn_y))
            if t7 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+omega_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t7=t7-1
            elif t7 == 0:
                win.fill(white)
                win.blit(Floor3Room3, (0,0))
                room_title14 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title14.render_to(win, (325, 10), "Floor 3 Room 3", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount7 < 60:
                    win.blit(pickupPotion[pickupCount7//3], (x,y))
                    pickupCount7 += 1
                elif pickupCount7 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
    elif luck == 2:
        if itemLuck2Spawned9 == 'potion':
            win.blit(spr_potion, (itm_spwn_x, itm_spwn_y))
            if t7 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t7=t7-1
            elif t7 == 0:
                win.fill(white)
                win.blit(Floor3Room3, (0,0))
                room_title14 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title14.render_to(win, (325, 10), "Floor 3 Room 3", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount7 < 60:
                    win.blit(pickupPotion[pickupCount7//3], (x,y))
                    pickupCount7 += 1
                elif pickupCount7 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck2Spawned9 == 'super_potion':
            win.blit(spr_super_potion, (itm_spwn_x, itm_spwn_y))
            if t7 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+super_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t7=t7-1
            elif t7 == 0:
                win.fill(white)
                win.blit(Floor3Room3, (0,0))
                room_title14 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title14.render_to(win, (325, 10), "Floor 3 Room 3", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount7 < 60:
                    win.blit(pickupSuperPotion[pickupCount7//3], (x,y))
                    pickupCount7 += 1
                elif pickupCount7 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck2Spawned9 == 'omega_potion':
            win.blit(spr_omega_potion, (itm_spwn_x, itm_spwn_y))
            if t7 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+omega_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t7=t7-1
            elif t7 == 0:
                win.fill(white)
                win.blit(Floor3Room3, (0,0))
                room_title14 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title14.render_to(win, (325, 10), "Floor 3 Room 3", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount7 < 60:
                    win.blit(pickupPotion[pickupCount7//3], (x,y))
                    pickupCount7 += 1
                elif pickupCount7 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
    elif luck == 3:
        if itemLuck3Spawned9 == 'potion':
            win.blit(spr_potion, (itm_spwn_x, itm_spwn_y))
            if t7 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t7=t7-1
            elif t7 == 0:
                win.fill(white)
                win.blit(Floor3Room3, (0,0))
                room_title14 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title14.render_to(win, (325, 10), "Floor 3 Room 3", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount7 < 60:
                    win.blit(pickupPotion[pickupCount7//3], (x,y))
                    pickupCount7 += 1
                elif pickupCount7 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck3Spawned9 == 'super_potion':
            win.blit(spr_super_potion, (itm_spwn_x, itm_spwn_y))
            if t7 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+super_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t7=t7-1
            elif t7 == 0:
                win.fill(white)
                win.blit(Floor3Room3, (0,0))
                room_title14 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title14.render_to(win, (325, 10), "Floor 3 Room 3", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount7 < 60:
                    win.blit(pickupSuperPotion[pickupCount7//3], (x,y))
                    pickupCount7 += 1
                elif pickupCount7 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
        elif itemLuck3Spawned9 == 'omega_potion':
            win.blit(spr_omega_potion, (itm_spwn_x, itm_spwn_y))
            if t7 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+omega_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t7=t7-1
            elif t7 == 0:
                win.fill(white)
                win.blit(Floor3Room3, (0,0))
                room_title14 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title14.render_to(win, (325, 10), "Floor 3 Room 3", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount7 < 60:
                    win.blit(pickupPotion[pickupCount7//3], (x,y))
                    pickupCount7 += 1
                elif pickupCount7 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
    p.display.update()
def level_15():
    global walkCount
    global player_health
    global super_potion_healed
    global omega_potion_healed
    global epic_potion_healed
    global t8
    global pickupCount8
    global toureCount
    global attackCount5
    global player_health
    global toure_health
    global luck
    global a5
    win.blit(Floor3Room4, (0,0))
    room_title15 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
    room_title15.render_to(win, (325, 10), "Floor 3 Room 4", (black))
    health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
    defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
    luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
    dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    if 'dagger' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
    elif 'trident' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
    elif 'sword' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
    elif 'axe' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
    elif 'gun' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
    elif 'nuke' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
    else:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))

    if walkCount + 1 >= 60:
        walkCount = 0

    if left:
        win.blit(walkLeft[walkCount//3], (x,y))
        walkCount += 1
    elif right:
        win.blit(walkRight[walkCount//3], (x,y))
        walkCount += 1
    elif up:
        win.blit(walkUp[walkCount//3], (x,y))
        walkCount += 1
    elif down:
        win.blit(walkDown[walkCount//3], (x,y))
        walkCount += 1
    else:
        win.blit(chara, (x, y))
    #Spawning set enemies
    if a5 == 1:
        if (x >= 400 and x <= 480) and (y >= 215 and y <= 265):
            if 'dagger' in inventory:
                if left == True:
                    win.blit(attackLeftDagger[attackCount5//3], (x,y))
                    attackCount5 += 1
                    toure_health=toure_health-dmg_dagger
                    if toure_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*toure_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount5 >= 60:
                        attackCount5=0
                elif right == True:
                    win.blit(attackRightDagger[attackCount5//3], (x,y))
                    attackCount5 += 1
                    toure_health=toure_health-dmg_dagger
                    if toure_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*toure_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount5 >= 60:
                        attackCount5=0
                elif up == True:
                    win.blit(attackUpDagger[attackCount5//3], (x,y))
                    attackCount5 += 1
                    toure_health=toure_health-dmg_dagger
                    if toure_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*toure_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount5 >= 60:
                        attackCount5=0
                elif down == True:
                    win.blit(attackDownDagger[attackCount5//3], (x,y))
                    attackCount5 += 1
                    toure_health=toure_health-dmg_dagger
                    if toure_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*toure_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount5 >= 60:
                        attackCount5=0
                else:
                    win.blit(attackDownDagger[attackCount5//3], (x,y))
                    attackCount5 += 1
                    toure_health=toure_health-dmg_dagger
                    if toure_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*toure_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount5 >= 60:
                        attackCount5=0
            elif 'trident' in inventory:
                if left == True:
                    win.blit(attackLeftTrident[attackCount5//3], (x,y))
                    attackCount5 += 1
                    toure_health=toure_health-dmg_trident
                    if toure_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*toure_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount5 >= 60:
                        attackCount5=0
                elif right == True:
                    win.blit(attackRightTrident[attackCount5//3], (x,y))
                    attackCount5 += 1
                    toure_health=toure_health-dmg_trident
                    if toure_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*toure_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount5 >= 60:
                        attackCount5=0
                elif up == True:
                    win.blit(attackUpTrident[attackCount5//3], (x,y))
                    attackCount5 += 1
                    toure_health=toure_health-dmg_trident
                    if toure_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*toure_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount5 >= 60:
                        attackCount5=0
                elif down == True:
                    win.blit(attackDownTrident[attackCount5//3], (x,y))
                    attackCount5 += 1
                    toure_health=toure_health-dmg_trident
                    if toure_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*toure_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount5 >= 60:
                        attackCount5=0
                else:
                    win.blit(attackDownTrident[attackCount5//3], (x,y))
                    attackCount5 += 1
                    toure_health=toure_health-dmg_trident
                    if toure_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*toure_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount5 >= 60:
                        attackCount5=0
            elif 'sword' in inventory:
                if left == True:
                    win.blit(attackLeftSword[attackCount5//3], (x,y))
                    attackCount5 += 1
                    toure_health=toure_health-dmg_sword
                    if toure_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*toure_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount5 >= 60:
                        attackCount5=0
                elif right == True:
                    win.blit(attackRightSword[attackCount5//3], (x,y))
                    attackCount5 += 1
                    toure_health=toure_health-dmg_sword
                    if toure_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*toure_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount5 >= 60:
                        attackCount5=0
                elif up == True:
                    win.blit(attackUpSword[attackCount5//3], (x,y))
                    attackCount5 += 1
                    toure_health=toure_health-dmg_sword
                    if toure_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*toure_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount5 >= 60:
                        attackCount5=0
                elif down == True:
                    win.blit(attackDownSword[attackCount5//3], (x,y))
                    attackCount5 += 1
                    toure_health=toure_health-dmg_sword
                    if toure_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*toure_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount5 >= 60:
                        attackCount5=0
                else:
                    win.blit(attackDownSword[attackCount5//3], (x,y))
                    attackCount5 += 1
                    toure_health=toure_health-dmg_sword
                    if toure_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*toure_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount5 >= 60:
                        attackCount5=0
            elif 'axe' in inventory:
                if left == True:
                    win.blit(attackLeftAxe[attackCount5//3], (x,y))
                    attackCount5 += 1
                    toure_health=toure_health-dmg_axe
                    if toure_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*toure_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount5 >= 60:
                        attackCount5=0
                elif right == True:
                    win.blit(attackRightAxe[attackCount5//3], (x,y))
                    attackCount5 += 1
                    toure_health=toure_health-dmg_axe
                    if toure_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*toure_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount5 >= 60:
                        attackCount5=0
                elif up == True:
                    win.blit(attackRightAxe[attackCount5//3], (x,y))
                    attackCount5 += 1
                    toure_health=toure_health-dmg_axe
                    if toure_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*toure_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount5 >= 60:
                        attackCount5=0
                elif down == True:
                    win.blit(attackDownAxe[attackCount5//3], (x,y))
                    attackCount5 += 1
                    toure_health=toure_health-dmg_axe
                    if toure_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*toure_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount5 >= 60:
                        attackCount5=0
                else:
                    win.blit(attackDownAxe[attackCount5//3], (x,y))
                    attackCount5 += 1
                    toure_health=toure_health-dmg_axe
                    if toure_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*toure_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount5 >= 60:
                        attackCount5=0
            elif 'gun' in inventory:
                if left == True:
                    win.blit(attackLeftGun[attackCount5//3], (x,y))
                    attackCount5 += 1
                    toure_health=toure_health-dmg_AK47
                    if toure_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*toure_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount5 >= 60:
                        attackCount5=0
                elif right == True:
                    win.blit(attackRightGun[attackCount5//3], (x,y))
                    attackCount5 += 1
                    toure_health=toure_health-dmg_AK47
                    if toure_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*toure_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount5 >= 60:
                        attackCount5=0
                elif up == True:
                    win.blit(attackUpGun[attackCount5//3], (x,y))
                    attackCount5 += 1
                    toure_health=toure_health-dmg_AK47
                    if toure_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*toure_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount5 >= 60:
                        attackCount5=0
                elif down == True:
                    win.blit(attackDownGun[attackCount5//3], (x,y))
                    attackCount5 += 1
                    toure_health=toure_health-dmg_AK47
                    if toure_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*toure_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount5 >= 60:
                        attackCount5=0
                else:
                    win.blit(attackDownGun[attackCount5//3], (x,y))
                    attackCount5 += 1
                    toure_health=toure_health-dmg_AK47
                    if toure_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*toure_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount5 >= 60:
                        attackCount5=0
            elif 'nuke' in inventory:
                if left == True:
                    win.blit(attackLeftNuke[attackCount5//3], (x,y))
                    attackCount5 += 1
                    toure_health=toure_health-dmg_Nuke
                    if toure_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*toure_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount5 >= 60:
                        attackCount5=0
                elif right == True:
                    win.blit(attackRightNuke[attackCount5//3], (x,y))
                    attackCount5 += 1
                    toure_health=toure_health-dmg_Nuke
                    if toure_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*toure_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount5 >= 60:
                        attackCount5=0
                elif up == True:
                    win.blit(attackUpNuke[attackCount5//3], (x,y))
                    attackCount5 += 1
                    toure_health=toure_health-dmg_Nuke
                    if toure_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*toure_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount5 >= 60:
                        attackCount5=0
                elif down == True:
                    win.blit(attackDownNuke[attackCount5//3], (x,y))
                    attackCount5 += 1
                    toure_health=toure_health-dmg_Nuke
                    if toure_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*toure_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount5 >= 60:
                        attackCount5=0
                else:
                    win.blit(attackDownNuke[attackCount5//3], (x,y))
                    attackCount5 += 1
                    toure_health=toure_health-dmg_Nuke
                    if toure_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*toure_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount5 >= 60:
                        attackCount5=0
    if toure_health > 0:
        win.blit(MmeToure[toureCount//3], (enemy_x, enemy_y))
        toure_health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 14)
        toure_health_bar.render_to(win, (455, 245), ("HP " + str(toure_health)), (black))
        toureCount += 1
        if toureCount == 60:
            toureCount=0
    elif toure_health <= 0:
        a5=a5-1
        pass
    if player_health <= 0:
        gameOver()
    #Spawning items
    if luck == 0:
        if itemSpawned10 == 'super_potion':
            win.blit(spr_super_potion, (itm_spwn_x, itm_spwn_y))
            if t8 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+super_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t8=t8-1
            elif t8 == 0:
                win.fill(white)
                win.blit(Floor3Room4, (0,0))
                room_title15 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title15.render_to(win, (325, 10), "Floor 3 Room 4", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount8 < 60:
                    win.blit(pickupSuperPotion[pickupCount8//3], (x,y))
                    pickupCount8 += 1
                elif pickupCount8 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
                #Spawning set enemies
                if a5 == 1:
                    if (x >= 400 and x <= 480) and (y >= 215 and y <= 265):
                        if 'dagger' in inventory:
                            if left == True:
                                win.blit(attackLeftDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'trident' in inventory:
                            if left == True:
                                win.blit(attackLeftTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'sword' in inventory:
                            if left == True:
                                win.blit(attackLeftSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'axe' in inventory:
                            if left == True:
                                win.blit(attackLeftAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackRightAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'gun' in inventory:
                            if left == True:
                                win.blit(attackLeftGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'nuke' in inventory:
                            if left == True:
                                win.blit(attackLeftNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                if toure_health > 0:
                    win.blit(MmeToure[toureCount//3], (enemy_x, enemy_y))
                    toure_health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 14)
                    toure_health_bar.render_to(win, (455, 245), ("HP " + str(toure_health)), (black))
                    toureCount += 1
                    if toureCount == 60:
                        toureCount=0
                elif toure_health <= 0:
                    a5=a5-1
                    pass
                if player_health <= 0:
                    gameOver()
        elif itemSpawned10 == 'omega_potion':
            win.blit(spr_omega_potion, (itm_spwn_x, itm_spwn_y))
            if t8 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+omega_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t8=t8-1
            elif  t8 == 0:
                win.fill(white)
                win.blit(Floor3Room4, (0,0))
                room_title15 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title15.render_to(win, (325, 10), "Floor 3 Room 4", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount8 < 60:
                    win.blit(pickupOmegaPotion[pickupCount8//3], (x,y))
                    pickupCount8 += 1
                elif pickupCount8 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
                #Spawning set enemies
                if a5 == 1:
                    if (x >= 400 and x <= 480) and (y >= 215 and y <= 265):
                        if 'dagger' in inventory:
                            if left == True:
                                win.blit(attackLeftDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'trident' in inventory:
                            if left == True:
                                win.blit(attackLeftTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'sword' in inventory:
                            if left == True:
                                win.blit(attackLeftSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'axe' in inventory:
                            if left == True:
                                win.blit(attackLeftAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackRightAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'gun' in inventory:
                            if left == True:
                                win.blit(attackLeftGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'nuke' in inventory:
                            if left == True:
                                win.blit(attackLeftNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                if toure_health > 0:
                    win.blit(MmeToure[toureCount//3], (enemy_x, enemy_y))
                    toure_health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 14)
                    toure_health_bar.render_to(win, (455, 245), ("HP " + str(toure_health)), (black))
                    toureCount += 1
                    if toureCount == 60:
                        toureCount=0
                elif toure_health <= 0:
                    a5=a5-1
                    pass
                if player_health <= 0:
                    gameOver()
        elif itemSpawned10 == 'epic_potion':
            win.blit(spr_epic_potion, (itm_spwn_x, itm_spwn_y))
            if t8 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+epic_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t8=t8-1
            elif t8 == 0:
                win.fill(white)
                win.blit(Floor3Room4, (0,0))
                room_title15 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title15.render_to(win, (325, 10), "Floor 3 Room 4", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount8 < 60:
                    win.blit(pickupEpicPotion[pickupCount8//3], (x,y))
                    pickupCount8 += 1
                elif pickupCount8 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
                #Spawning set enemies
                if a5 == 1:
                    if (x >= 400 and x <= 480) and (y >= 215 and y <= 265):
                        if 'dagger' in inventory:
                            if left == True:
                                win.blit(attackLeftDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'trident' in inventory:
                            if left == True:
                                win.blit(attackLeftTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'sword' in inventory:
                            if left == True:
                                win.blit(attackLeftSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'axe' in inventory:
                            if left == True:
                                win.blit(attackLeftAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackRightAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'gun' in inventory:
                            if left == True:
                                win.blit(attackLeftGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'nuke' in inventory:
                            if left == True:
                                win.blit(attackLeftNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                if toure_health > 0:
                    win.blit(MmeToure[toureCount//3], (enemy_x, enemy_y))
                    toure_health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 14)
                    toure_health_bar.render_to(win, (455, 245), ("HP " + str(toure_health)), (black))
                    toureCount += 1
                    if toureCount == 60:
                        toureCount=0
                elif toure_health <= 0:
                    a5=a5-1
                    pass
                if player_health <= 0:
                    gameOver()
    elif luck == 1:
        if itemLuck1Spawned10 == 'super_potion':
            win.blit(spr_super_potion, (itm_spwn_x, itm_spwn_y))
            if t8 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+super_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t8=t8-1
            elif t8 == 0:
                win.fill(white)
                win.blit(Floor3Room4, (0,0))
                room_title15 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title15.render_to(win, (325, 10), "Floor 3 Room 4", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount8 < 60:
                    win.blit(pickupSuperPotion[pickupCount8//3], (x,y))
                    pickupCount8 += 1
                elif pickupCount8 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
                #Spawning set enemies
                if a5 == 1:
                    if (x >= 400 and x <= 480) and (y >= 215 and y <= 265):
                        if 'dagger' in inventory:
                            if left == True:
                                win.blit(attackLeftDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'trident' in inventory:
                            if left == True:
                                win.blit(attackLeftTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'sword' in inventory:
                            if left == True:
                                win.blit(attackLeftSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'axe' in inventory:
                            if left == True:
                                win.blit(attackLeftAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackRightAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'gun' in inventory:
                            if left == True:
                                win.blit(attackLeftGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'nuke' in inventory:
                            if left == True:
                                win.blit(attackLeftNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                if toure_health > 0:
                    win.blit(MmeToure[toureCount//3], (enemy_x, enemy_y))
                    toure_health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 14)
                    toure_health_bar.render_to(win, (455, 245), ("HP " + str(toure_health)), (black))
                    toureCount += 1
                    if toureCount == 60:
                        toureCount=0
                elif toure_health <= 0:
                    a5=a5-1
                    pass
                if player_health <= 0:
                    gameOver()
        elif itemLuck1Spawned10 == 'omega_potion':
            win.blit(spr_omega_potion, (itm_spwn_x, itm_spwn_y))
            if t8 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+omega_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t8=t8-1
            elif  t8 == 0:
                win.fill(white)
                win.blit(Floor3Room4, (0,0))
                room_title15 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title15.render_to(win, (325, 10), "Floor 3 Room 4", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount8 < 60:
                    win.blit(pickupOmegaPotion[pickupCount8//3], (x,y))
                    pickupCount8 += 1
                elif pickupCount8 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
                #Spawning set enemies
                if a5 == 1:
                    if (x >= 400 and x <= 480) and (y >= 215 and y <= 265):
                        if 'dagger' in inventory:
                            if left == True:
                                win.blit(attackLeftDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'trident' in inventory:
                            if left == True:
                                win.blit(attackLeftTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'sword' in inventory:
                            if left == True:
                                win.blit(attackLeftSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'axe' in inventory:
                            if left == True:
                                win.blit(attackLeftAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackRightAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'gun' in inventory:
                            if left == True:
                                win.blit(attackLeftGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'nuke' in inventory:
                            if left == True:
                                win.blit(attackLeftNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                if toure_health > 0:
                    win.blit(MmeToure[toureCount//3], (enemy_x, enemy_y))
                    toure_health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 14)
                    toure_health_bar.render_to(win, (455, 245), ("HP " + str(toure_health)), (black))
                    toureCount += 1
                    if toureCount == 60:
                        toureCount=0
                elif toure_health <= 0:
                    a5=a5-1
                    pass
                if player_health <= 0:
                    gameOver()
        elif itemLuck1Spawned10 == 'epic_potion':
            win.blit(spr_epic_potion, (itm_spwn_x, itm_spwn_y))
            if t8 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+epic_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t8=t8-1
            elif t8 == 0:
                win.fill(white)
                win.blit(Floor3Room4, (0,0))
                room_title15 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title15.render_to(win, (325, 10), "Floor 3 Room 4", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount8 < 60:
                    win.blit(pickupEpicPotion[pickupCount8//3], (x,y))
                    pickupCount8 += 1
                elif pickupCount8 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
                #Spawning set enemies
                if a5 == 1:
                    if (x >= 400 and x <= 480) and (y >= 215 and y <= 265):
                        if 'dagger' in inventory:
                            if left == True:
                                win.blit(attackLeftDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'trident' in inventory:
                            if left == True:
                                win.blit(attackLeftTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'sword' in inventory:
                            if left == True:
                                win.blit(attackLeftSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'axe' in inventory:
                            if left == True:
                                win.blit(attackLeftAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackRightAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'gun' in inventory:
                            if left == True:
                                win.blit(attackLeftGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'nuke' in inventory:
                            if left == True:
                                win.blit(attackLeftNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                if toure_health > 0:
                    win.blit(MmeToure[toureCount//3], (enemy_x, enemy_y))
                    toure_health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 14)
                    toure_health_bar.render_to(win, (455, 245), ("HP " + str(toure_health)), (black))
                    toureCount += 1
                    if toureCount == 60:
                        toureCount=0
                elif toure_health <= 0:
                    a5=a5-1
                    pass
                if player_health <= 0:
                    gameOver()
    elif luck == 2:
        if itemLuck2Spawned10 == 'super_potion':
            win.blit(spr_super_potion, (itm_spwn_x, itm_spwn_y))
            if t8 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+super_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t8=t8-1
            elif t8 == 0:
                win.fill(white)
                win.blit(Floor3Room4, (0,0))
                room_title15 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title15.render_to(win, (325, 10), "Floor 3 Room 4", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount8 < 60:
                    win.blit(pickupSuperPotion[pickupCount8//3], (x,y))
                    pickupCount8 += 1
                elif pickupCount8 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
                #Spawning set enemies
                if a5 == 1:
                    if (x >= 400 and x <= 480) and (y >= 215 and y <= 265):
                        if 'dagger' in inventory:
                            if left == True:
                                win.blit(attackLeftDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'trident' in inventory:
                            if left == True:
                                win.blit(attackLeftTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'sword' in inventory:
                            if left == True:
                                win.blit(attackLeftSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'axe' in inventory:
                            if left == True:
                                win.blit(attackLeftAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackRightAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'gun' in inventory:
                            if left == True:
                                win.blit(attackLeftGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'nuke' in inventory:
                            if left == True:
                                win.blit(attackLeftNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                if toure_health > 0:
                    win.blit(MmeToure[toureCount//3], (enemy_x, enemy_y))
                    toure_health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 14)
                    toure_health_bar.render_to(win, (455, 245), ("HP " + str(toure_health)), (black))
                    toureCount += 1
                    if toureCount == 60:
                        toureCount=0
                elif toure_health <= 0:
                    a5=a5-1
                    pass
                if player_health <= 0:
                    gameOver()
        elif itemLuck2Spawned10 == 'omega_potion':
            win.blit(spr_omega_potion, (itm_spwn_x, itm_spwn_y))
            if t8 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+omega_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t8=t8-1
            elif  t8 == 0:
                win.fill(white)
                win.blit(Floor3Room4, (0,0))
                room_title15 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title15.render_to(win, (325, 10), "Floor 3 Room 4", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount8 < 60:
                    win.blit(pickupOmegaPotion[pickupCount8//3], (x,y))
                    pickupCount8 += 1
                elif pickupCount8 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
                #Spawning set enemies
                if a5 == 1:
                    if (x >= 400 and x <= 480) and (y >= 215 and y <= 265):
                        if 'dagger' in inventory:
                            if left == True:
                                win.blit(attackLeftDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'trident' in inventory:
                            if left == True:
                                win.blit(attackLeftTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'sword' in inventory:
                            if left == True:
                                win.blit(attackLeftSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'axe' in inventory:
                            if left == True:
                                win.blit(attackLeftAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackRightAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'gun' in inventory:
                            if left == True:
                                win.blit(attackLeftGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'nuke' in inventory:
                            if left == True:
                                win.blit(attackLeftNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                if toure_health > 0:
                    win.blit(MmeToure[toureCount//3], (enemy_x, enemy_y))
                    toure_health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 14)
                    toure_health_bar.render_to(win, (455, 245), ("HP " + str(toure_health)), (black))
                    toureCount += 1
                    if toureCount == 60:
                        toureCount=0
                elif toure_health <= 0:
                    a5=a5-1
                    pass
                if player_health <= 0:
                    gameOver()
        elif itemLuck2Spawned10 == 'epic_potion':
            win.blit(spr_epic_potion, (itm_spwn_x, itm_spwn_y))
            if t8 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+epic_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t8=t8-1
            elif t8 == 0:
                win.fill(white)
                win.blit(Floor3Room4, (0,0))
                room_title15 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title15.render_to(win, (325, 10), "Floor 3 Room 4", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount8 < 60:
                    win.blit(pickupEpicPotion[pickupCount8//3], (x,y))
                    pickupCount8 += 1
                elif pickupCount8 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
                #Spawning set enemies
                if a5 == 1:
                    if (x >= 400 and x <= 480) and (y >= 215 and y <= 265):
                        if 'dagger' in inventory:
                            if left == True:
                                win.blit(attackLeftDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'trident' in inventory:
                            if left == True:
                                win.blit(attackLeftTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'sword' in inventory:
                            if left == True:
                                win.blit(attackLeftSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'axe' in inventory:
                            if left == True:
                                win.blit(attackLeftAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackRightAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'gun' in inventory:
                            if left == True:
                                win.blit(attackLeftGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'nuke' in inventory:
                            if left == True:
                                win.blit(attackLeftNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                if toure_health > 0:
                    win.blit(MmeToure[toureCount//3], (enemy_x, enemy_y))
                    toure_health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 14)
                    toure_health_bar.render_to(win, (455, 245), ("HP " + str(toure_health)), (black))
                    toureCount += 1
                    if toureCount == 60:
                        toureCount=0
                elif toure_health <= 0:
                    a5=a5-1
                    pass
                if player_health <= 0:
                    gameOver()
    elif luck == 3:
        if itemLuck3Spawned10 == 'super_potion':
            win.blit(spr_super_potion, (itm_spwn_x, itm_spwn_y))
            if t8 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+super_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t8=t8-1
            elif t8 == 0:
                win.fill(white)
                win.blit(Floor3Room4, (0,0))
                room_title15 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title15.render_to(win, (325, 10), "Floor 3 Room 4", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount8 < 60:
                    win.blit(pickupSuperPotion[pickupCount8//3], (x,y))
                    pickupCount8 += 1
                elif pickupCount8 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
                #Spawning set enemies
                if a5 == 1:
                    if (x >= 400 and x <= 480) and (y >= 215 and y <= 265):
                        if 'dagger' in inventory:
                            if left == True:
                                win.blit(attackLeftDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'trident' in inventory:
                            if left == True:
                                win.blit(attackLeftTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'sword' in inventory:
                            if left == True:
                                win.blit(attackLeftSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'axe' in inventory:
                            if left == True:
                                win.blit(attackLeftAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackRightAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'gun' in inventory:
                            if left == True:
                                win.blit(attackLeftGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'nuke' in inventory:
                            if left == True:
                                win.blit(attackLeftNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                if toure_health > 0:
                    win.blit(MmeToure[toureCount//3], (enemy_x, enemy_y))
                    toure_health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 14)
                    toure_health_bar.render_to(win, (455, 245), ("HP " + str(toure_health)), (black))
                    toureCount += 1
                    if toureCount == 60:
                        toureCount=0
                elif toure_health <= 0:
                    a5=a5-1
                    pass
                if player_health <= 0:
                    gameOver()
        elif itemLuck3Spawned10 == 'omega_potion':
            win.blit(spr_omega_potion, (itm_spwn_x, itm_spwn_y))
            if t8 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+omega_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t8=t8-1
            elif  t8 == 0:
                win.fill(white)
                win.blit(Floor3Room4, (0,0))
                room_title15 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title15.render_to(win, (325, 10), "Floor 3 Room 4", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount8 < 60:
                    win.blit(pickupOmegaPotion[pickupCount8//3], (x,y))
                    pickupCount8 += 1
                elif pickupCount8 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
                #Spawning set enemies
                if a5 == 1:
                    if (x >= 400 and x <= 480) and (y >= 215 and y <= 265):
                        if 'dagger' in inventory:
                            if left == True:
                                win.blit(attackLeftDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'trident' in inventory:
                            if left == True:
                                win.blit(attackLeftTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'sword' in inventory:
                            if left == True:
                                win.blit(attackLeftSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'axe' in inventory:
                            if left == True:
                                win.blit(attackLeftAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackRightAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'gun' in inventory:
                            if left == True:
                                win.blit(attackLeftGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'nuke' in inventory:
                            if left == True:
                                win.blit(attackLeftNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                if toure_health > 0:
                    win.blit(MmeToure[toureCount//3], (enemy_x, enemy_y))
                    toure_health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 14)
                    toure_health_bar.render_to(win, (455, 245), ("HP " + str(toure_health)), (black))
                    toureCount += 1
                    if toureCount == 60:
                        toureCount=0
                elif toure_health <= 0:
                    a5=a5-1
                    pass
                if player_health <= 0:
                    gameOver()
        elif itemLuck3Spawned10 == 'epic_potion':
            win.blit(spr_epic_potion, (itm_spwn_x, itm_spwn_y))
            if t8 == 1:
                if (x >= 330 and x <= 370) and (y >= 305 and y <= 345):
                    player_health=player_health+epic_potion_healed
                    m.music.load('item-get.mp3')
                    m.music.play()
                    t8=t8-1
            elif t8 == 0:
                win.fill(white)
                win.blit(Floor3Room4, (0,0))
                room_title15 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
                room_title15.render_to(win, (325, 10), "Floor 3 Room 4", (black))
                health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
                defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
                luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
                dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
                if 'dagger' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
                elif 'trident' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
                elif 'sword' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
                elif 'axe' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
                elif 'gun' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
                elif 'nuke' in inventory:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
                else:
                    dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
                if pickupCount8 < 60:
                    win.blit(pickupEpicPotion[pickupCount8//3], (x,y))
                    pickupCount8 += 1
                elif pickupCount8 > 60:
                    win.blit(chara, (x,y))
                if walkCount + 1 >= 60:
                    walkCount = 0
                if left:
                    win.blit(walkLeft[walkCount//3], (x,y))
                    walkCount += 1
                elif right:
                    win.blit(walkRight[walkCount//3], (x,y))
                    walkCount += 1
                elif up:
                    win.blit(walkUp[walkCount//3], (x,y))
                    walkCount += 1
                elif down:
                    win.blit(walkDown[walkCount//3], (x,y))
                    walkCount += 1
                else:
                    win.blit(chara, (x, y))
                #Spawning set enemies
                if a5 == 1:
                    if (x >= 400 and x <= 480) and (y >= 215 and y <= 265):
                        if 'dagger' in inventory:
                            if left == True:
                                win.blit(attackLeftDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownDagger[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_dagger
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'trident' in inventory:
                            if left == True:
                                win.blit(attackLeftTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownTrident[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_trident
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'sword' in inventory:
                            if left == True:
                                win.blit(attackLeftSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownSword[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_sword
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'axe' in inventory:
                            if left == True:
                                win.blit(attackLeftAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackRightAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownAxe[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_axe
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'gun' in inventory:
                            if left == True:
                                win.blit(attackLeftGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownGun[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_AK47
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                        elif 'nuke' in inventory:
                            if left == True:
                                win.blit(attackLeftNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif right == True:
                                win.blit(attackRightNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif up == True:
                                win.blit(attackUpNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            elif down == True:
                                win.blit(attackDownNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                            else:
                                win.blit(attackDownNuke[attackCount5//3], (x,y))
                                attackCount5 += 1
                                toure_health=toure_health-dmg_Nuke
                                if toure_health > 0:
                                    if player_defense == 0:
                                        player_health=player_health-devil1_dmg
                                    elif player_defense > 0:
                                        dmg_undefended=((1-(player_defense/100))*toure_dmg)
                                        player_health=player_health-dmg_undefended
                                if attackCount5 >= 60:
                                    attackCount5=0
                if toure_health > 0:
                    win.blit(MmeToure[toureCount//3], (enemy_x, enemy_y))
                    toure_health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 14)
                    toure_health_bar.render_to(win, (455, 245), ("HP " + str(toure_health)), (black))
                    toureCount += 1
                    if toureCount == 60:
                        toureCount=0
                elif toure_health <= 0:
                    a5=a5-1
                    pass
                if player_health <= 0:
                    gameOver()
    p.display.update()
def level_16():
    global walkCount
    global satanCount
    global attackCount6
    global player_health
    global satan_health
    global a6
    win.blit(Floor3Room5, (0,0))
    room_title16 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
    room_title16.render_to(win, (325, 10), "Floor 3 Room 5", (black))
    health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
    defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
    luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
    dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    if 'dagger' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
    elif 'trident' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
    elif 'sword' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
    elif 'axe' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
    elif 'gun' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
    elif 'nuke' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
    else:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))

    if walkCount + 1 >= 60:
        walkCount = 0

    if left:
        win.blit(walkLeft[walkCount//3], (x,y))
        walkCount += 1
    elif right:
        win.blit(walkRight[walkCount//3], (x,y))
        walkCount += 1
    elif up:
        win.blit(walkUp[walkCount//3], (x,y))
        walkCount += 1
    elif down:
        win.blit(walkDown[walkCount//3], (x,y))
        walkCount += 1
    else:
        win.blit(chara, (x, y))
    #Spawning set enemies
    if a6 == 1:
        if (x >= 400 and x <= 480) and (y >= 215 and y <= 265):
            if 'dagger' in inventory:
                if left == True:
                    win.blit(attackLeftDagger[attackCount6//3], (x,y))
                    attackCount6 += 1
                    satan_health=satan_health-dmg_dagger
                    if satan_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*satan_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount6 >= 60:
                        attackCount6=0
                elif right == True:
                    win.blit(attackRightDagger[attackCount6//3], (x,y))
                    attackCount6 += 1
                    satan_health=satan_health-dmg_dagger
                    if satan_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*satan_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount6 >= 60:
                        attackCount6=0
                elif up == True:
                    win.blit(attackUpDagger[attackCount6//3], (x,y))
                    attackCount6 += 1
                    satan_health=satan_health-dmg_dagger
                    if satan_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*satan_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount6 >= 60:
                        attackCount6=0
                elif down == True:
                    win.blit(attackDownDagger[attackCount6//3], (x,y))
                    attackCount6 += 1
                    satan_health=satan_health-dmg_dagger
                    if satan_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*satan_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount6 >= 60:
                        attackCount6=0
                else:
                    win.blit(attackDownDagger[attackCount6//3], (x,y))
                    attackCount6 += 1
                    satan_health=satan_health-dmg_dagger
                    if satan_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*satan_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount6 >= 60:
                        attackCount6=0
            elif 'trident' in inventory:
                if left == True:
                    win.blit(attackLeftTrident[attackCount6//3], (x,y))
                    attackCount6 += 1
                    satan_health=satan_health-dmg_trident
                    if satan_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*satan_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount6 >= 60:
                        attackCount6=0
                elif right == True:
                    win.blit(attackRightTrident[attackCount6//3], (x,y))
                    attackCount6 += 1
                    satan_health=satan_health-dmg_trident
                    if satan_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*satan_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount6 >= 60:
                        attackCount6=0
                elif up == True:
                    win.blit(attackUpTrident[attackCount6//3], (x,y))
                    attackCount6 += 1
                    satan_health=satan_health-dmg_trident
                    if satan_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*satan_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount6 >= 60:
                        attackCount6=0
                elif down == True:
                    win.blit(attackDownTrident[attackCount6//3], (x,y))
                    attackCount6 += 1
                    satan_health=satan_health-dmg_trident
                    if satan_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*satan_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount6 >= 60:
                        attackCount6=0
                else:
                    win.blit(attackDownTrident[attackCount6//3], (x,y))
                    attackCount6 += 1
                    satan_health=satan_health-dmg_trident
                    if satan_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*satan_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount6 >= 60:
                        attackCount6=0
            elif 'sword' in inventory:
                if left == True:
                    win.blit(attackLeftSword[attackCount6//3], (x,y))
                    attackCount6 += 1
                    satan_health=satan_health-dmg_sword
                    if satan_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*satan_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount6 >= 60:
                        attackCount6=0
                elif right == True:
                    win.blit(attackRightSword[attackCount6//3], (x,y))
                    attackCount6 += 1
                    satan_health=satan_health-dmg_sword
                    if satan_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*satan_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount6 >= 60:
                        attackCount6=0
                elif up == True:
                    win.blit(attackUpSword[attackCount6//3], (x,y))
                    attackCount6 += 1
                    satan_health=satan_health-dmg_sword
                    if satan_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*satan_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount6 >= 60:
                        attackCount6=0
                elif down == True:
                    win.blit(attackDownSword[attackCount6//3], (x,y))
                    attackCount6 += 1
                    satan_health=satan_health-dmg_sword
                    if satan_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*satan_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount6 >= 60:
                        attackCount6=0
                else:
                    win.blit(attackDownSword[attackCount6//3], (x,y))
                    attackCount6 += 1
                    satan_health=satan_health-dmg_sword
                    if satan_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*satan_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount6 >= 60:
                        attackCount6=0
            elif 'axe' in inventory:
                if left == True:
                    win.blit(attackLeftAxe[attackCount6//3], (x,y))
                    attackCount6 += 1
                    satan_health=satan_health-dmg_axe
                    if satan_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*satan_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount6 >= 60:
                        attackCount6=0
                elif right == True:
                    win.blit(attackRightAxe[attackCount6//3], (x,y))
                    attackCount6 += 1
                    satan_health=satan_health-dmg_axe
                    if satan_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*satan_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount6 >= 60:
                        attackCount6=0
                elif up == True:
                    win.blit(attackUpAxe[attackCount6//3], (x,y))
                    attackCount6 += 1
                    satan_health=satan_health-dmg_axe
                    if satan_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*satan_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount6 >= 60:
                        attackCount6=0
                elif down == True:
                    win.blit(attackDownAxe[attackCount6//3], (x,y))
                    attackCount6 += 1
                    satan_health=satan_health-dmg_axe
                    if satan_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*satan_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount6 >= 60:
                        attackCount6=0
                else:
                    win.blit(attackDownAxe[attackCount6//3], (x,y))
                    attackCount6 += 1
                    satan_health=satan_health-dmg_axe
                    if satan_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*satan_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount6 >= 60:
                        attackCount6=0
            elif 'gun' in inventory:
                if left == True:
                    win.blit(attackLeftGun[attackCount6//3], (x,y))
                    attackCount6 += 1
                    satan_health=satan_health-dmg_AK47
                    if satan_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*satan_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount6 >= 60:
                        attackCount6=0
                elif right == True:
                    win.blit(attackRightGun[attackCount6//3], (x,y))
                    attackCount6 += 1
                    satan_health=satan_health-dmg_AK47
                    if satan_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*satan_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount6 >= 60:
                        attackCount6=0
                elif up == True:
                    win.blit(attackUpGun[attackCount6//3], (x,y))
                    attackCount6 += 1
                    satan_health=satan_health-dmg_AK47
                    if satan_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*satan_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount6 >= 60:
                        attackCount6=0
                elif down == True:
                    win.blit(attackDownGun[attackCount6//3], (x,y))
                    attackCount6 += 1
                    satan_health=satan_health-dmg_AK47
                    if satan_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*satan_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount6 >= 60:
                        attackCount6=0
                else:
                    win.blit(attackDownGun[attackCount6//3], (x,y))
                    attackCount6 += 1
                    satan_health=satan_health-dmg_AK47
                    if satan_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*satan_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount6 >= 60:
                        attackCount6=0
            elif 'nuke' in inventory:
                if left == True:
                    win.blit(attackLeftNuke[attackCount6//3], (x,y))
                    attackCount6 += 1
                    satan_health=satan_health-dmg_Nuke
                    if satan_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*satan_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount6 >= 60:
                        attackCount6=0
                elif right == True:
                    win.blit(attackRightNuke[attackCount6//3], (x,y))
                    attackCount6 += 1
                    satan_health=satan_health-dmg_Nuke
                    if satan_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*satan_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount6 >= 60:
                        attackCount6=0
                elif up == True:
                    win.blit(attackUpNuke[attackCount6//3], (x,y))
                    attackCount6 += 1
                    satan_health=satan_health-dmg_Nuke
                    if satan_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*satan_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount6 >= 60:
                        attackCount6=0
                elif down == True:
                    win.blit(attackDownNuke[attackCount6//3], (x,y))
                    attackCount6 += 1
                    satan_health=satan_health-dmg_Nuke
                    if satan_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*satan_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount6 >= 60:
                        attackCount6=0
                else:
                    win.blit(attackDownNuke[attackCount6//3], (x,y))
                    attackCount6 += 1
                    satan_health=satan_health-dmg_Nuke
                    if satan_health > 0:
                        if player_defense == 0:
                            player_health=player_health-devil1_dmg
                        elif player_defense > 0:
                            dmg_undefended=((1-(player_defense/100))*satan_dmg)
                            player_health=player_health-dmg_undefended
                    if attackCount6 >= 60:
                        attackCount6=0
    if satan_health > 0:
        win.blit(Satan[satanCount//3], (enemy_x, enemy_y))
        satan_health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 14)
        satan_health_bar.render_to(win, (455, 245), ("HP " + str(satan_health)), (black))
        satanCount += 1
        if satanCount == 60:
            satanCount=0
    elif satan_health <= 0:
        a6=a6-1
        pass
    if player_health <= 0:
        gameOver()
    p.display.update()
def level_17():
    global walkCount
    win.blit(Surface, (0,0))
    room_title17 = p.freetype.Font("Raleway-BlackItalic.ttf", 26)
    room_title17.render_to(win, (325, 10), "The Surface", (black))
    health_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    health_bar.render_to(win, (655, 575), ("HP " + str(player_health)), (black))
    defense_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    defense_bar.render_to(win, (595, 575), ("DEF " + str(player_defense)), (black))
    luck_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    luck_bar.render_to(win, (655, 550), ("Luck " + str(luck)), (black))
    dmg_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 18)
    if 'dagger' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_dagger)), (black))
    elif 'trident' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_trident)), (black))
    elif 'sword' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_sword)), (black))
    elif 'axe' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_axe)), (black))
    elif 'gun' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_AK47)), (black))
    elif 'nuke' in inventory:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(dmg_Nuke)), (black))
    else:
        dmg_bar.render_to(win, (655, 525), ("DMG " + str(no_weapon)), (black))
    win_bar = p.freetype.Font("Raleway-BlackItalic.ttf", 32)
    win_bar.render_to(win, (250, 250), "You WIN!!!", (white))

    if walkCount + 1 >= 60:
        walkCount = 0

    if left:
        win.blit(walkLeft[walkCount//3], (x,y))
        walkCount += 1
    elif right:
        win.blit(walkRight[walkCount//3], (x,y))
        walkCount += 1
    elif up:
        win.blit(walkUp[walkCount//3], (x,y))
        walkCount += 1
    elif down:
        win.blit(walkDown[walkCount//3], (x,y))
        walkCount += 1
    else:
        win.blit(chara, (x, y))
    p.display.update()
def moveRooms():
    global x
    global y
    x=75
    y=250
    win.fill(white)
    p.display.flip()
def moveRooms2():
    global x
    global y
    x=335
    y=445
    win.fill(white)
    p.display.flip()
def moveRooms3():
    global x
    global y
    x=370
    y=20
    win.fill(white)
    p.display.flip()
def moveRooms4():
    global x
    global y
    x=680
    y=230
    win.fill(white)
    p.display.flip()
def moveRooms5():
    global x
    global y
    x=515
    y=45
def moveRooms6():
    global x
    global y
    x=375
    y=350
def redrawGameWindow():
    global n
    if n == 0:
        level_1()
        if x == 685 and (y >= 180 and y <= 275):
            n=n+1
            moveRooms()
    elif n == 1:
        level_2()
        if x == 685 and (y >= 180 and y <= 275):
            n=n+1
            moveRooms()
        elif x == 50 and (y >= 160 and y <= 270):
            n=n-1
            moveRooms4()
    elif n == 2:
        level_3()
        if x == 685 and (y >= 180 and y <= 275):
            n=n+1
            moveRooms()
        elif x == 50 and (y >= 160 and y <= 270):
            n=n-1
            moveRooms4()
    elif n == 3:
        level_4()
        if x == 685 and (y >= 180 and y <= 275):
            n=n+1
            moveRooms()
        elif x == 50 and (y >= 160 and y <= 270):
            n=n-1
            moveRooms4()
    elif n == 4:
        level_5()
        if (x >= 530 and x <= 695) and (y >= 10 and y <= 85):
            n=n+1
            moveRooms()
        elif x == 50 and (y >= 160 and y <= 270):
            n=n-1
            moveRooms4()
    elif n == 5:
        level_6()
        if x == 685 and (y >= 180 and y <= 275):
            n=n+1
            moveRooms()
    elif n == 6:
        level_7()
        if x == 685 and (y >= 180 and y <= 275):
            n=n+1
            moveRooms()
        elif x == 50 and (y >= 160 and y <= 270):
            n=n-1
            moveRooms4()
    elif n == 7:
        level_8()
        if x == 685 and (y >= 180 and y <= 275):
            n=n+1
            moveRooms()
        elif x == 50 and (y >= 160 and y <= 270):
            n=n-1
            moveRooms4()
        elif (x >= 285 and x <= 445) and y == 5:
            n=n-8
            moveRooms2()
    elif n == -1:
        level_9()
        if (x >= 305 and x <= 445) and y == 490:
            n=n+8
            moveRooms3()
    elif n == 8:
        level_10()
        if x == 685 and (y >= 180 and y <= 275):
            n=n+1
            moveRooms()
        elif x == 50 and (y >= 160 and y <= 270):
            n=n-1
            moveRooms4()
    elif n == 9:
        level_11()
        if (x >= 530 and x <= 695) and (y >= 10 and y <= 85):
            n=n+1
            moveRooms()
        elif x == 50 and (y >= 160 and y <= 270):
            n=n-1
            moveRooms4()
    elif n == 10:
        level_12()
        if x == 685 and (y >= 180 and y <= 275):
            n=n+1
            moveRooms()
    elif n == 11:
        level_13()
        if x == 685 and (y >= 180 and y <= 275):
            n=n+1
            moveRooms()
        elif x == 50 and (y >= 160 and y <= 270):
            n=n-1
            moveRooms4()
    elif n == 12:
        level_14()
        if x == 685 and (y >= 180 and y <= 275):
            n=n+1
            moveRooms()
        elif x == 50 and (y >= 160 and y <= 270):
            n=n-1
            moveRooms4()
    elif n == 13:
        level_15()
        if x == 685 and (y >= 180 and y <= 275):
            n=n+1
            moveRooms()
        elif x == 50 and (y >= 160 and y <= 270):
            n=n-1
            moveRooms4()
    elif n == 14:
        level_16()
        if (x >= 530 and x <= 695) and (y >= 10 and y <= 85):
            n=n+1
            moveRooms6()
        elif x == 50 and (y >= 160 and y <= 270):
            n=n-1
            moveRooms4()
    elif n == 15:
        level_17()
        if (x >= 355 and x <= 415) and (y >= 415 and y <= 475):
            n=n-1
            moveRooms5()
#setting stuff to False so the character wont be moving randomly    
isJump = False
jumpCount = 10
left=False
right=False
up=False
down=False
attack=False
walkCount=0
#main loop
run=True
while run:   
    clock.tick(60)

    if player_health <= 0:
        break
    for event in p.event.get():
        if event.type == p.QUIT:
            run = False
    keys=p.key.get_pressed()
    if keys[p.K_q]:
        attack = True
    if keys[p.K_e]:
        attack = True
    if keys[p.K_LEFT]:
        if x > vel:
            x -= vel
            left = True
            right = False
        else:
            m.music.load("error.mp3")
            m.music.play()
    elif keys[p.K_a]:
        if x > vel:
            x -= vel
            left = True
            right = False
        else:
            m.music.load("error.mp3")
            m.music.play()
    elif keys[p.K_RIGHT]:
        if x < 800 - chara_width - vel:
            x += vel
            left = False
            right = True
        else:
            m.music.load("error.mp3")
            m.music.play()
    elif keys[p.K_d]:
        if x < 800 - chara_width - vel:
            x += vel
            left = False
            right = True
        else:
            m.music.load("error.mp3")
            m.music.play()
    else:
        left = False
        right= False
        walkCount=0
    if not(isJump):
        if keys[p.K_UP]:
            if y > vel:
                y -= vel
                up = True
                down = False
            else:
                m.music.load("error.mp3")
                m.music.play()
        if keys[p.K_w]:
            if y > vel:
                y -= vel
                up = True
                down = False
            else:
                m.music.load("error.mp3")
                m.music.play()
        if keys[p.K_DOWN]:
            if y < 600 - chara_height - vel:
                y += vel
                up = False
                down = True
            else:
                m.music.load("error.mp3")
                m.music.play()
        if keys[p.K_s]:
            if y < 600 - chara_height - vel:
                y += vel
                up = False
                down = True
            else:
                m.music.load("error.mp3")
                m.music.play()
        if keys[p.K_SPACE]:
            isJump = True
            left = False
            right = False
            walkCount=0
    else:
        if jumpCount >= -10:
            neg = 1
            if  jumpCount < 0:
                neg = -1
            y -= (jumpCount ** 2) * 0.5 * neg 
            jumpCount -= 1
        else:
            isJump = False
            jumpCount = 10
    if keys[p.K_F4]:
        init_display()
    if keys[p.K_ESCAPE]:
        break
    redrawGameWindow()
p.quit()
